import { ApiProperty, getSchemaPath } from '@nestjs/swagger'
import { SMSType } from './sms-type.enum'
import { SIM_SELECTIONS } from './sim-report'

export class SimInfoDTO {
  @ApiProperty({
    type: Number,
    required: true,
    description:
      'Android subscription id of the SIM. It can change when the SIM is removed and reinserted or swapped, so send with simSlotIndex to choose a SIM.',
    example: 1,
  })
  subscriptionId: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'ICCID of the SIM card.',
  })
  iccId?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Android card id of the SIM slot.',
  })
  cardId?: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'Mobile network operator, as reported by Android.',
    example: 'Safaricom',
  })
  carrierName?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Label the user gave this SIM on the device.',
  })
  displayName?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Physical SIM slot, starting at 0.',
    example: 0,
  })
  simSlotIndex?: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'Mobile country code.',
    example: '639',
  })
  mcc?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Mobile network code.',
    example: '02',
  })
  mnc?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Two letter country code of the SIM.',
    example: 'ke',
  })
  countryIso?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Whether the SIM is physical or an eSIM.',
    enum: ['PHYSICAL_SIM', 'ESIM'],
  })
  subscriptionType?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Whether the SIM had network service when the device last reported.',
    enum: [
      'IN_SERVICE',
      'OUT_OF_SERVICE',
      'EMERGENCY_ONLY',
      'POWER_OFF',
      'UNKNOWN',
    ],
  })
  serviceState?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'State of the SIM card itself, as reported by Android.',
    example: 'READY',
  })
  simState?: string

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether the SIM was roaming when the device last reported.',
  })
  isRoaming?: boolean

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Signal strength on a 0 to 4 scale, where 0 is no signal.',
    example: 3,
  })
  signalLevel?: number
}

export class SimInfoCollectionDTO {
  @ApiProperty({
    type: Date,
    required: true,
    description: 'When the device last reported its SIM list.',
  })
  lastUpdated: Date

  @ApiProperty({
    type: [SimInfoDTO],
    required: true,
    description: 'SIMs currently installed in the device.',
  })
  sims: SimInfoDTO[]
}

export class SimNumberDTO {
  @ApiProperty({
    type: 'integer',
    required: true,
    minimum: 0,
    maximum: 7,
    description:
      'Zero-based SIM slot, the same as simInfo.sims[].simSlotIndex. 0 is SIM 1, 1 is SIM 2.',
    example: 0,
  })
  slotIndex: number

  @ApiProperty({
    type: String,
    required: true,
    description:
      'Phone number of the SIM in this slot, typed by you. Only a label: textbee does not check it and never sends by it. On update, spaces, dashes, dots and brackets are removed, then the value must be an optional + followed by 3 to 15 digits. An empty string removes the number for this slot.',
    example: '+15555550123',
  })
  phoneNumber: string
}

export class RegisterDeviceInputDTO {
  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether the device may send and receive SMS.',
  })
  enabled?: boolean

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Firebase Cloud Messaging token. textbee pushes send jobs to this token, so a stale value stops delivery.',
  })
  fcmToken?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Device brand.',
    example: 'google',
  })
  brand?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Device manufacturer.',
    example: 'Google',
  })
  manufacturer?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Device model.',
    example: 'Pixel 7',
  })
  model?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Your own label for the device, shown in the dashboard.',
    example: 'Office phone',
  })
  name?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Hardware serial. Stored, but never returned by the API.',
  })
  serial?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Android build id.',
    example: 'TQ3A.230805.001',
  })
  buildId?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Operating system name.',
    example: 'Android',
  })
  os?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Android release version.',
    example: '16',
  })
  osVersion?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Android SDK level.',
    example: 36,
  })
  osApiLevel?: number

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Android build fingerprint. Used to fill in the release version when the device does not report one.',
  })
  osBuildFingerprint?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'textbee app version name.',
    example: '1.9.0',
  })
  appVersionName?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'textbee app version code.',
    example: 190,
  })
  appVersionCode?: number

  @ApiProperty({
    type: SimInfoCollectionDTO,
    required: false,
    description: 'SIMs installed in the device.',
  })
  simInfo?: SimInfoCollectionDTO

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Random id of this app install, sent by the textbee app with fcmToken. Not stored on the device as sent.',
  })
  installId?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Package name of the app that installed the textbee app, as Android reports it. An empty string means Android has no installer name. Omit it when the app cannot read it. A value that is not a package name is ignored.',
    example: 'com.android.vending',
  })
  installerPackage?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Package name of the app that started the install, as Android 11 and up reports it. A value that is not a package name is ignored.',
    example: 'com.android.chrome',
  })
  initiatingPackage?: string

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'When the installed textbee app build was installed or last updated, in epoch milliseconds. A value that is not a whole number or not a plausible time is ignored.',
    example: 1762905600000,
  })
  appLastUpdateTime?: number
}

/**
 * Fields a client may write on a device. There is no global ValidationPipe, so
 * without this the whole request body reaches `$set` and any device field is
 * settable, `user` and the SMS counters included.
 *
 * Applied at the controller, which is where input stops being trusted. The
 * service also receives internally built payloads (registerDevice hands its own
 * data to updateDevice) that legitimately carry fields absent from this list.
 */
const DEVICE_WRITABLE_FIELDS = [
  'enabled',
  'fcmToken',
  'brand',
  'manufacturer',
  'model',
  'name',
  'serial',
  'buildId',
  'os',
  'osVersion',
  'osApiLevel',
  'osBuildFingerprint',
  'appVersionName',
  'appVersionCode',
  'simInfo',
  // Read by the service to record which install holds fcmToken, never $set as is
  'installId',
  // Read by the service to record the app version history, never written as given
  'installerPackage',
  'initiatingPackage',
  'appLastUpdateTime',
] as const

export function pickDeviceWritableFields(
  input: RegisterDeviceInputDTO,
): RegisterDeviceInputDTO {
  const picked: any = {}
  for (const field of DEVICE_WRITABLE_FIELDS) {
    if (input?.[field] !== undefined) picked[field] = input[field]
  }
  return picked
}

export class UpdateDeviceInputDTO extends RegisterDeviceInputDTO {
  @ApiProperty({
    type: [SimNumberDTO],
    required: false,
    description:
      'Phone number labels per SIM slot, typed by you. Each entry sets or removes the number for one slot, and slots you leave out keep their number. Omit the field, or send null, to keep every number. The textbee app never sends it.',
    example: [{ slotIndex: 0, phoneNumber: '+15555550123' }],
  })
  simNumbers?: SimNumberDTO[]
}

// Registration takes the phone's fields only; simNumbers is set by the owner
export function pickDeviceUpdateFields(
  input: UpdateDeviceInputDTO,
): UpdateDeviceInputDTO {
  const picked: UpdateDeviceInputDTO = pickDeviceWritableFields(input)
  if (input?.simNumbers != null) picked.simNumbers = input.simNumbers
  return picked
}

export class SMSData {
  @ApiProperty({
    type: String,
    required: true,
    description:
      'Text of the message. Long messages are split by the carrier. At most 9000 bytes, counted in modified UTF-8, which differs from UTF-8 only in that a character outside the Basic Multilingual Plane, such as an emoji, counts as 6 bytes and U+0000 counts as 2. That is about 9000 Latin letters, 4500 Cyrillic, Greek or Arabic letters, or 3000 Chinese, Japanese or Korean characters. A longer message gets a 400 and is not sent.',
    example: 'Your appointment is confirmed for Tuesday at 10am.',
  })
  message: string

  @ApiProperty({
    type: [String],
    required: true,
    description:
      'Phone numbers or short codes to send to. Use international format (+ and country code) to reach another country. Local format works for numbers in the same country as the sending SIM. Values with letters are rejected. Each recipient is billed as one message.',
    example: ['+12025550123', '+12025550124'],
  })
  recipients: string[]

  @ApiProperty({
    type: 'integer',
    required: false,
    minimum: 0,
    maximum: 7,
    description:
      'SIM slot to send from, starting at 0: 0 is SIM 1, 1 is SIM 2. Same numbering as simInfo.sims[].simSlotIndex. Works with or without deviceId, because SIM 2 is the same slot on every phone. The slot is a place in the phone, not a specific SIM card: a different card in that slot sends the message. When the slot has no active SIM, the message fails with SIM_SLOT_EMPTY and is not sent from another SIM. Omit it to use the preferred SIM set in the textbee app, or the device default SIM. When both simSlotIndex and simSubscriptionId are sent, simSlotIndex is used and simSubscriptionId is ignored. Older textbee app versions get a 400 when the phone cannot choose a SIM or its last report shows no SIM in that slot.',
    example: 1,
  })
  simSlotIndex?: number

  @ApiProperty({
    type: Number,
    required: false,
    deprecated: true,
    description:
      'Older way to choose the SIM: use simSlotIndex instead. The subscriptionId from the device simInfo: a whole number from 0 to 2147483646, as a number or a string such as "4". A whole number from -2147483648 to -1, 2147483647, null or an empty string means no SIM is chosen. Fractions, text, true, false and larger numbers get a 400. Android can assign a new id when a SIM is removed and reinserted or swapped, and an id that matches no active SIM is sent from the preferred SIM set in the textbee app, or the device default SIM. Ignored when simSlotIndex is sent.',
    example: 1,
  })
  simSubscriptionId?: number

  @ApiProperty({
    type: String,
    required: false,
    description:
      'ISO 8601 time to send the message. Must be in the future. Omit to send now.',
    example: '2024-01-15T10:30:00Z',
  })
  scheduledAt?: string

  // TODO: restructure the Payload such that it contains bactchId, smsId, recipients and message in an optimized way
  // message: string
  // bactchId: string
  // list: {
  //   smsId: string
  //   recipient: string
  // }

  @ApiProperty({
    type: String,
    required: false,
    deprecated: true,
    description: 'Legacy alias for message. Used only when message is absent.',
  })
  smsBody: string

  @ApiProperty({
    type: [String],
    required: false,
    deprecated: true,
    description:
      'Legacy alias for recipients. Used only when recipients is absent.',
    example: ['+12025550123', '+12025550124'],
  })
  receivers: string[]
}
export class SendSMSInputDTO extends SMSData {}

export class SendBulkSMSInputDTO {
  @ApiProperty({
    type: String,
    required: false,
    description:
      'Optional label for the batch. Each entry in messages carries its own text.',
  })
  messageTemplate: string

  @ApiProperty({
    type: [SMSData],
    required: true,
    description:
      'Messages to send. Every message can target different recipients and use a different SIM.',
  })
  messages: SMSData[]
}

export class SendSMSRequestDTO extends SendSMSInputDTO {
  @ApiProperty({
    type: String,
    required: false,
    description:
      'Device to send from. When omitted, uses your default device, or the enabled device with the most recent heartbeat.',
  })
  deviceId?: string
}

export class SendBulkSMSRequestDTO extends SendBulkSMSInputDTO {
  @ApiProperty({
    type: String,
    required: false,
    description:
      'Device to send from. When omitted, uses your default device, or the enabled device with the most recent heartbeat.',
  })
  deviceId?: string
}

export class DeliveryReportDTO {
  @ApiProperty({
    type: String,
    required: false,
    enum: ['3gpp', '3gpp2'],
    description: 'Format of the delivery report',
    example: '3gpp',
  })
  format?: string

  @ApiProperty({
    type: 'integer',
    required: false,
    description:
      'The status value Android read from the report. For 3gpp it is TP-Status: 0 to 31 delivered, 32 to 63 the carrier is still trying, 64 to 255 the carrier gave up. For 3gpp2 the error class is bits 25 and 24 and the status code is bits 23 to 16: class 0 with code 0 (accepted) still trying, codes 1 and 2 (deposited, delivered) delivered, code 3 (cancelled) the carrier gave up, any other code no verdict; class 2 still trying; class 1 or 3 the carrier gave up. When the carrier verdict is on for the device and the report has perPartUpload true, a report the carrier gave up on fails the message with errorCode CARRIER_ and the status in hex (CARRIER_0x41, or CARRIER_3GPP2_ and bits 23 to 16 for 3gpp2), and a report the carrier still tries on moves a waiting message, or one failed by the push service or the server, to sent. It never marks a message delivered.',
    example: 0,
  })
  status?: number

  @ApiProperty({
    type: String,
    required: false,
    maxLength: 600,
    description:
      'The raw report as a hex string, at most 600 characters. Ignored when it is longer or not hex. The server keeps the report only up to the status, never any user data.',
  })
  pdu?: string
}

// The SIM a device reports for one message. Every field is optional: the
// device omits what Android does not expose, and older apps send nothing.
export class SimUsedDTO {
  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Android subscription id of the SIM. It can change when the SIM is removed and reinserted or swapped.',
    example: 19,
  })
  subscriptionId?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Zero-based slot of the SIM: 0 is SIM 1, 1 is SIM 2.',
    example: 1,
  })
  slotIndex?: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'Mobile network operator, as reported by Android.',
    example: 'Example Mobile',
  })
  carrierName?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Label the user gave this SIM on the device.',
    example: 'Work',
  })
  displayName?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Two letter country code of the SIM, lowercase.',
    example: 'us',
  })
  countryIso?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Mobile country code.',
    example: '310',
  })
  mcc?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Mobile network code.',
    example: '260',
  })
  mnc?: string
}

export class ReceivedSMSDTO {
  @ApiProperty({
    type: String,
    required: true,
    description:
      'Text of the message. An empty string is acknowledged but not stored.',
    example: 'Your code is 482913',
  })
  message: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Phone number or name of the sender. A message without a sender is acknowledged but not stored.',
    example: '+15555550123',
  })
  sender?: string

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'When the phone received the message, as an ISO 8601 date. Used when receivedAtInMillis is missing or 0.',
    example: '2026-09-13T10:30:00.000Z',
  })
  receivedAt?: Date

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'When the phone received the message, in milliseconds since the Unix epoch. Takes precedence over receivedAt. When neither is a valid time, the server time is used.',
    example: 1789295400000,
  })
  receivedAtInMillis?: number

  @ApiProperty({
    type: SimUsedDTO,
    required: false,
    description:
      'The SIM that received the message. Omit it, or any field in it, when the device cannot tell.',
  })
  simUsed?: SimUsedDTO

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Subscription id of the SIM that received the message. Older form of simUsed.subscriptionId, which takes precedence when both are present.',
    example: 19,
  })
  simSubscriptionId?: number

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Zero-based slot of the SIM that received the message: 0 is SIM 1, 1 is SIM 2. Older form of simUsed.slotIndex, which takes precedence when both are present.',
    example: 1,
  })
  simSlotIndex?: number
}

// The device summary embedded in message responses. Message queries populate
// only these fields, so it is deliberately smaller than DeviceDTO.
export class MessageDeviceDTO {
  @ApiProperty({ type: String, description: 'Device id.' })
  _id: string

  @ApiProperty({
    type: Boolean,
    description: 'Whether the device may send and receive SMS.',
  })
  enabled: boolean

  @ApiProperty({
    type: String,
    required: false,
    description: 'Your own label for the device.',
    example: 'Office phone',
  })
  name?: string

  @ApiProperty({ type: String, description: 'Device brand.', example: 'google' })
  brand: string

  @ApiProperty({
    type: String,
    description: 'Device model.',
    example: 'Pixel 7',
  })
  model: string

  @ApiProperty({ type: String, description: 'Android build id.' })
  buildId: string
}

export class BatteryInfoDTO {
  @ApiProperty({
    type: Number,
    required: false,
    description: 'Battery level, 0 to 100.',
  })
  percentage?: number

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether the device was charging at the last heartbeat.',
  })
  isCharging?: boolean

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When this reading was taken.',
  })
  lastUpdated?: Date
}

export class NetworkInfoDTO {
  @ApiProperty({
    type: String,
    required: false,
    enum: ['wifi', 'cellular', 'none'],
    description: 'Connection the device last reported.',
  })
  networkType?: string

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When this reading was taken.',
  })
  lastUpdated?: Date
}

export class AppVersionInfoDTO {
  @ApiProperty({
    type: String,
    required: false,
    description: 'textbee app version name.',
    example: '1.9.0',
  })
  versionName?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'textbee app version code.',
    example: 190,
  })
  versionCode?: number

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When this reading was taken.',
  })
  lastUpdated?: Date
}

export class DeviceUptimeInfoDTO {
  @ApiProperty({
    type: Number,
    required: false,
    description: 'Milliseconds since the device booted.',
  })
  uptimeMillis?: number

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When this reading was taken.',
  })
  lastUpdated?: Date
}

export class PowerInfoDTO {
  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'Whether the app is exempt from battery optimization. When false, Android may delay the app in the background.',
  })
  isIgnoringBatteryOptimizations?: boolean

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether the device was in Doze at the last heartbeat.',
  })
  isDeviceIdleMode?: boolean

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether battery saver was on at the last heartbeat.',
  })
  isPowerSaveMode?: boolean

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When this reading was taken.',
  })
  lastUpdated?: Date
}

export class MemoryInfoDTO {
  @ApiProperty({
    type: Number,
    required: false,
    description: 'Free memory in bytes.',
  })
  freeBytes?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Total memory in bytes.',
  })
  totalBytes?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Maximum memory the app may use, in bytes.',
  })
  maxBytes?: number

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When this reading was taken.',
  })
  lastUpdated?: Date
}

export class StorageInfoDTO {
  @ApiProperty({
    type: Number,
    required: false,
    description: 'Free storage in bytes.',
  })
  availableBytes?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Total storage in bytes.',
  })
  totalBytes?: number

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When this reading was taken.',
  })
  lastUpdated?: Date
}

export class DeviceSystemInfoDTO {
  @ApiProperty({
    type: String,
    required: false,
    description: 'Device timezone.',
    example: 'Africa/Addis_Ababa',
  })
  timezone?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Device locale.',
    example: 'en_US',
  })
  locale?: string

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When this reading was taken.',
  })
  lastUpdated?: Date
}

// Full device as returned by the device endpoints. The push token and hardware
// serial are stored but never returned.
export class DeviceDTO {
  @ApiProperty({
    type: String,
    description: 'Device id. Pass it as deviceId when sending.',
  })
  _id: string

  @ApiProperty({ type: String, description: 'Owner account id.' })
  user: string

  @ApiProperty({
    type: Boolean,
    description:
      'Whether the device may send and receive SMS. Sending to a disabled device fails.',
  })
  enabled: boolean

  @ApiProperty({
    type: Boolean,
    description: 'Whether sends without a deviceId go out from this device.',
  })
  isDefault: boolean

  @ApiProperty({ type: String, description: 'Device brand.', example: 'google' })
  brand: string

  @ApiProperty({
    type: String,
    description: 'Device manufacturer.',
    example: 'Google',
  })
  manufacturer: string

  @ApiProperty({
    type: String,
    description: 'Device model.',
    example: 'Pixel 7',
  })
  model: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Your own label for the device.',
    example: 'Office phone',
  })
  name?: string

  @ApiProperty({ type: String, description: 'Android build id.' })
  buildId: string

  @ApiProperty({
    type: String,
    description: 'Operating system name.',
    example: 'Android',
  })
  os: string

  @ApiProperty({
    type: String,
    description: 'Android release version.',
    example: '16',
  })
  osVersion: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Android SDK level.',
    example: 36,
  })
  osApiLevel?: number

  @ApiProperty({
    type: String,
    required: false,
    enum: ['reported', 'fingerprint', 'buildId'],
    description: 'How osVersion was determined.',
  })
  osVersionSource?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Android build fingerprint.',
  })
  osBuildFingerprint?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'textbee app version name.',
    example: '1.9.0',
  })
  appVersionName?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'textbee app version code.',
    example: 190,
  })
  appVersionCode?: number

  @ApiProperty({
    type: Number,
    description: 'Messages this device has sent.',
  })
  sentSMSCount: number

  @ApiProperty({
    type: Number,
    description: 'Messages this device has received.',
  })
  receivedSMSCount: number

  @ApiProperty({
    type: Boolean,
    description: 'Whether the device reports heartbeats.',
  })
  heartbeatEnabled: boolean

  @ApiProperty({
    type: Number,
    description: 'Minutes between heartbeats.',
    example: 30,
  })
  heartbeatIntervalMinutes: number

  @ApiProperty({
    type: Boolean,
    description:
      'Whether incoming messages are forwarded to textbee. Required for received message history and webhooks.',
  })
  receiveSMSEnabled: boolean

  @ApiProperty({
    type: Number,
    description: 'Seconds the device waits between messages in a batch.',
  })
  smsSendDelaySeconds: number

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'Last heartbeat. A device silent for long is likely offline and sends will queue.',
  })
  lastHeartbeat?: Date

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'True when the API key the textbee app on this device last used is revoked. The device cannot report or receive messages until a new key is added in the app. False until the device next reports after this field was introduced. Returned by the device list only.',
  })
  apiKeyRevoked?: boolean

  @ApiProperty({
    type: BatteryInfoDTO,
    required: false,
    description: 'Battery level at the last heartbeat.',
  })
  batteryInfo?: BatteryInfoDTO

  @ApiProperty({
    type: NetworkInfoDTO,
    required: false,
    description: 'Connection the device was on at the last heartbeat.',
  })
  networkInfo?: NetworkInfoDTO

  @ApiProperty({
    type: AppVersionInfoDTO,
    required: false,
    description: 'textbee app version running on the device.',
  })
  appVersionInfo?: AppVersionInfoDTO

  @ApiProperty({
    type: DeviceUptimeInfoDTO,
    required: false,
    description: 'How long the device has been up.',
  })
  deviceUptimeInfo?: DeviceUptimeInfoDTO

  @ApiProperty({
    type: MemoryInfoDTO,
    required: false,
    description: 'Memory reported at the last heartbeat.',
  })
  memoryInfo?: MemoryInfoDTO

  @ApiProperty({
    type: StorageInfoDTO,
    required: false,
    description: 'Storage reported at the last heartbeat.',
  })
  storageInfo?: StorageInfoDTO

  @ApiProperty({
    type: DeviceSystemInfoDTO,
    required: false,
    description: 'Timezone and locale of the device.',
  })
  systemInfo?: DeviceSystemInfoDTO

  @ApiProperty({
    type: PowerInfoDTO,
    required: false,
    description:
      'Android power state reported at the last heartbeat. Explains a device that is online but slow to send.',
  })
  powerInfo?: PowerInfoDTO

  @ApiProperty({
    type: SimInfoCollectionDTO,
    required: false,
    description: 'SIMs installed in the device.',
  })
  simInfo?: SimInfoCollectionDTO

  @ApiProperty({
    type: [SimNumberDTO],
    required: false,
    description:
      'Phone number labels you set per SIM slot. Absent until you set one.',
  })
  simNumbers?: SimNumberDTO[]

  @ApiProperty({ type: Date, description: 'When the device was registered.' })
  createdAt: Date

  @ApiProperty({ type: Date, description: 'When the device was last updated.' })
  updatedAt: Date
}

export class IssueHistoryEntryDTO {
  @ApiProperty({
    type: String,
    description:
      'Failure code. UNKNOWN when none was reported. From the phone: an Android SmsManager result code as a string, PERMISSION_DENIED, SIM_SLOT_EMPTY, SENDING_EXCEPTION, MESSAGE_TOO_LARGE or SEND_INTERRUPTED, or CARRIER_ and the carrier status in hex (for example CARRIER_0x41) when the carrier reported that it could not deliver the SMS. From the push service: a code that starts with FCM_. From the server: DISPATCH_FAILED or SEND_TIMEOUT.',
    example: 'PERMISSION_DENIED',
  })
  code: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Stable name of the failure, for code that matches on it. Present when textbee knows the code. A phone code only gets a name when source is device.',
    example: 'PERMISSION_DENIED',
  })
  name?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'What happened and how to fix it. For a known code this is the current textbee text, so it can change and improve over time; for other codes it is the stored reason, up to 300 characters.',
  })
  message?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'The text the phone reported for this failure, when it differs from message. Phone failures only. Use message for display.',
    example: 'Invalid destinationAddress',
  })
  deviceMessage?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Link to the docs section that explains this failure. Present only for codes with a docs section.',
    example: 'https://textbee.dev/docs/sending-sms/sending-sms#short-codes',
  })
  docsUrl?: string

  @ApiProperty({
    type: Date,
    description:
      'When the failure happened. Phone time for phone failures, server time otherwise.',
  })
  at: Date

  @ApiProperty({
    type: String,
    enum: ['device', 'push', 'server'],
    description:
      'Where the failure came from. device: the phone could not send. push: the push service could not reach the phone. server: the server could not hand the message off.',
  })
  source: 'device' | 'push' | 'server'

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'True when the entry was rebuilt from the failure fields of a message recorded before this history existed.',
  })
  backfilled?: boolean

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'True when the entry is a delivery report that did not confirm delivery. The message was sent; only the carrier receipt is missing, so this is not a send failure.',
  })
  deliveryReport?: boolean
}

export class RetrieveSMSDTO {
  @ApiProperty({ type: String, description: 'Message id.' })
  _id: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Message text. Empty when the message is end to end encrypted.',
  })
  message: string

  @ApiProperty({
    type: MessageDeviceDTO,
    description: 'Device that sent or received the message.',
  })
  device: MessageDeviceDTO

  @ApiProperty({
    enum: SMSType,
    deprecated: true,
    description:
      'Direction of the message, uppercase. Deprecated: read the lowercase direction field instead, whose values match the direction query filter.',
  })
  type: string

  @ApiProperty({
    type: String,
    required: false,
    nullable: true,
    enum: [
      'pending',
      'dispatched',
      'sent',
      'delivered',
      'failed',
      'unknown',
      'received',
    ],
    description:
      'Delivery state, lowercase. Incoming messages are always received. Outgoing messages move from pending to sent, then to delivered when the carrier confirms. Absent on messages stored before status tracking, so treat a missing value as unknown.',
  })
  status?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Sender number. Set on received messages.',
  })
  sender?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Destination number. Set on sent messages.',
  })
  recipient?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Id of the batch this message was sent in.',
  })
  smsBatch?: string

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'Whether the body is end to end encrypted. Encrypted bodies can only be read by your own client.',
  })
  encrypted?: boolean

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'SIM requested for this send, as passed in the send request. Not necessarily the SIM used: read simUsed for that.',
  })
  simSubscriptionId?: number

  @ApiProperty({
    type: 'integer',
    required: false,
    description:
      'SIM slot requested for this send, starting at 0 (0 is SIM 1), as passed in the send request. Not necessarily the SIM used: read simUsed for that.',
  })
  simSlotIndex?: number

  @ApiProperty({
    type: SimUsedDTO,
    required: false,
    description:
      'SIM the device reports it used: the SIM that sent an outgoing message, or the SIM that received an incoming one. Absent when the device app does not report it.',
  })
  simUsed?: SimUsedDTO

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When the message was received. Received messages only.',
  })
  receivedAt?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When the send was requested. Sent messages only.',
  })
  requestedAt?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'When the queue is due to hand the message to the push service. Set for queued messages that wait server-side before dispatch: scheduled sends, large sends, which are released in waves paced to the device send delay, and sends that wait for the messages already queued for the same device, so the phone is never asked to hold more than it can send. Absent for messages handed to the push service right away.',
  })
  dispatchDueAt?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'When the push service accepted the message for delivery to the device. Does not mean the device has received it; sentAt is the first device-confirmed timestamp.',
  })
  dispatchedAt?: Date

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'How many times the message has been handed to the push service. Normally 1; higher when a message was dispatched again.',
  })
  dispatchAttempts?: number

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'When the device received the push for this message. Absent for messages handled by app versions that do not report it.',
  })
  pushReceivedAt?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'When the device handed the message to the radio. The gap to sentAt is time spent in the radio; the gap from pushReceivedAt is time the message waited on the device.',
  })
  sendAttemptedAt?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When the device reported the message as sent.',
  })
  sentAt?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When the carrier confirmed delivery.',
  })
  deliveredAt?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'When the current failure happened. Present only while status is failed. Removed when a later report shows the message was sent; the failure stays in issueHistory.',
  })
  failedAt?: Date

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Code of the current failure, from the phone, the push service or the server. Present only while status is failed. From the phone: an Android SmsManager result code as a string, PERMISSION_DENIED, SIM_SLOT_EMPTY, SENDING_EXCEPTION, MESSAGE_TOO_LARGE or SEND_INTERRUPTED. From the push service: a code that starts with FCM_. From the server: DISPATCH_FAILED or SEND_TIMEOUT.',
    example: 'PERMISSION_DENIED',
  })
  errorCode?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Stable name of errorCode, for code that matches on it. Present when textbee knows the code.',
    example: 'PERMISSION_DENIED',
  })
  errorName?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'What happened and how to fix it. Present while status is failed. For a known errorCode this is the current textbee text, so it can change and improve over time; for other codes it is the stored reason. While status is unknown it holds a note that the phone did not report in time, which is not a failure.',
  })
  errorMessage?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'The text the phone reported for the current failure, when it differs from errorMessage. Phone failures only. Use errorMessage for display.',
    example: 'Invalid destinationAddress',
  })
  deviceMessage?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Link to the docs section that explains errorCode. Present only for codes with a docs section.',
    example: 'https://textbee.dev/docs/sending-sms/sending-sms#short-codes',
  })
  docsUrl?: string

  @ApiProperty({
    type: [IssueHistoryEntryDTO],
    required: false,
    description:
      'Every failure the message had, plus delivery reports that did not confirm delivery (deliveryReport: true, not failures), oldest first. Kept after the message later succeeds, so a delivered message can show the attempts that failed first. When there are more than 15, only the first 5 and the newest 10 are kept. Absent when nothing was recorded.',
  })
  issueHistory?: IssueHistoryEntryDTO[]

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'True when the message was received while the account was over its plan limit. Received messages only. Absent otherwise.',
  })
  overLimit?: boolean

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'When the platform stored the message. Set only on a received message uploaded more than 24 hours after receivedAt, whose createdAt is set to receivedAt.',
  })
  originalCreatedAt?: Date

  @ApiProperty({
    type: Date,
    description:
      'When the record was created. For a received message uploaded more than 24 hours after receivedAt, this equals receivedAt and originalCreatedAt holds the upload time.',
  })
  createdAt: Date

  @ApiProperty({ type: Date, description: 'When the record was last updated.' })
  updatedAt: Date
}

export class PaginationMetaDTO {
  @ApiProperty({
    type: 'integer',
    required: true,
    description: 'Current page number',
  })
  page: number;

  @ApiProperty({
    type: 'integer',
    required: true,
    description: 'Number of items per page',
  })
  limit: number;

  @ApiProperty({
    type: 'integer',
    required: true,
    description: 'Total number of items',
  })
  total: number;

  @ApiProperty({
    type: 'integer',
    required: true,
    description: 'Total number of pages',
  })
  totalPages: number;
}

export class RetrieveSMSResponseDTO {
  @ApiProperty({
    type: [RetrieveSMSDTO],
    required: true,
    description: 'The received SMS data',
  })
  data: RetrieveSMSDTO[]

  @ApiProperty({
    type: PaginationMetaDTO,
    required: true,
    description: 'Pagination metadata',
  })
  meta?: PaginationMetaDTO
}

export class MessageDTO extends RetrieveSMSDTO {
  @ApiProperty({
    enum: ['sent', 'received'],
    description:
      'Direction of the message, lowercase. Values match the direction query filter, so a response value can be passed straight back as a filter. Not the same thing as status: direction=sent means outbound, status=sent means the device dispatched it.',
  })
  direction: 'sent' | 'received'

  @ApiProperty({
    enum: ['sms'],
    required: false,
    description:
      'Message channel. Currently always sms; mms will appear here when supported. Absent means sms.',
  })
  channel?: string
}

export class CursorPaginationMetaDTO {
  @ApiProperty({ type: 'integer', description: 'Number of items per page.' })
  limit: number

  @ApiProperty({
    type: String,
    nullable: true,
    description:
      'Opaque cursor for the next page. Pass it back as the cursor query parameter. Null when there is nothing further.',
  })
  nextCursor: string | null

  @ApiProperty({
    type: Boolean,
    description: 'Whether more messages exist beyond this page.',
  })
  hasMore: boolean
}

// Page mode carries the cursor fields too, so a poller can start from a plain
// page-mode call and switch to cursor mode without a bootstrap step.
export class MessagePageMetaDTO extends PaginationMetaDTO {
  @ApiProperty({
    type: String,
    nullable: true,
    description:
      'Opaque cursor positioned after the last message on this page. Pass it back as the cursor query parameter. Null on the final page.',
  })
  nextCursor: string | null

  @ApiProperty({
    type: Boolean,
    description: 'Whether more messages exist beyond this page.',
  })
  hasMore: boolean
}

export class MessageListResponseDTO {
  @ApiProperty({ type: [MessageDTO], description: 'Messages, newest first unless order=asc.' })
  data: MessageDTO[]

  @ApiProperty({
    description:
      'Pagination metadata. Page mode (no cursor) returns page, limit, total, totalPages plus nextCursor and hasMore; cursor mode returns limit, nextCursor, and hasMore only, skipping the expensive total count. anyOf rather than oneOf: a page-mode object also satisfies the cursor-mode shape, and oneOf would make strict validators reject it.',
    anyOf: [
      { $ref: getSchemaPath(MessagePageMetaDTO) },
      { $ref: getSchemaPath(CursorPaginationMetaDTO) },
    ],
  })
  meta: MessagePageMetaDTO | CursorPaginationMetaDTO
}

export class UpdateSMSStatusDTO {
  @ApiProperty({
    type: String,
    required: true,
    description: 'The ID of the SMS',
  })
  smsId: string

  @ApiProperty({
    type: String,
    required: true,
    description: 'The ID of the SMS batch',
  })
  smsBatchId: string

  @ApiProperty({
    type: String,
    required: true,
    description:
      'The status of the SMS. delivery_failed is a delivery report that did not confirm delivery. It is recorded in issueHistory and does not change the status. delivered with a deliveryReport can end as failed when the server reads the carrier status as a failure (see deliveryReport). unknown with errorCode SEND_INTERRUPTED means the app handed the message to the radio and has no result for it; a message that is still waiting becomes unknown and is not offered to the phone again. Any other value is rejected with 400.',
    enum: ['sent', 'delivered', 'failed', 'delivery_failed'],
  })
  status: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'The time the message was sent (in milliseconds)',
  })
  sentAtInMillis?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'The time the message was delivered (in milliseconds)',
  })
  deliveredAtInMillis?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'The time the message failed (in milliseconds)',
  })
  failedAtInMillis?: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'Error code if the message failed',
  })
  errorCode?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Error message if the message failed',
  })
  errorMessage?: string

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'When the device received the push for this message (in milliseconds)',
  })
  pushReceivedAtInMillis?: number

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'When the device handed this message to the radio (in milliseconds)',
  })
  sendAttemptedAtInMillis?: number

  @ApiProperty({
    type: SimUsedDTO,
    required: false,
    description:
      'The SIM the device used for this message. Can differ from the requested simSubscriptionId. Replaces the SIM stored for the message; an empty object clears it. Omit it to keep the stored SIM, and omit any field in it the device cannot tell.',
  })
  simUsed?: SimUsedDTO

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Subscription id of the SIM the device used for this message. Older form of simUsed.subscriptionId, which takes precedence when both are present.',
    example: 19,
  })
  simSubscriptionId?: number

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Zero-based slot of the SIM the device used for this message: 0 is SIM 1, 1 is SIM 2. Older form of simUsed.slotIndex, which takes precedence when both are present.',
    example: 1,
  })
  simSlotIndex?: number

  @ApiProperty({
    type: String,
    required: false,
    enum: SIM_SELECTIONS,
    description:
      'Why the device used that SIM. requested means the requested simSubscriptionId matched an active SIM. requested_invalid_fallback means the requested simSubscriptionId matched no active SIM, so the device fell back to the preferred SIM set in the textbee app, or the device default SIM. requested_slot means the device sent from the SIM in the requested simSlotIndex. requested_slot_empty means the requested slot had no active SIM, so the device did not send the message and reported it failed with SIM_SLOT_EMPTY. app_preferred and system_default mean the request named no SIM.',
    example: 'requested',
  })
  simSelection?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Which attempt of the device retry loop filed this report',
  })
  reportAttempt?: number

  @ApiProperty({
    type: 'integer',
    required: false,
    minimum: 0,
    description:
      'Zero-based index of the part this report is about. Sent with partCount. Ignored when it is not a whole number below partCount.',
    example: 0,
  })
  partIndex?: number

  @ApiProperty({
    type: 'integer',
    required: false,
    minimum: 1,
    maximum: 255,
    description:
      'Number of parts the device split the text into; 1 for a single-part message. A report with partCount is stored as a part report, and a failed part fails a message of more than one part. Omit it when the part is not known; the report then counts as one for the whole message. Ignored when it is not a whole number from 1 to 255.',
    example: 3,
  })
  partCount?: number

  @ApiProperty({
    type: 'integer',
    required: false,
    description:
      'The Android result code of the sent or delivered callback, unchanged. Ignored when it is not a whole number.',
    example: -1,
  })
  resultCode?: number

  @ApiProperty({
    type: 'integer',
    required: false,
    description:
      'The errorCode extra of a sent callback, when Android gives one. Ignored when it is not a whole number.',
    example: 0,
  })
  radioErrorCode?: number

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'true when the device uploaded this report on its own, one per part and callback. Omit it otherwise. Only true counts. The carrier verdict in deliveryReport is read only from such reports.',
    example: true,
  })
  perPartUpload?: boolean

  @ApiProperty({
    type: DeliveryReportDTO,
    required: false,
    description:
      'The carrier delivery report of a delivery callback. Sent with status delivered. Fields that do not match their type are ignored.',
  })
  deliveryReport?: DeliveryReportDTO
}

export class HeartbeatInputDTO {
  @ApiProperty({
    type: String,
    required: false,
    description: 'FCM token for push notifications',
  })
  fcmToken?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Battery percentage (0-100)',
  })
  batteryPercentage?: number

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether device is currently charging',
  })
  isCharging?: boolean

  @ApiProperty({
    type: String,
    required: false,
    description: 'Network type',
    enum: ['wifi', 'cellular', 'none'],
  })
  networkType?: 'wifi' | 'cellular' | 'none'

  @ApiProperty({
    type: String,
    required: false,
    description: 'App version name',
  })
  appVersionName?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'App version code',
  })
  appVersionCode?: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'Android release version, e.g. "16"',
  })
  osVersion?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Android SDK / API level, e.g. 36',
  })
  osApiLevel?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Device uptime in milliseconds since boot',
  })
  deviceUptimeMillis?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Free memory in bytes',
  })
  memoryFreeBytes?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Total memory in bytes',
  })
  memoryTotalBytes?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Max memory in bytes',
  })
  memoryMaxBytes?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Available storage in bytes',
  })
  storageAvailableBytes?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Total storage in bytes',
  })
  storageTotalBytes?: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'Device timezone (e.g., "America/New_York")',
  })
  timezone?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Device locale (e.g., "en_US")',
  })
  locale?: string

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether receive SMS feature is enabled',
  })
  receiveSMSEnabled?: boolean

  @ApiProperty({
    type: Number,
    required: false,
    description: 'SMS send delay in seconds (0-3600), used by device queue',
  })
  smsSendDelaySeconds?: number

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'Whether the app is exempt from battery optimization on the device.',
  })
  isIgnoringBatteryOptimizations?: boolean

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether the device was in Doze when it reported.',
  })
  isDeviceIdleMode?: boolean

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether battery saver was on when the device reported.',
  })
  isPowerSaveMode?: boolean

  @ApiProperty({ type: Boolean, required: false, description: 'SEND_SMS granted' })
  hasSendSmsPermission?: boolean

  @ApiProperty({ type: Boolean, required: false, description: 'RECEIVE_SMS granted' })
  hasReceiveSmsPermission?: boolean

  @ApiProperty({ type: Boolean, required: false, description: 'READ_PHONE_STATE granted' })
  hasReadPhoneStatePermission?: boolean

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'POST_NOTIFICATIONS granted. Always true below Android 13.',
  })
  hasPostNotificationsPermission?: boolean

  @ApiProperty({ type: Boolean, required: false, description: 'Sticky notification switched on' })
  stickyNotificationEnabled?: boolean

  @ApiProperty({ type: Boolean, required: false, description: 'Running the legacy UI' })
  usingLegacyUi?: boolean

  @ApiProperty({
    type: SimInfoCollectionDTO,
    required: false,
    description: 'SIMs installed in the device at the time of the heartbeat.',
  })
  simInfo?: SimInfoCollectionDTO

  @ApiProperty({ type: String, required: false, description: 'Random id of this app install' })
  installId?: string

  @ApiProperty({ type: Boolean, required: false, description: 'The app can claim messages from the server' })
  pullCapable?: boolean

  @ApiProperty({ type: Number, required: false, description: 'Time of the last message push the app received, in epoch milliseconds' })
  lastPushReceivedAt?: number

  @ApiProperty({ type: Number, required: false, description: 'Repeated messages the app has skipped since install' })
  dedupeSkipCount?: number

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Package name of the app that installed the textbee app, as Android reports it. An empty string means Android has no installer name. Omit it when the app cannot read it. A value that is not a package name is ignored.',
  })
  installerPackage?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Package name of the app that started the install, as Android 11 and up reports it. A value that is not a package name is ignored.',
  })
  initiatingPackage?: string

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'When the installed textbee app build was installed or last updated, in epoch milliseconds. A value that is not a whole number or not a plausible time is ignored.',
  })
  appLastUpdateTime?: number

  @ApiProperty({
    type: [String],
    required: false,
    maxItems: 200,
    items: { type: 'string', pattern: '^[A-Za-z0-9._-]{1,40}$' },
    description:
      'Ids of the notices the user closed on this phone, newest last. The server keeps the ids that have 1 to 40 letters, digits, dots, dashes and underscores, in order, and stores the last 50 of them. Other entries are dropped. A list with no valid id, or an empty list, stores an empty list. A list of more than 200 entries, or a value that is not a list, is ignored and the stored list stays. Omit it to keep the stored list. The heartbeat never fails because of this field.',
    example: ['update-22-2026-46'],
  })
  closedNoticeIds?: string[]
}

export class ClaimMessagesInputDTO {
  @ApiProperty({ type: Number, required: false, description: 'Most messages to return, 1 to 25' })
  limit?: number

  @ApiProperty({ type: String, required: false, description: 'What made the app ask, for example heartbeat or timer' })
  source?: string

  @ApiProperty({ type: String, required: true, description: 'Random id of this app install' })
  installId: string
}

export class DeviceConfigTuningDTO {
  @ApiProperty({ type: Number, description: 'Shortest time in seconds between two claims, 10 to 300' })
  claimMinGapSeconds: number

  @ApiProperty({
    type: Number,
    description: 'Seconds before the retry job behind a direct upload starts, 30 to 3600',
  })
  directUploadRetryDelaySeconds: number

  @ApiProperty({
    type: Number,
    description: 'Minutes a sending marker counts as in flight, 3 to 60',
  })
  sendingMarkerYoungMinutes: number
}

export class DeviceConfigNoticeDTO {
  @ApiProperty({
    type: String,
    description: 'Id of the notice, up to 40 letters, digits, dots, dashes and underscores. A closed notice stays closed for this id.',
  })
  id: string

  @ApiProperty({
    type: String,
    enum: ['info', 'warning', 'error'],
    description: 'How the banner looks: grey for info, amber for warning, red for error',
  })
  level: 'info' | 'warning' | 'error'

  @ApiProperty({
    type: String,
    required: false,
    description: 'Bold first line of the banner, 1 to 60 characters, one line. Missing when the notice has no title.',
  })
  title?: string

  @ApiProperty({ type: String, description: 'Text of the banner, 1 to 200 characters, one line' })
  text: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Label of the button, up to 30 characters. Sent only together with actionUrl.',
  })
  actionLabel?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'What the button opens: an https link, or one of the app screens textbee://device-health, textbee://add-api-key and textbee://battery-settings. Sent only together with actionLabel.',
  })
  actionUrl?: string

  @ApiProperty({ type: Boolean, description: 'Whether the user can close the banner' })
  dismissible: boolean

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Hours, 1 to 8760, after which the app hides the notice when it has had no reply from the server. Missing means no limit.',
  })
  maxAgeHours?: number

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'When true, the app also shows the notice once as a silent system notification. Sent only when true.',
  })
  notify?: boolean
}

export class DeviceConfigDTO {
  @ApiProperty({ type: Boolean, description: 'Use the per-message send scheduler' })
  sendSchedulerV2Enabled: boolean

  @ApiProperty({ type: Boolean, description: 'Ask the server for missed messages' })
  recoveryPollEnabled: boolean

  @ApiProperty({ type: Boolean, description: 'Show a notification when a newer app exists' })
  updateNotificationsEnabled: boolean

  @ApiProperty({
    type: Boolean,
    description: 'Upload status reports and received messages directly, with the background queue as the retry',
  })
  directUploadEnabled: boolean

  @ApiProperty({ type: Boolean, description: 'Claim waiting messages from the server' })
  pullEnabled: boolean

  @ApiProperty({
    type: Boolean,
    description: 'Upload one status report per part and callback, with partIndex and partCount',
  })
  partReportsEnabled: boolean

  @ApiProperty({ type: Number, description: 'versionCode of the latest release' })
  latestVersionCode: number

  @ApiProperty({ type: String, description: 'versionName of the latest release' })
  latestVersionName: string

  @ApiProperty({
    type: Number,
    description: 'Minutes between runs of the background job that sends the heartbeat, 15 to 240',
  })
  periodicJobMinutes: number

  @ApiProperty({ type: Number, description: 'Most entries kept in the activity log, 500 to 20000' })
  deviceLogMaxEntries: number

  @ApiProperty({ type: Boolean, description: 'Collect app usage analytics' })
  analyticsEnabled: boolean

  @ApiProperty({ type: DeviceConfigTuningDTO, description: 'Timings of the send and upload paths' })
  tuning: DeviceConfigTuningDTO

  @ApiProperty({
    type: [DeviceConfigNoticeDTO],
    description:
      'Banners for the home screen, in display order. The unsupported build banner comes first when it applies. Then come the notices for this device, or else the notices for all devices (up to 5, in priority order). When an update is available, its banner comes after the first two of those notices, so it is always among the first three. The update banner is left out when the unsupported banner is sent. No two banners share an id. Empty when none applies.',
  })
  notices: DeviceConfigNoticeDTO[]
}

export class HeartbeatResponseDTO {
  @ApiProperty({
    type: Boolean,
    required: true,
    description: 'Whether the heartbeat was successful',
  })
  success: boolean

  @ApiProperty({
    type: Boolean,
    required: true,
    description: 'Whether the FCM token was updated',
  })
  fcmTokenUpdated: boolean

  @ApiProperty({
    type: Date,
    required: true,
    description: 'Server timestamp of the heartbeat',
  })
  lastHeartbeat: Date

  @ApiProperty({
    type: String,
    required: false,
    description: 'Device name (if updated)',
  })
  name?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Messages waiting for this device that a push may have missed',
  })
  pendingCount?: number

  @ApiProperty({
    type: DeviceConfigDTO,
    required: false,
    description: 'Settings the app applies until the next heartbeat',
  })
  config?: DeviceConfigDTO
}

export class GatewayStatsDTO {
  @ApiProperty({
    type: Number,
    description: 'Messages sent across all your devices.',
  })
  totalSentSMSCount: number

  @ApiProperty({
    type: Number,
    description: 'Messages received across all your devices.',
  })
  totalReceivedSMSCount: number

  @ApiProperty({ type: Number, description: 'Devices on your account.' })
  totalDeviceCount: number

  @ApiProperty({ type: Number, description: 'API keys on your account.' })
  totalApiKeyCount: number
}

export class GatewayStatsResponseDTO {
  @ApiProperty({ type: GatewayStatsDTO, description: 'Account totals.' })
  data: GatewayStatsDTO
}

export class SmsPermissionStatusDTO {
  @ApiProperty({
    type: Boolean,
    nullable: true,
    description:
      'True when your latest outgoing message failed because the textbee app on the phone lacks the SMS permission (error code PERMISSION_DENIED) and the phone has not reported the permission granted since, or when an enabled phone reported the SMS permission off in a heartbeat within the last 7 days. False when neither applies. Null when the account has never sent a message and no phone reports the permission off.',
  })
  needsSmsPermission: boolean | null

  @ApiProperty({
    type: Number,
    nullable: true,
    description:
      'Whole hours since that failure. Null unless source is failure.',
  })
  hoursSinceFailure: number | null

  @ApiProperty({
    type: String,
    nullable: true,
    description:
      'Id of the device that reported the failure, or the missing permission in a heartbeat. Null unless needsSmsPermission is true.',
  })
  deviceId: string | null

  @ApiProperty({
    type: String,
    nullable: true,
    description:
      'Name of that device, or its brand and model when it has no name. Null unless needsSmsPermission is true.',
  })
  deviceName: string | null

  @ApiProperty({
    type: Date,
    nullable: true,
    description:
      'When the server received the failure report from the phone. Null unless source is failure.',
  })
  failedAt: Date | null

  @ApiProperty({
    type: String,
    nullable: true,
    enum: ['failure', 'heartbeat'],
    description:
      'Why needsSmsPermission is true. failure: your latest outgoing message failed because the permission is missing. heartbeat: the phone reports the permission as off, and no message has failed for it yet. Null unless needsSmsPermission is true.',
  })
  source: 'failure' | 'heartbeat' | null
}

export class SmsPermissionStatusResponseDTO {
  @ApiProperty({
    type: SmsPermissionStatusDTO,
    description: 'Whether a missing SMS permission is blocking your sends.',
  })
  data: SmsPermissionStatusDTO
}

export class DeviceListResponseDTO {
  @ApiProperty({ type: [DeviceDTO], description: 'Your devices.' })
  data: DeviceDTO[]
}

export class DeviceResponseDTO {
  @ApiProperty({ type: DeviceDTO, description: 'The device.' })
  data: DeviceDTO
}

export class SuccessResultDTO {
  @ApiProperty({ type: Boolean, description: 'Whether the action succeeded.' })
  success: boolean
}

export class SuccessResponseDTO {
  @ApiProperty({ type: SuccessResultDTO, description: 'Outcome of the action.' })
  data: SuccessResultDTO
}

export class SendSMSWarningDTO {
  @ApiProperty({
    type: String,
    description:
      'Machine readable warning code. SMS_PERMISSION_MISSING: the textbee app on the sending phone last reported the SMS permission as off. The message is queued, and it fails if the permission is still off.',
    example: 'SMS_PERMISSION_MISSING',
  })
  code: string

  @ApiProperty({
    type: String,
    description: 'Human readable explanation of the warning.',
    example:
      'The textbee app on this phone last reported the SMS permission as off. The message fails if it is still off.',
  })
  message: string
}

export class SendSMSResultDTO {
  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether the batch was accepted. Queued sends only.',
  })
  success?: boolean

  @ApiProperty({
    type: String,
    required: false,
    description: 'Human readable outcome. Queued sends only.',
    example: 'SMS added to queue for processing',
  })
  message?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Batch id. Pass it to GET /gateway/devices/{id}/sms-batch/{smsBatchId} to follow delivery. Queued sends only.',
  })
  smsBatchId?: string

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Number of recipients in the batch. Queued sends only.',
  })
  recipientCount?: number

  @ApiProperty({
    type: String,
    required: false,
    format: 'date-time',
    description:
      'Projected time the device finishes sending, based on the recipient count, the messages already queued for the same device, and the device send delay setting. Present when the batch is released in waves or waits for messages already queued for the device. The device must stay online for the estimate to hold.',
    example: '2026-08-22T14:05:00.000Z',
  })
  estimatedCompletionAt?: string

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Messages pushed to the device. Returned instead of the queue fields when the instance dispatches immediately.',
  })
  successCount?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Messages that could not be pushed to the device.',
  })
  failureCount?: number

  @ApiProperty({
    type: SendSMSWarningDTO,
    required: false,
    description:
      'Present when the message was accepted but is likely to fail, for example because the phone reported the SMS permission off in the last 7 days. Set for single sends only, not for bulk sends.',
  })
  warning?: SendSMSWarningDTO
}

export class SendSMSResponseDTO {
  @ApiProperty({ type: SendSMSResultDTO, description: 'Outcome of the send.' })
  data: SendSMSResultDTO
}

export class SMSResponseDTO {
  @ApiProperty({ type: RetrieveSMSDTO, description: 'The message.' })
  data: RetrieveSMSDTO
}

export class SMSBatchDTO {
  @ApiProperty({ type: String, description: 'Batch id.' })
  _id: string

  @ApiProperty({ type: String, description: 'Owner account id.' })
  user: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Message text sent to every recipient in the batch.',
  })
  message?: string

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether the body is end to end encrypted.',
  })
  encrypted?: boolean

  @ApiProperty({ type: Number, description: 'Recipients in the batch.' })
  recipientCount: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'Short preview of the recipient list.',
    example: '+12025550123 and 3 others',
  })
  recipientPreview?: string

  @ApiProperty({
    type: Number,
    description:
      'Messages the phone reported as sent or delivered. Equals sentCount plus deliveredCount.',
    example: 3,
  })
  successCount: number

  @ApiProperty({
    type: Number,
    description:
      'Messages that failed, either on the phone or before they reached it.',
    example: 1,
  })
  failureCount: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Messages not yet handed to the phone. Paced and scheduled messages wait here.',
    example: 0,
  })
  pendingCount?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Messages handed to the phone that have not reported a result yet.',
    example: 0,
  })
  dispatchedCount?: number

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Messages the phone sent that have no delivery report yet. A message moves to deliveredCount when its delivery report arrives.',
    example: 1,
  })
  sentCount?: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Messages with a delivery report from the carrier.',
    example: 2,
  })
  deliveredCount?: number

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'Messages with no result: the phone did not report back in time, or the state is one textbee does not recognize. A late report still updates the message and the batch.',
    example: 0,
  })
  unknownCount?: number

  @ApiProperty({
    type: String,
    required: false,
    nullable: true,
    enum: [
      'pending',
      'processing',
      'completed',
      'partial_success',
      'failed',
      'unknown',
      'sent',
      'delivered',
    ],
    description:
      'Outcome of the batch, calculated from its messages. processing: at least one message is pending or dispatched. completed: every message was sent or delivered. failed: every message failed. partial_success: some were sent or delivered, the rest failed or are unknown. unknown: none was sent and at least one is unknown, or the batch has no messages. pending: the batch was created and no message was queued yet. sent and delivered appear only on old batches that have no messages.',
    example: 'partial_success',
  })
  status?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Error from the last failed attempt to hand the batch to the phone. It can be present on a batch that later sent some messages.',
  })
  error?: string

  @ApiProperty({
    type: Date,
    required: false,
    description:
      'When the batch reached its current final status. Absent while the batch is processing.',
  })
  completedAt?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When the status and counts were last calculated from the messages.',
  })
  statusCheckedAt?: Date

  @ApiProperty({ type: Date, description: 'When the batch was created.' })
  createdAt: Date

  @ApiProperty({ type: Date, description: 'When the batch was last updated.' })
  updatedAt: Date
}

export class SMSBatchResultDTO {
  @ApiProperty({ type: SMSBatchDTO, description: 'The batch itself.' })
  batch: SMSBatchDTO

  @ApiProperty({
    type: [RetrieveSMSDTO],
    description: 'Every message in the batch, one per recipient.',
  })
  messages: RetrieveSMSDTO[]
}

export class SMSBatchResponseDTO {
  @ApiProperty({
    type: SMSBatchResultDTO,
    description: 'The batch and the messages in it.',
  })
  data: SMSBatchResultDTO
}
