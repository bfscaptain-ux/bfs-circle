import { Types } from 'mongoose'
import { RECOVERY_MIN_VERSION_CODE } from './device-config'
import { FCM_SEND_SKIPPED_ERROR_CODE } from './fcm-send-skip'
import { HANDED_BY_PUSH } from './push-ownership'
import { simPayloadFor, StoredSimRequest } from './sim-request'
import { SMSType } from './sms-type.enum'

// A message the phone may have missed: outbound, still waiting, old enough
// that its push is not just slow, young enough to still be wanted, and not
// handed out too many times already. It must also have been queued for a
// build that remembers what it sent, so an older build's send is never repeated.
export const REDISPATCH_AFTER_MS = 30 * 60 * 1000
export const RECOVERY_WINDOW_MS = 72 * 60 * 60 * 1000
export const MAX_DISPATCH_ATTEMPTS = 3
export const CLAIM_LIMIT = 25
export const POLL_COOLDOWN_MS = 5 * 60 * 1000
export const CLAIM_COOLDOWN_MS = 3 * 1000

// installId is set for a claim through the new endpoint. A message already
// handed to one install is never offered to another.
export function pendingRecoveryFilter(
  deviceId: string,
  now: Date = new Date(),
  installId?: string,
) {
  const redispatchBefore = new Date(now.getTime() - REDISPATCH_AFTER_MS)
  const windowStart = new Date(now.getTime() - RECOVERY_WINDOW_MS)
  // No claim time on the row: wait until its push is overdue
  const byPushAge = {
    'metadata.claimableAt': { $exists: false },
    $and: [
      {
        $or: [
          { dispatchedAt: { $lt: redispatchBefore } },
          {
            dispatchedAt: { $exists: false },
            requestedAt: { $lt: redispatchBefore },
          },
        ],
      },
      // A paced row is left to its own queue job until it is as overdue as a push
      {
        $or: [
          { dispatchDueAt: { $exists: false } },
          { dispatchDueAt: { $lte: redispatchBefore } },
        ],
      },
    ],
  }
  return {
    device: Types.ObjectId.isValid(deviceId) ? new Types.ObjectId(deviceId) : deviceId,
    type: SMSType.SENT,
    status: { $in: ['pending', 'dispatched', 'unknown'] as const },
    requestedAt: { $gte: windowStart },
    'metadata.appVersionCode': { $gte: RECOVERY_MIN_VERSION_CODE },
    // A withheld push is never handed out another way
    errorCode: { $ne: FCM_SEND_SKIPPED_ERROR_CODE },
    $and: [
      {
        $or: [
          // The row says when it may be taken
          { 'metadata.claimableAt': { $lte: now } },
          // An install takes only rows that carry a claim time. A row without
          // one was pushed with no record of who got it.
          ...(installId ? [] : [byPushAge]),
        ],
      },
      {
        $or: [
          { dispatchAttempts: { $exists: false } },
          { dispatchAttempts: { $lt: MAX_DISPATCH_ATTEMPTS } },
        ],
      },
      {
        $or: [
          { 'metadata.handedTo': { $exists: false } },
          { 'metadata.handedTo': installId ?? HANDED_BY_PUSH },
        ],
      },
    ],
  }
}

// The same shape the push carries, so the app treats both alike
export function toRecoveryPayload(sms: {
  _id: Types.ObjectId
  smsBatch?: unknown
  message?: string
  recipient?: string
} & StoredSimRequest) {
  const batch = (sms.smsBatch as { _id?: unknown })?._id ?? sms.smsBatch
  return {
    smsId: String(sms._id),
    smsBatchId: batch ? String(batch) : undefined,
    message: sms.message,
    recipients: [sms.recipient],
    ...simPayloadFor(sms),
  }
}
