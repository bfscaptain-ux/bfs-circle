import { HttpException } from '@nestjs/common'
import * as crypto from 'crypto'
import axios from 'axios'
import * as dns from 'dns'
import {
  NOTIFICATION_DEVICE_FIELDS,
  WebhookService,
  redactDeliveryUrl,
} from './webhook.service'
import { DEVICE_HIDDEN_FIELDS } from '../gateway/schemas/device.schema'
import { WebhookEvent } from './webhook-event.enum'
import { Types } from 'mongoose'

jest.mock('axios')
jest.mock('dns')
const mockedAxios = axios as jest.Mocked<typeof axios>
const mockedDnsLookup = dns.lookup as unknown as jest.Mock

const build = () => {
  const webhookSubscriptionModel: any = {
    findById: jest.fn(),
    findOne: jest.fn(),
    countDocuments: jest.fn(),
    create: jest.fn(),
    updateOne: jest.fn().mockResolvedValue(undefined),
  }
  const webhookNotificationModel: any = { findOneAndUpdate: jest.fn() }
  const billingService: any = {
    getUserLimits: jest.fn().mockResolvedValue({ webhookLimit: 5 }),
  }

  const service = new WebhookService(
    webhookSubscriptionModel,
    webhookNotificationModel,
    {} as any, // webhookQueueService
    {} as any, // mailService
    {} as any, // usersService
    billingService,
  )

  return {
    service,
    webhookSubscriptionModel,
    webhookNotificationModel,
    billingService,
  }
}

describe('redactDeliveryUrl', () => {
  it('drops userinfo and the query string', () => {
    expect(redactDeliveryUrl('https://user:pass@example.com/hook?token=secret')).toBe(
      'https://example.com/hook',
    )
  })

  it('keeps origin and path when there is nothing sensitive', () => {
    expect(redactDeliveryUrl('https://example.com/hook')).toBe(
      'https://example.com/hook',
    )
  })

  it('returns a placeholder for an unparseable url', () => {
    expect(redactDeliveryUrl('not-a-url')).toBe('[unparseable url]')
  })

  it('returns an empty string for an empty url', () => {
    expect(redactDeliveryUrl('')).toBe('')
  })
})

describe('WebhookService', () => {
  beforeEach(() => jest.clearAllMocks())

  describe('validateDeliveryUrl (SSRF guard)', () => {
    const validate = (service: WebhookService, url: string) =>
      (service as any).validateDeliveryUrl(url)

    it('accepts a normal https URL', () => {
      const { service } = build()
      expect(() => validate(service, 'https://example.com/hook')).not.toThrow()
    })

    it.each([
      'ftp://example.com/hook',
      'file:///etc/passwd',
      'not-a-url',
    ])('rejects a non-http(s) or malformed URL: %s', (url) => {
      const { service } = build()
      expect(() => validate(service, url)).toThrow(HttpException)
    })

    it.each([
      'http://localhost/hook',
      'http://127.0.0.1/hook',
      'http://10.0.0.5/hook',
      'http://192.168.1.10/hook',
      'http://169.254.169.254/latest/meta-data', // cloud metadata IP
      'http://172.16.0.1/hook',
      'http://[::ffff:7f00:1]/hook', // hex IPv4-mapped loopback
      'http://[::ffff:127.0.0.1]/hook',
      'http://[fe81::1]/hook',
      'http://[febf::1]/hook',
      'http://0.0.0.0/hook',
      'http://224.0.0.1/hook',
    ])('rejects a private or loopback host: %s', (url) => {
      const { service } = build()
      expect(() => validate(service, url)).toThrow(HttpException)
    })
  })

  describe('isBlockedIpAddress', () => {
    const blocked = (service: WebhookService, ip: string) =>
      (service as any).isBlockedIpAddress(ip)

    it.each([
      '10.0.0.5',
      '127.0.0.1',
      '169.254.169.254',
      '172.16.0.1',
      '192.168.1.10',
      '100.64.0.1',
      '::1',
      'fe80::1',
      'fd00::1',
      '::ffff:127.0.0.1',
      '::ffff:7f00:1',
      '::ffff:a00:1',
      'fe81::1',
      'febf:ffff::1',
      'fc00::1',
      'fec0::1',
      'feff:ffff::1',
      '198.18.0.0',
      '198.19.255.255',
    ])('blocks private, loopback or link-local address: %s', (ip) => {
      const { service } = build()
      expect(blocked(service, ip)).toBe(true)
    })

    it.each([
      '8.8.8.8',
      '1.1.1.1',
      '93.184.216.34',
      '::ffff:808:808',
      'fe7f::1',
      '198.17.255.255',
      '198.20.0.0',
      '2606:4700::1',
      'example.com',
    ])(
      'allows a public address: %s',
      (ip) => {
        const { service } = build()
        expect(blocked(service, ip)).toBe(false)
      },
    )
  })

  describe('guardedLookup (connection-time DNS guard)', () => {
    const resolveTo = (addresses: { address: string; family: number }[]) =>
      mockedDnsLookup.mockImplementation((_host, _opts, cb) =>
        cb(null, addresses),
      )

    it('refuses a connection when the hostname resolves to a private address', (done) => {
      const { service } = build()
      resolveTo([{ address: '10.99.0.50', family: 4 }])
      ;(service as any).guardedLookup('internal.example.com', {}, (err: any) => {
        expect(err).toBeInstanceOf(Error)
        done()
      })
    })

    it('allows a connection when the hostname resolves to a public address', (done) => {
      const { service } = build()
      resolveTo([{ address: '93.184.216.34', family: 4 }])
      ;(service as any).guardedLookup(
        'example.com',
        {},
        (err: any, address: string, family: number) => {
          expect(err).toBeNull()
          expect(address).toBe('93.184.216.34')
          expect(family).toBe(4)
          done()
        },
      )
    })

    it('returns address records when the caller asks for all addresses', (done) => {
      const { service } = build()
      resolveTo([
        { address: '93.184.216.34', family: 4 },
        { address: '2606:2800:220:1::1', family: 6 },
      ])
      ;(service as any).guardedLookup(
        'example.com',
        { all: true },
        (err: any, addresses: { address: string; family: number }[]) => {
          expect(err).toBeNull()
          expect(addresses).toEqual([
            { address: '93.184.216.34', family: 4 },
            { address: '2606:2800:220:1::1', family: 6 },
          ])
          done()
        },
      )
    })

    it('refuses when any resolved address is private (rebinding across records)', (done) => {
      const { service } = build()
      resolveTo([
        { address: '93.184.216.34', family: 4 },
        { address: '127.0.0.1', family: 4 },
      ])
      ;(service as any).guardedLookup('mixed.example.com', {}, (err: any) => {
        expect(err).toBeInstanceOf(Error)
        done()
      })
    })
  })

  describe('signing secret validation', () => {
    it('rejects a create with a secret shorter than 20 characters', async () => {
      const { service } = build()
      await expect(
        service.create({
          user: { _id: 'user_1' },
          createWebhookDto: {
            name: 'w',
            events: ['message.received'],
            deliveryUrl: 'https://example.com/hook',
            signingSecret: 'too-short',
          },
        }),
      ).rejects.toThrow(HttpException)
    })

    it('rejects an update that sets a secret shorter than 20 characters', async () => {
      const { service, webhookSubscriptionModel } = build()
      webhookSubscriptionModel.findOne.mockResolvedValue({
        signingSecret: 'a'.repeat(20),
        save: jest.fn(),
      })

      await expect(
        service.update({
          user: { _id: 'user_1' },
          webhookId: 'wh_1',
          updateWebhookDto: { signingSecret: 'short' },
        }),
      ).rejects.toThrow(HttpException)
    })
  })

  describe('webhook subscription limit', () => {
    const createDto = {
      name: 'w',
      events: [WebhookEvent.MESSAGE_RECEIVED],
      deliveryUrl: 'https://example.com/hook',
      signingSecret: 'a'.repeat(20),
    }
    const user = { _id: '507f1f77bcf86cd799439011' }

    const setup = (limits: any, existingCount: number) => {
      const built = build()
      if (limits instanceof Error) {
        built.billingService.getUserLimits.mockRejectedValue(limits)
      } else {
        built.billingService.getUserLimits.mockResolvedValue(limits)
      }
      built.webhookSubscriptionModel.countDocuments.mockResolvedValue(
        existingCount,
      )
      built.webhookSubscriptionModel.create.mockResolvedValue({ _id: 'ws_new' })
      return built
    }

    const originalEnv = process.env.MAX_WEBHOOKS_PER_USER
    afterEach(() => {
      jest.restoreAllMocks()
      if (originalEnv === undefined) delete process.env.MAX_WEBHOOKS_PER_USER
      else process.env.MAX_WEBHOOKS_PER_USER = originalEnv
    })

    it('blocks a create at the limit with a 400 and a clear message', async () => {
      const { service, webhookSubscriptionModel } = setup({ webhookLimit: 10 }, 10)

      const error = await service
        .create({ user, createWebhookDto: createDto })
        .catch((e) => e)

      expect(error).toBeInstanceOf(HttpException)
      expect(error.getStatus()).toBe(400)
      expect(error.getResponse()).toMatchObject({
        message:
          'Your plan allows up to 10 webhook subscriptions and you have 10. Delete one, upgrade your plan, or contact support@textbee.dev for a higher limit.',
        hasReachedLimit: true,
        webhookLimit: 10,
        webhookCount: 10,
      })
      expect(webhookSubscriptionModel.create).not.toHaveBeenCalled()
    })

    it('allows a create below the limit', async () => {
      const { service, webhookSubscriptionModel, billingService } = setup(
        { webhookLimit: 10 },
        9,
      )

      await service.create({ user, createWebhookDto: createDto })

      expect(billingService.getUserLimits).toHaveBeenCalledWith(user._id)
      expect(webhookSubscriptionModel.countDocuments).toHaveBeenCalledWith({
        user: user._id,
        deletedAt: null,
      })
      expect(webhookSubscriptionModel.create).toHaveBeenCalledTimes(1)
    })

    it('does not cap the limit at 25', async () => {
      const { service, webhookSubscriptionModel } = setup({ webhookLimit: 100 }, 60)

      await service.create({ user, createWebhookDto: createDto })

      expect(webhookSubscriptionModel.create).toHaveBeenCalledTimes(1)
    })

    it('treats -1 as unlimited', async () => {
      const { service, webhookSubscriptionModel } = setup({ webhookLimit: -1 }, 500)

      await service.create({ user, createWebhookDto: createDto })

      expect(webhookSubscriptionModel.create).toHaveBeenCalledTimes(1)
    })

    it('returns 503 and creates nothing when the limit lookup fails', async () => {
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
      const { service, webhookSubscriptionModel } = setup(new Error('db down'), 3)

      const error = await service
        .create({ user, createWebhookDto: createDto })
        .catch((e) => e)

      expect(error).toBeInstanceOf(HttpException)
      expect(error.getStatus()).toBe(503)
      expect(error.message).toBe('Could not check your webhook limit. Please try again.')
      expect(webhookSubscriptionModel.create).not.toHaveBeenCalled()
    })
  })

  describe('findWebhookNotificationsForUser', () => {
    const setup = () => {
      const built = build()
      built.webhookSubscriptionModel.distinct = jest
        .fn()
        .mockResolvedValue([new Types.ObjectId('664a9b8cd0e1f2a3b4c5d6e7')])
      built.webhookNotificationModel.countDocuments = jest
        .fn()
        .mockResolvedValue(0)
      built.webhookNotificationModel.aggregate = jest.fn().mockResolvedValue([])
      return built
    }

    it('removes signing secrets from each page', async () => {
      const { service, webhookNotificationModel } = setup()

      await service.findWebhookNotificationsForUser({ user: { _id: 'user_1' } })

      const pipeline = webhookNotificationModel.aggregate.mock.calls[0][0]
      expect(pipeline[pipeline.length - 1]).toEqual({
        $project: { 'webhookSubscriptionData.signingSecret': 0 },
      })
    })

    it('joins only the name, brand and model of the device', async () => {
      const { service, webhookNotificationModel } = setup()

      await service.findWebhookNotificationsForUser({ user: { _id: 'user_1' } })

      const pipeline = webhookNotificationModel.aggregate.mock.calls[0][0]
      const deviceLookup = pipeline.find(
        (stage: any) => stage.$lookup?.from === 'devices',
      ).$lookup
      expect(deviceLookup.as).toBe('deviceData')
      expect(deviceLookup.pipeline).toEqual([
        { $project: { _id: 0, name: 1, brand: 1, model: 1 } },
      ])
      // An inclusion projection: no other device field, hidden or new, comes through
      const kept = Object.entries(NOTIFICATION_DEVICE_FIELDS)
        .filter(([, include]) => include === 1)
        .map(([field]) => field)
      for (const field of DEVICE_HIDDEN_FIELDS) {
        expect(kept).not.toContain(field)
      }
    })

    it('pages before the lookups and counts with the same filter', async () => {
      const { service, webhookNotificationModel } = setup()
      webhookNotificationModel.countDocuments.mockResolvedValue(25)

      const result = await service.findWebhookNotificationsForUser({
        user: { _id: 'user_1' },
        page: 2,
        limit: 10,
        status: 'failed',
        deviceId: '664a9b8cd0e1f2a3b4c5d6e8',
      })

      const pipeline = webhookNotificationModel.aggregate.mock.calls[0][0]
      const stages = pipeline.map((stage: any) => Object.keys(stage)[0])
      expect(stages.slice(0, 5)).toEqual([
        '$match',
        '$sort',
        '$skip',
        '$limit',
        '$lookup',
      ])
      expect(pipeline[1].$sort).toEqual({ createdAt: -1, _id: -1 })
      expect(pipeline[2].$skip).toBe(10)

      const filter = webhookNotificationModel.countDocuments.mock.calls[0][0]
      expect(pipeline[0].$match).toBe(filter)
      expect(filter.deliveredAt).toBeNull()
      expect(filter.$or).toEqual([
        { deliveryAttemptAbortedAt: { $ne: null } },
        { deliveryAttemptCount: { $gte: 10 } },
      ])
      expect(String(filter['payload.deviceId'])).toBe('664a9b8cd0e1f2a3b4c5d6e8')
      expect(result.meta).toEqual({ page: 2, limit: 10, total: 25, totalPages: 3 })
    })

    it('returns an empty page for an unknown status without querying', async () => {
      const { service, webhookNotificationModel } = setup()

      const result = await service.findWebhookNotificationsForUser({
        user: { _id: 'user_1' },
        status: 'bogus',
      })

      expect(result).toEqual({
        data: [],
        meta: { page: 1, limit: 10, total: 0, totalPages: 0 },
      })
      expect(webhookNotificationModel.aggregate).not.toHaveBeenCalled()
      expect(webhookNotificationModel.countDocuments).not.toHaveBeenCalled()
    })

    it('treats an inherited property name as an unknown status', async () => {
      const { service, webhookNotificationModel } = setup()

      const result = await service.findWebhookNotificationsForUser({
        user: { _id: 'user_1' },
        status: 'constructor',
      })

      expect(result.meta.total).toBe(0)
      expect(webhookNotificationModel.countDocuments).not.toHaveBeenCalled()
    })

    it('rejects an eventType that is not a known event name', async () => {
      const { service, webhookNotificationModel } = setup()

      for (const eventType of [{ $ne: null } as any, 'NOT_AN_EVENT']) {
        const error = await service
          .findWebhookNotificationsForUser({ user: { _id: 'user_1' }, eventType })
          .catch((e) => e)
        expect(error).toBeInstanceOf(HttpException)
        expect(error.getStatus()).toBe(400)
      }
      expect(webhookNotificationModel.countDocuments).not.toHaveBeenCalled()
    })
  })

  describe('attemptWebhookDelivery', () => {
    const activeSubscription = (overrides: Record<string, unknown> = {}) => ({
      _id: 'ws_1',
      isActive: true,
      deletedAt: null,
      deliveryUrl: 'https://example.com/hook',
      signingSecret: 'a-signing-secret-of-enough-length',
      ...overrides,
    })

    const notification = (): any => ({
      _id: 'wn_1',
      webhookSubscription: 'ws_1',
      payload: { hello: 'world' },
      deliveryAttemptCount: 0,
      save: jest.fn().mockResolvedValue(undefined),
    })

    it('signs the payload with HMAC-SHA256 of the signing secret', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      const sub = activeSubscription()
      const notif = notification()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
      webhookSubscriptionModel.findById.mockResolvedValue(sub)
      mockedAxios.post.mockResolvedValue({ status: 200, data: 'ok' })

      await service.attemptWebhookDelivery('wn_1')

      const expected = crypto
        .createHmac('sha256', sub.signingSecret)
        .update(JSON.stringify(notif.payload))
        .digest('hex')

      expect(mockedAxios.post).toHaveBeenCalledTimes(1)
      const [, , config] = mockedAxios.post.mock.calls[0]
      expect((config as any).headers['X-Signature']).toBe(expected)
    })

    describe('timestamped signature', () => {
      const deliver = async () => {
        const { service, webhookSubscriptionModel, webhookNotificationModel } =
          build()
        const sub = activeSubscription()
        const notif = notification()
        webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
        webhookSubscriptionModel.findById.mockResolvedValue(sub)
        mockedAxios.post.mockResolvedValue({ status: 200, data: 'ok' })

        await service.attemptWebhookDelivery('wn_1')

        const [, body, config] = mockedAxios.post.mock.calls[0]
        return { sub, notif, body, headers: (config as any).headers, config: config as any }
      }

      afterEach(() => jest.restoreAllMocks())

      it('sends X-Textbee-Timestamp and X-Textbee-Signature', async () => {
        jest
          .spyOn(Date, 'now')
          .mockReturnValue(Date.parse('2026-11-05T12:00:00.000Z'))
        const { headers } = await deliver()

        const t = String(Date.parse('2026-11-05T12:00:00.000Z') / 1000)
        expect(headers['X-Textbee-Timestamp']).toBe(t)
        expect(headers['X-Textbee-Signature']).toMatch(
          new RegExp(`^t=${t},v1=[0-9a-f]{64}$`),
        )
      })

      it('v1 is the HMAC-SHA256 of "<t>.<body>" with the signing secret', async () => {
        const { sub, body, headers } = await deliver()

        const [tPart, v1Part] = headers['X-Textbee-Signature'].split(',')
        const t = tPart.slice('t='.length)
        const v1 = v1Part.slice('v1='.length)
        const expected = crypto
          .createHmac('sha256', sub.signingSecret)
          .update(`${t}.${body}`)
          .digest('hex')

        expect(t).toBe(headers['X-Textbee-Timestamp'])
        expect(v1).toBe(expected)
      })

      it('keeps the legacy X-Signature as the HMAC of the body alone', async () => {
        const { sub, body, headers } = await deliver()

        expect(headers['X-Signature']).toBe(
          crypto
            .createHmac('sha256', sub.signingSecret)
            .update(body as string)
            .digest('hex'),
        )
      })

      it('posts the exact signed string as a JSON body', async () => {
        const { notif, body, headers, config } = await deliver()

        expect(typeof body).toBe('string')
        expect(body).toBe(JSON.stringify(notif.payload))
        expect(headers['Content-Type']).toBe('application/json')
        // axios must pass the string through without re-serializing it
        for (const transform of config.transformRequest) {
          expect(transform(body, {})).toBe(body)
        }
      })

      it('signs each attempt with a fresh timestamp', async () => {
        const now = jest
          .spyOn(Date, 'now')
          .mockReturnValue(Date.parse('2026-11-05T12:00:00.000Z'))
        const first = (await deliver()).headers['X-Textbee-Timestamp']
        mockedAxios.post.mockClear()
        now.mockReturnValue(Date.parse('2026-11-05T12:05:00.000Z'))
        const second = (await deliver()).headers['X-Textbee-Timestamp']

        expect(Number(second) - Number(first)).toBe(300)
      })
    })

    it('follows redirects through the guarded agents', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      const notif = notification()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
      webhookSubscriptionModel.findById.mockResolvedValue(activeSubscription())
      mockedAxios.post.mockResolvedValue({ status: 200, data: 'ok' })

      await service.attemptWebhookDelivery('wn_1')

      const [, , config] = mockedAxios.post.mock.calls[0]
      expect((config as any).maxRedirects).toBe(5)
      expect(typeof (config as any).beforeRedirect).toBe('function')
      expect((config as any).proxy).toBe(false)
      expect((config as any).httpAgent).toBe((service as any).deliveryHttpAgent)
      expect((config as any).httpsAgent).toBe((service as any).deliveryHttpsAgent)
    })

    it('produces a different signature when the secret differs', async () => {
      const payload = { hello: 'world' }
      const sig = (secret: string) =>
        crypto.createHmac('sha256', secret).update(JSON.stringify(payload)).digest('hex')
      expect(sig('a-signing-secret-of-enough-length')).not.toBe(
        sig('a-different-secret-of-enough-length'),
      )
    })

    it.each(['127.0.0.1', '::ffff:7f00:1', '10.0.0.5', 'localhost'])(
      'refuses a redirect hop to %s',
      async (hostname) => {
        const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
        webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notification())
        webhookSubscriptionModel.findById.mockResolvedValue(activeSubscription())
        mockedAxios.post.mockResolvedValue({ status: 200, data: 'ok' })

        await service.attemptWebhookDelivery('wn_1')

        const [, , config] = mockedAxios.post.mock.calls[0]
        expect(() => (config as any).beforeRedirect({ hostname })).toThrow()
      },
    )

    it('allows a redirect hop to a public host', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notification())
      webhookSubscriptionModel.findById.mockResolvedValue(activeSubscription())
      mockedAxios.post.mockResolvedValue({ status: 200, data: 'ok' })

      await service.attemptWebhookDelivery('wn_1')

      const [, , config] = mockedAxios.post.mock.calls[0]
      expect(() =>
        (config as any).beforeRedirect({ hostname: 'script.googleusercontent.com' }),
      ).not.toThrow()
    })

    it('classifies an unfollowed 3xx like a 4xx', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      const notif = notification()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
      webhookSubscriptionModel.findById.mockResolvedValue(activeSubscription())
      mockedAxios.post.mockRejectedValue({ response: { status: 302, data: '' } })

      await service.attemptWebhookDelivery('wn_1')

      expect(notif.errorType).toBe('non-retryable')
      expect(notif.httpStatusCode).toBe(302)
    })

    it.each([
      [0, false],
      [1, false],
      [2, true],
    ])(
      'retries a 4xx until the 3rd attempt (attempts before: %i, aborted: %s)',
      async (before, aborted) => {
        const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
        const notif = { ...notification(), deliveryAttemptCount: before }
        webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
        webhookSubscriptionModel.findById.mockResolvedValue(activeSubscription())
        mockedAxios.post.mockRejectedValue({ response: { status: 404, data: 'nope' } })

        await service.attemptWebhookDelivery('wn_1')

        expect(notif.errorType).toBe('non-retryable')
        expect(notif.deliveryAttemptCount).toBe(before + 1)
        if (aborted) {
          expect(notif.deliveryAttemptAbortedAt).toBeInstanceOf(Date)
          expect(notif.nextDeliveryAttemptAt).toBeUndefined()
        } else {
          expect(notif.deliveryAttemptAbortedAt).toBeUndefined()
          expect(notif.nextDeliveryAttemptAt).toBeInstanceOf(Date)
        }
      },
    )

    it('still aborts a 5xx after the 10th attempt', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      const notif = { ...notification(), deliveryAttemptCount: 9 }
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
      webhookSubscriptionModel.findById.mockResolvedValue(activeSubscription())
      mockedAxios.post.mockRejectedValue({ response: { status: 503, data: '' } })

      await service.attemptWebhookDelivery('wn_1')

      expect(notif.errorType).toBe('retryable')
      expect(notif.deliveryAttemptAbortedAt).toBeInstanceOf(Date)
    })

    it('does not deliver to a stored URL whose host is a private IP literal', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      const notif = notification()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
      webhookSubscriptionModel.findById.mockResolvedValue(
        activeSubscription({ deliveryUrl: 'http://[::ffff:7f00:1]:3001/' }),
      )

      await service.attemptWebhookDelivery('wn_1')

      expect(mockedAxios.post).not.toHaveBeenCalled()
      expect(notif.deliveredAt).toBeUndefined()
    })

    it('aborts delivery without calling axios when the subscription is inactive', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      const notif = notification()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
      webhookSubscriptionModel.findById.mockResolvedValue(
        activeSubscription({ isActive: false }),
      )

      await service.attemptWebhookDelivery('wn_1')

      expect(notif.deliveryAttemptAbortedAt).toBeInstanceOf(Date)
      expect(notif.save).toHaveBeenCalledTimes(1)
      expect(mockedAxios.post).not.toHaveBeenCalled()
    })

    it('aborts delivery when the subscription has been soft-deleted', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      const notif = notification()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
      webhookSubscriptionModel.findById.mockResolvedValue(
        activeSubscription({ deletedAt: new Date() }),
      )

      await service.attemptWebhookDelivery('wn_1')

      expect(notif.deliveryAttemptAbortedAt).toBeInstanceOf(Date)
      expect(mockedAxios.post).not.toHaveBeenCalled()
    })

    it('claims only a pending notification that is due', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notification())
      webhookSubscriptionModel.findById.mockResolvedValue(activeSubscription())
      mockedAxios.post.mockResolvedValue({ status: 200, data: 'ok' })

      await service.attemptWebhookDelivery('wn_1')

      const [filter, update] = webhookNotificationModel.findOneAndUpdate.mock.calls[0]
      expect(filter).toMatchObject({
        _id: 'wn_1',
        deliveredAt: null,
        deliveryAttemptAbortedAt: null,
      })
      expect(filter.$or).toEqual([
        { nextDeliveryAttemptAt: null },
        { nextDeliveryAttemptAt: { $lte: expect.any(Date) } },
      ])
      expect(update.$set.nextDeliveryAttemptAt.getTime()).toBeGreaterThan(Date.now())
    })

    it('sends nothing when the notification is already delivered or claimed', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(null)

      await service.attemptWebhookDelivery('wn_1')

      expect(webhookSubscriptionModel.findById).not.toHaveBeenCalled()
      expect(mockedAxios.post).not.toHaveBeenCalled()
    })

    it('aborts a notification whose subscription no longer exists', async () => {
      const { service, webhookSubscriptionModel, webhookNotificationModel } = build()
      const notif = notification()
      webhookNotificationModel.findOneAndUpdate.mockResolvedValue(notif)
      webhookSubscriptionModel.findById.mockResolvedValue(null)

      await service.attemptWebhookDelivery('wn_1')

      expect(notif.deliveryAttemptAbortedAt).toBeInstanceOf(Date)
      expect(mockedAxios.post).not.toHaveBeenCalled()
    })
  })
})

describe('WebhookService repeated reports', () => {
  const setup = (notifiedSubscriptionIds: string[]) => {
    const webhookSubscriptionModel: any = {
      find: jest.fn().mockResolvedValue([
        { _id: 'ws_1', deliveryUrl: 'https://example.com/a' },
        { _id: 'ws_2', deliveryUrl: 'https://example.com/b' },
      ]),
    }
    const webhookNotificationModel: any = {
      distinct: jest.fn().mockResolvedValue(notifiedSubscriptionIds),
      create: jest.fn().mockResolvedValue({ _id: 'wn_new' }),
    }
    const webhookQueueService: any = {
      addWebhookDeliveryJob: jest.fn().mockResolvedValue(undefined),
    }
    const service = new WebhookService(
      webhookSubscriptionModel,
      webhookNotificationModel,
      webhookQueueService,
      {} as any,
      {} as any,
      {} as any,
    )
    return { service, webhookNotificationModel }
  }

  it('skips subscriptions already notified about this message and event', async () => {
    const { service, webhookNotificationModel } = setup(['ws_1'])

    await service.deliverNotification({
      sms: { _id: 's1', status: 'delivered' },
      user: { _id: 'u1' },
      event: 'MESSAGE_DELIVERED',
    })

    expect(webhookNotificationModel.distinct).toHaveBeenCalledWith('webhookSubscription', {
      sms: 's1',
      event: 'MESSAGE_DELIVERED',
      webhookSubscription: { $in: ['ws_1', 'ws_2'] },
      deliveryAttemptAbortedAt: null,
    })
    expect(webhookNotificationModel.create).toHaveBeenCalledTimes(1)
    expect(webhookNotificationModel.create.mock.calls[0][0].webhookSubscription).toBe('ws_2')
  })

  it('still sends every unknown-state report', async () => {
    const { service, webhookNotificationModel } = setup(['ws_1', 'ws_2'])

    await service.deliverNotification({
      sms: { _id: 's1', status: 'queued' },
      user: { _id: 'u1' },
      event: 'UNKNOWN_STATE',
    })

    expect(webhookNotificationModel.distinct).not.toHaveBeenCalled()
    expect(webhookNotificationModel.create).toHaveBeenCalledTimes(2)
  })

  it('leaves a notification due for retry when its job cannot be queued', async () => {
    const webhookSubscriptionModel: any = {
      find: jest.fn().mockResolvedValue([{ _id: 'ws_1', deliveryUrl: 'https://example.com/a' }]),
    }
    const webhookNotificationModel: any = {
      distinct: jest.fn().mockResolvedValue([]),
      create: jest.fn().mockResolvedValue({ _id: 'wn_new' }),
      updateOne: jest.fn().mockResolvedValue(undefined),
    }
    const service = new WebhookService(
      webhookSubscriptionModel,
      webhookNotificationModel,
      { addWebhookDeliveryJob: jest.fn().mockRejectedValue(new Error('redis down')) } as any,
      {} as any,
      {} as any,
      {} as any,
    )
    jest.spyOn(console, 'log').mockImplementation(() => undefined)

    await service.deliverNotification({
      sms: { _id: 's1', status: 'sent' },
      user: { _id: 'u1' },
      event: 'MESSAGE_SENT',
    })

    expect(webhookNotificationModel.updateOne).toHaveBeenCalledWith(
      { _id: 'wn_new' },
      { $set: { nextDeliveryAttemptAt: expect.any(Date) } },
    )
  })

  it('creates nothing when every subscription was already notified', async () => {
    const { service, webhookNotificationModel } = setup(['ws_1', 'ws_2'])

    await service.deliverNotification({
      sms: { _id: 's1', status: 'delivered' },
      user: { _id: 'u1' },
      event: 'MESSAGE_DELIVERED',
    })

    expect(webhookNotificationModel.create).not.toHaveBeenCalled()
  })
})

describe('WebhookService payload simUsed', () => {
  const setup = () => {
    const webhookSubscriptionModel: any = {
      find: jest.fn().mockResolvedValue([
        { _id: 'ws_1', deliveryUrl: 'https://example.com/hook' },
      ]),
    }
    const webhookNotificationModel: any = {
      distinct: jest.fn().mockResolvedValue([]),
      create: jest.fn().mockResolvedValue({ _id: 'wn_1' }),
    }
    const webhookQueueService: any = {
      addWebhookDeliveryJob: jest.fn().mockResolvedValue(undefined),
    }
    const service = new WebhookService(
      webhookSubscriptionModel,
      webhookNotificationModel,
      webhookQueueService,
      {} as any,
      {} as any,
      {} as any,
    )
    const payloadFor = async (sms: Record<string, unknown>, event: string) => {
      await service.deliverNotification({ sms, user: { _id: 'u1' }, event })
      return webhookNotificationModel.create.mock.calls[0][0].payload
    }
    return { payloadFor }
  }

  it('adds the SIM the phone reported', async () => {
    const payload = await setup().payloadFor(
      { _id: 's1', status: 'sent', simUsed: { subscriptionId: 19, slotIndex: 1 } },
      'MESSAGE_SENT',
    )

    expect(payload.simUsed).toEqual({ subscriptionId: 19, slotIndex: 1 })
  })

  it('passes every stored SIM detail through', async () => {
    const simUsed = {
      subscriptionId: 19,
      slotIndex: 1,
      carrierName: 'Smart',
      displayName: 'Work',
      countryIso: 'ph',
      mcc: '515',
      mnc: '03',
    }
    const payload = await setup().payloadFor(
      { _id: 's1', status: 'sent', simUsed },
      'MESSAGE_SENT',
    )

    expect(payload.simUsed).toEqual(simUsed)
  })

  it('adds it to received messages too', async () => {
    const payload = await setup().payloadFor(
      { _id: 's1', sender: '+15550100', simUsed: { slotIndex: 0 } },
      'MESSAGE_RECEIVED',
    )

    expect(payload.simUsed).toEqual({ slotIndex: 0 })
  })

  it('leaves the payload unchanged when no SIM was reported', async () => {
    const payload = await setup().payloadFor(
      { _id: 's1', status: 'sent', simSubscriptionId: 19 },
      'MESSAGE_SENT',
    )

    expect(payload).not.toHaveProperty('simUsed')
  })
})

describe('WebhookService payload error text', () => {
  const payloadFor = async (sms: Record<string, unknown>) => {
    const webhookNotificationModel: any = {
      distinct: jest.fn().mockResolvedValue([]),
      create: jest.fn().mockResolvedValue({ _id: 'wn_1' }),
    }
    const service = new WebhookService(
      {
        find: jest
          .fn()
          .mockResolvedValue([
            { _id: 'ws_1', deliveryUrl: 'https://example.com/hook' },
          ]),
      } as any,
      webhookNotificationModel,
      { addWebhookDeliveryJob: jest.fn().mockResolvedValue(undefined) } as any,
      {} as any,
      {} as any,
      {} as any,
    )
    await service.deliverNotification({ sms, user: { _id: 'u1' }, event: 'MESSAGE_FAILED' })
    return webhookNotificationModel.create.mock.calls[0][0].payload
  }

  it('sends the catalog text, the name and the phone text for a known code', async () => {
    const payload = await payloadFor({
      _id: 's1',
      status: 'failed',
      errorCode: '7',
      errorMessage: 'Short code not allowed on this carrier. Use a full phone number.',
      failedAt: new Date('2026-11-01T10:00:00Z'),
    })

    expect(payload.errorCode).toBe('7')
    expect(payload.errorName).toBe('SHORT_CODE_CANCELLED')
    expect(payload.errorMessage).toContain('Premium SMS access')
    expect(payload.deviceMessage).toBe(
      'Short code not allowed on this carrier. Use a full phone number.',
    )
    expect(payload.docsUrl).toBe(
      'https://textbee.dev/docs/sending-sms/sending-sms#short-codes',
    )
  })

  it('sends the stored text for an unknown code', async () => {
    const payload = await payloadFor({
      _id: 's1',
      status: 'failed',
      errorCode: '999',
      errorMessage: 'SmsManager.RESULT_SOMETHING_NEW',
      failedAt: new Date('2026-11-01T10:00:00Z'),
    })

    expect(payload.errorMessage).toBe('SmsManager.RESULT_SOMETHING_NEW')
    expect(payload).not.toHaveProperty('errorName')
    expect(payload).not.toHaveProperty('deviceMessage')
    expect(payload).not.toHaveProperty('docsUrl')
  })

  it('sends push text for a push failure', async () => {
    const payload = await payloadFor({
      _id: 's1',
      status: 'failed',
      errorCode: 'FCM_TOKEN_NOT_REGISTERED',
      errorMessage:
        'FCM_DELIVERY_FAILED: NotRegistered. The device token is invalid.',
      failedAt: new Date('2026-11-01T10:00:00Z'),
    })

    expect(payload.errorName).toBe('PUSH_TOKEN_NOT_REGISTERED')
    expect(payload.errorMessage).toContain('register it again')
    expect(payload).not.toHaveProperty('deviceMessage')
  })
})
