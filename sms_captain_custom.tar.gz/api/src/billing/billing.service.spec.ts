import { Test, TestingModule } from '@nestjs/testing'
import { getModelToken } from '@nestjs/mongoose'
import { createHmac } from 'crypto'
import { errors } from '@polar-sh/sdk/2026-10'
import { Types } from 'mongoose'
import { BillingService } from './billing.service'
import { Plan } from './schemas/plan.schema'
import { Subscription } from './schemas/subscription.schema'
import { User } from '../users/schemas/user.schema'
import { SMS } from '../gateway/schemas/sms.schema'
import { PolarWebhookPayload } from './schemas/polar-webhook-payload.schema'
import { CheckoutSession } from './schemas/checkout-session.schema'
import { CheckoutAttempt } from './schemas/checkout-attempt.schema'
import { BillingNotificationsService } from './billing-notifications.service'
import { BillingNotificationType } from './schemas/billing-notification.schema'
import { UsersService } from '../users/users.service'
import { AnalyticsService } from '../analytics/analytics.service'
import { CheckoutPromotionService } from './checkout-promotion.service'

const noPromotion = { getLivePromotion: async () => null }

// Pins apart three failures that used to share one misleading message.
describe('BillingService - checkout guards', () => {
  let service: BillingService

  const user = { _id: new Types.ObjectId('507f1f77bcf86cd799439011') }
  const req = { ip: '127.0.0.1' }

  const mockPlanModel = {
    findOne: jest.fn(),
  }
  const emptyModel = {}

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BillingService,
        { provide: getModelToken(Plan.name), useValue: mockPlanModel },
        { provide: getModelToken(Subscription.name), useValue: emptyModel },
        { provide: getModelToken(User.name), useValue: emptyModel },
        { provide: getModelToken(SMS.name), useValue: emptyModel },
        {
          provide: getModelToken(PolarWebhookPayload.name),
          useValue: emptyModel,
        },
        { provide: getModelToken(CheckoutSession.name), useValue: emptyModel },
        { provide: getModelToken(CheckoutAttempt.name), useValue: emptyModel },
        { provide: BillingNotificationsService, useValue: {} },
        { provide: UsersService, useValue: { markMilestone: jest.fn() } },
        { provide: AnalyticsService, useValue: { purchase: jest.fn(), checkoutStarted: jest.fn() } },
        { provide: CheckoutPromotionService, useValue: noPromotion },
      ],
    }).compile()

    service = module.get<BillingService>(BillingService)
    jest.clearAllMocks()
  })

  it('names the real problem when the request carries no plan name', async () => {
    await expect(
      service.getCheckoutUrl({
        user,
        payload: { billingInterval: 'monthly' },
        req,
      }),
    ).rejects.toMatchObject({
      response: { code: 'PLAN_NAME_REQUIRED' },
    })

    // the plan is never looked up, so it can never be blamed
    expect(mockPlanModel.findOne).not.toHaveBeenCalled()
  })

  it('reports an unknown plan as not found, not as unpurchasable', async () => {
    mockPlanModel.findOne.mockResolvedValue(null)

    await expect(
      service.getCheckoutUrl({
        user,
        payload: { planName: 'enterprise', billingInterval: 'monthly' },
        req,
      }),
    ).rejects.toMatchObject({
      response: { code: 'PLAN_NOT_FOUND' },
    })
  })

  it('still rejects a real plan that has no Polar products', async () => {
    mockPlanModel.findOne.mockResolvedValue({ name: 'pro' })

    await expect(
      service.getCheckoutUrl({
        user,
        payload: { planName: 'pro', billingInterval: 'monthly' },
        req,
      }),
    ).rejects.toThrow('Plan cannot be purchased')
  })
})

describe('BillingService - syncCheckoutSessionStatus', () => {
  let service: BillingService

  const mockCheckoutSessionModel = {
    updateOne: jest.fn(),
  }
  const mockCheckoutAttemptModel = {
    findOne: jest.fn(),
    updateOne: jest.fn(),
  }
  const emptyModel = {}
  const sortArgs: unknown[] = []
  const latestAttempt = (attempts: any[]) => (filter: any) => ({
    sort: (order: unknown) => {
      sortArgs.push(order)
      return {
        select: () => ({
          lean: async () =>
            attempts
              .filter((a) => a.checkoutSessionId === filter.checkoutSessionId)
              .sort((x, y) => y.createdAt.getTime() - x.createdAt.getTime())[0] ?? null,
        }),
      }
    },
  })

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BillingService,
        { provide: getModelToken(Plan.name), useValue: emptyModel },
        { provide: getModelToken(Subscription.name), useValue: emptyModel },
        { provide: getModelToken(User.name), useValue: emptyModel },
        { provide: getModelToken(SMS.name), useValue: emptyModel },
        {
          provide: getModelToken(PolarWebhookPayload.name),
          useValue: emptyModel,
        },
        {
          provide: getModelToken(CheckoutSession.name),
          useValue: mockCheckoutSessionModel,
        },
        {
          provide: getModelToken(CheckoutAttempt.name),
          useValue: mockCheckoutAttemptModel,
        },
        { provide: BillingNotificationsService, useValue: {} },
        { provide: UsersService, useValue: { markMilestone: jest.fn() } },
        { provide: AnalyticsService, useValue: { purchase: jest.fn(), checkoutStarted: jest.fn() } },
        { provide: CheckoutPromotionService, useValue: noPromotion },
      ],
    }).compile()

    service = module.get<BillingService>(BillingService)

    jest.clearAllMocks()
    sortArgs.length = 0
    mockCheckoutSessionModel.updateOne.mockResolvedValue({ modifiedCount: 1 })
    mockCheckoutAttemptModel.findOne.mockImplementation(latestAttempt([]))
    mockCheckoutAttemptModel.updateOne.mockResolvedValue({ modifiedCount: 1 })
  })

  // Nothing wrote isCompleted before this existed, so a checkout the customer
  // had already paid for stayed reusable until it expired.
  it('marks a succeeded checkout completed', async () => {
    await service.syncCheckoutSessionStatus({
      checkoutSessionId: 'checkout_abc',
      status: 'succeeded',
    })

    expect(mockCheckoutSessionModel.updateOne).toHaveBeenCalledWith(
      { checkoutSessionId: 'checkout_abc' },
      expect.objectContaining({ isCompleted: true, completedAt: expect.any(Date) }),
    )
  })

  describe('checkout attempts', () => {
    const attempts = (): any[] => [
      { _id: 'a1', checkoutSessionId: 'checkout_abc', createdAt: new Date('2026-10-01T10:00:00Z') },
      { _id: 'a2', checkoutSessionId: 'checkout_abc', createdAt: new Date('2026-10-01T11:00:00Z') },
      { _id: 'a3', checkoutSessionId: 'checkout_other', createdAt: new Date('2026-10-01T12:00:00Z') },
    ]
    const store = (rows: any[]) => {
      mockCheckoutAttemptModel.findOne.mockImplementation(latestAttempt(rows))
      mockCheckoutAttemptModel.updateOne.mockImplementation(async (filter, update) => {
        const row = rows.find((r) => r._id === filter._id && !r.completedAt)
        if (row) Object.assign(row, update.$set)
        return { modifiedCount: row ? 1 : 0 }
      })
    }

    it('completes only the newest attempt for the checkout', async () => {
      const rows = attempts()
      store(rows)

      await service.syncCheckoutSessionStatus({
        checkoutSessionId: 'checkout_abc',
        status: 'succeeded',
      })

      expect(sortArgs).toEqual([{ createdAt: -1 }])
      expect(rows[1].completedAt).toBeInstanceOf(Date)
      expect(rows[0]).not.toHaveProperty('completedAt')
      expect(rows[2]).not.toHaveProperty('completedAt')
    })

    it('marks nothing more when the webhook is delivered again', async () => {
      const rows = attempts()
      store(rows)
      const event = { checkoutSessionId: 'checkout_abc', status: 'succeeded' }

      await service.syncCheckoutSessionStatus(event)
      const first = (rows[1] as any).completedAt
      await service.syncCheckoutSessionStatus(event)

      expect((rows[1] as any).completedAt).toBe(first)
      expect(rows[0]).not.toHaveProperty('completedAt')
      expect(mockCheckoutAttemptModel.updateOne).toHaveBeenCalledTimes(1)
    })

    it.each(['open', 'confirmed', 'failed', 'expired'])(
      'leaves attempts open for a %s checkout',
      async (status) => {
        await service.syncCheckoutSessionStatus({ checkoutSessionId: 'checkout_abc', status })

        expect(mockCheckoutAttemptModel.findOne).not.toHaveBeenCalled()
        expect(mockCheckoutAttemptModel.updateOne).not.toHaveBeenCalled()
      },
    )

    it('does not throw when the attempt lookup fails', async () => {
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
      mockCheckoutAttemptModel.findOne.mockImplementation(() => {
        throw new Error('db down')
      })

      await expect(
        service.syncCheckoutSessionStatus({
          checkoutSessionId: 'checkout_abc',
          status: 'succeeded',
        }),
      ).resolves.toBeUndefined()
    })
  })

  it('marks an expired checkout abandoned', async () => {
    await service.syncCheckoutSessionStatus({
      checkoutSessionId: 'checkout_abc',
      status: 'expired',
    })

    expect(mockCheckoutSessionModel.updateOne).toHaveBeenCalledWith(
      { checkoutSessionId: 'checkout_abc' },
      { isAbandoned: true },
    )
  })

  // open and confirmed are still in flight and failed is retryable, so the
  // cached checkout URL has to stay usable.
  it.each(['open', 'confirmed', 'failed'])(
    'leaves a %s checkout untouched',
    async (status) => {
      await service.syncCheckoutSessionStatus({
        checkoutSessionId: 'checkout_abc',
        status,
      })

      expect(mockCheckoutSessionModel.updateOne).not.toHaveBeenCalled()
    },
  )

  // The cache holds one row per user, so a late webhook for a checkout that has
  // since been replaced must match nothing rather than clobber the new row.
  it('keys on the checkout id, never on the user', async () => {
    await service.syncCheckoutSessionStatus({
      checkoutSessionId: 'checkout_stale',
      status: 'succeeded',
    })

    const [filter] = mockCheckoutSessionModel.updateOne.mock.calls[0]
    expect(filter).toEqual({ checkoutSessionId: 'checkout_stale' })
    expect(filter).not.toHaveProperty('user')
  })

  it('ignores an event with no checkout id', async () => {
    await service.syncCheckoutSessionStatus({
      checkoutSessionId: undefined as any,
      status: 'succeeded',
    })

    expect(mockCheckoutSessionModel.updateOne).not.toHaveBeenCalled()
  })

  // A webhook handler that throws would make Polar retry the whole event.
  it('does not throw when the write fails', async () => {
    mockCheckoutSessionModel.updateOne.mockRejectedValue(new Error('db down'))

    await expect(
      service.syncCheckoutSessionStatus({
        checkoutSessionId: 'checkout_abc',
        status: 'succeeded',
      }),
    ).resolves.not.toThrow()
  })
})

describe('BillingService - canPerformAction account checks', () => {
  let service: BillingService

  const userId = '507f1f77bcf86cd799439011'
  const freePlan = { _id: 'plan_free', name: 'free', dailyLimit: 50, monthlyLimit: 300, bulkSendLimit: 50 }

  const select = jest.fn()
  const mockUserModel = { findById: jest.fn(() => ({ select })) }
  const mockSubscriptionModel = { findOne: jest.fn() }
  const mockPlanModel = { findOne: jest.fn(), findById: jest.fn() }
  const mockSmsModel = { countDocuments: jest.fn() }
  const mockBillingNotifications = { notifyOnce: jest.fn() }
  const emptyModel = {}

  const givenUser = (fields: Record<string, unknown> | null) =>
    select.mockResolvedValue(
      fields && { _id: userId, email: 'ada@example.com', isBanned: false, ...fields },
    )

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BillingService,
        { provide: getModelToken(Plan.name), useValue: mockPlanModel },
        { provide: getModelToken(Subscription.name), useValue: mockSubscriptionModel },
        { provide: getModelToken(User.name), useValue: mockUserModel },
        { provide: getModelToken(SMS.name), useValue: mockSmsModel },
        { provide: getModelToken(PolarWebhookPayload.name), useValue: emptyModel },
        { provide: getModelToken(CheckoutSession.name), useValue: emptyModel },
        { provide: getModelToken(CheckoutAttempt.name), useValue: emptyModel },
        { provide: BillingNotificationsService, useValue: mockBillingNotifications },
        { provide: UsersService, useValue: { markMilestone: jest.fn() } },
        { provide: AnalyticsService, useValue: { purchase: jest.fn(), checkoutStarted: jest.fn() } },
        { provide: CheckoutPromotionService, useValue: noPromotion },
      ],
    }).compile()

    service = module.get<BillingService>(BillingService)

    jest.clearAllMocks()
    jest.spyOn(console, 'warn').mockImplementation(() => undefined)
    jest.spyOn(console, 'error').mockImplementation(() => undefined)
    mockSubscriptionModel.findOne.mockResolvedValue(null)
    mockPlanModel.findOne.mockResolvedValue(freePlan)
    mockSmsModel.countDocuments.mockResolvedValue(0)
    mockBillingNotifications.notifyOnce.mockResolvedValue(undefined)
  })

  afterEach(() => jest.restoreAllMocks())

  it('loads the waiver field that is hidden by default', async () => {
    givenUser({ emailVerifiedAt: new Date() })

    await service.canPerformAction(userId, 'send_sms', 1)

    expect(select).toHaveBeenCalledWith('+emailVerificationWaivedAt')
  })

  it('blocks an account whose emailVerifiedAt was never written', async () => {
    givenUser({})

    await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
      response: { message: 'Please verify your email to continue' },
      status: 400,
    })
    expect(mockSmsModel.countDocuments).not.toHaveBeenCalled()
  })

  it('blocks an account whose emailVerifiedAt is null', async () => {
    givenUser({ emailVerifiedAt: null })

    await expect(service.canPerformAction(userId, 'receive_sms', 1)).rejects.toMatchObject({
      status: 400,
    })
  })

  it.each(['send_sms', 'bulk_send_sms', 'receive_sms'] as const)(
    'allows a verified account to %s',
    async (action) => {
      givenUser({ emailVerifiedAt: new Date() })

      await expect(service.canPerformAction(userId, action, 1)).resolves.toEqual({
        overLimit: false,
      })
    },
  )

  it('allows an unverified account with a waiver', async () => {
    givenUser({ emailVerificationWaivedAt: new Date() })

    await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
      overLimit: false,
    })
  })

  describe('LIMIT_EXEMPT_USER_IDS', () => {
    const originalExempt = process.env.LIMIT_EXEMPT_USER_IDS

    afterEach(() => {
      if (originalExempt === undefined) delete process.env.LIMIT_EXEMPT_USER_IDS
      else process.env.LIMIT_EXEMPT_USER_IDS = originalExempt
    })

    it.each(['send_sms', 'bulk_send_sms', 'receive_sms'] as const)(
      'skips usage limits for a listed account on %s',
      async (action) => {
        process.env.LIMIT_EXEMPT_USER_IDS = ` 64b000000000000000000001 , ${userId} `
        givenUser({ emailVerifiedAt: new Date() })
        mockSmsModel.countDocuments.mockResolvedValue(1000)

        await expect(service.canPerformAction(userId, action, 500)).resolves.toEqual({
          overLimit: false,
        })
        expect(mockSmsModel.countDocuments).not.toHaveBeenCalled()
      },
    )

    it('still enforces limits for an account that is not listed', async () => {
      process.env.LIMIT_EXEMPT_USER_IDS = '64b000000000000000000001'
      givenUser({ emailVerifiedAt: new Date() })
      mockSmsModel.countDocuments.mockResolvedValue(300)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
    })

    it('still requires a verified email for a listed account', async () => {
      process.env.LIMIT_EXEMPT_USER_IDS = userId
      givenUser({})

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 400,
      })
    })

    it('still blocks a banned listed account', async () => {
      process.env.LIMIT_EXEMPT_USER_IDS = userId
      givenUser({ emailVerifiedAt: new Date(), isBanned: true })

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 403,
      })
    })
  })

  describe('limit hit logging', () => {
    const limitLines = () =>
      (console.warn as jest.Mock).mock.calls
        .map(([line]) => String(line))
        .filter((line) => line.includes('hasReachedLimit'))

    const hitLimit = () =>
      expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })

    beforeEach(() => {
      givenUser({
        emailVerifiedAt: new Date(),
        email: 'person@example.com',
        name: 'Some Person',
      })
      mockSmsModel.countDocuments.mockResolvedValue(freePlan.dailyLimit)
    })

    it('writes one line without the email or name', async () => {
      await hitLimit()

      expect(limitLines()).toHaveLength(1)
      expect(limitLines()[0]).toContain(userId)
      expect(limitLines()[0]).not.toContain('person@example.com')
      expect(limitLines()[0]).not.toContain('Some Person')
    })

    it('rejects every call but logs a repeat only once in the hour', async () => {
      await hitLimit()
      await hitLimit()
      await hitLimit()

      expect(limitLines()).toHaveLength(1)
    })

    it('reports the skipped count on the next line after the hour', async () => {
      const start = Date.now()
      const clock = jest.spyOn(Date, 'now').mockReturnValue(start)
      await hitLimit()
      await hitLimit()
      await hitLimit()

      clock.mockReturnValue(start + 60 * 60 * 1000)
      await hitLimit()

      expect(limitLines()).toHaveLength(2)
      expect(limitLines()[1]).toContain('"suppressed":2')
    })

    it('logs another account separately', async () => {
      await hitLimit()
      await expect(
        service.canPerformAction('64b000000000000000000009', 'send_sms', 1),
      ).rejects.toMatchObject({ status: 429 })

      expect(limitLines()).toHaveLength(2)
    })

    it('logs each limit type separately for one account', async () => {
      await hitLimit()
      await expect(
        service.canPerformAction(userId, 'bulk_send_sms', freePlan.bulkSendLimit + 1),
      ).rejects.toMatchObject({ status: 429 })

      expect(limitLines()).toHaveLength(2)
      expect(limitLines()[0]).toContain('"tripped":"daily"')
      expect(limitLines()[1]).toContain('"tripped":"bulk"')
    })
  })

  it('still applies plan limits to a waived account', async () => {
    givenUser({ emailVerificationWaivedAt: new Date() })
    mockSmsModel.countDocuments.mockResolvedValue(freePlan.dailyLimit)

    await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
      status: 429,
    })
  })

  it('still blocks a banned account', async () => {
    givenUser({ emailVerifiedAt: new Date(), isBanned: true })

    await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
      status: 403,
    })
  })

  it('rejects an unknown user instead of allowing the action', async () => {
    givenUser(null)

    await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
      status: 404,
    })
  })

  describe('receives over the plan limit', () => {
    const originalSetting = process.env.RECEIVE_SMS_OVER_LIMIT

    beforeEach(() => {
      delete process.env.RECEIVE_SMS_OVER_LIMIT
      givenUser({ emailVerifiedAt: new Date() })
      mockSmsModel.countDocuments
        .mockResolvedValueOnce(10)
        .mockResolvedValueOnce(freePlan.monthlyLimit)
    })

    afterEach(() => {
      if (originalSetting === undefined) delete process.env.RECEIVE_SMS_OVER_LIMIT
      else process.env.RECEIVE_SMS_OVER_LIMIT = originalSetting
    })

    it('allows the receive and marks it over the limit', async () => {
      await expect(service.canPerformAction(userId, 'receive_sms', 1)).resolves.toEqual({
        overLimit: true,
      })
      expect(mockBillingNotifications.notifyOnce).toHaveBeenCalledWith(
        expect.objectContaining({
          type: BillingNotificationType.MONTHLY_LIMIT_REACHED,
          emailKey: 'U2',
          recordHit: true,
        }),
      )
    })

    it('still allows the receive when the notification fails', async () => {
      mockBillingNotifications.notifyOnce.mockRejectedValue(new Error('queue unavailable'))

      await expect(service.canPerformAction(userId, 'receive_sms', 1)).resolves.toEqual({
        overLimit: true,
      })
    })

    it('still refuses an over-limit send when the notice fails', async () => {
      mockBillingNotifications.notifyOnce.mockRejectedValue(new Error('db down'))

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
      expect(console.error).toHaveBeenCalledWith(
        'canPerformAction: failed to record a limit notice',
        expect.objectContaining({ error: 'db down' }),
      )
    })

    it('rejects the receive when RECEIVE_SMS_OVER_LIMIT is reject', async () => {
      process.env.RECEIVE_SMS_OVER_LIMIT = 'reject'

      await expect(service.canPerformAction(userId, 'receive_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
    })

    it('still notifies when receives over the limit are rejected', async () => {
      process.env.RECEIVE_SMS_OVER_LIMIT = 'reject'

      await expect(service.canPerformAction(userId, 'receive_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
      expect(mockBillingNotifications.notifyOnce).toHaveBeenCalledWith(
        expect.objectContaining({ meta: expect.objectContaining({ limitTripped: 'monthly' }) }),
      )
    })

    it('still rejects a send over the limit', async () => {
      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
    })

    it('does not mark a paid receive inside the extended monthly allowance', async () => {
      const proPlan = { _id: 'plan_pro', name: 'pro', dailyLimit: -1, monthlyLimit: 5000, bulkSendLimit: -1 }
      mockSubscriptionModel.findOne.mockResolvedValue({ plan: proPlan._id })
      mockPlanModel.findById.mockResolvedValue(proPlan)
      mockSmsModel.countDocuments.mockReset()
      mockSmsModel.countDocuments
        .mockResolvedValueOnce(10)
        .mockResolvedValueOnce(proPlan.monthlyLimit)

      await expect(service.canPerformAction(userId, 'receive_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
    })
  })

  describe('paid monthly allowance', () => {
    const proPlan = { _id: 'plan_pro', name: 'pro', dailyLimit: -1, monthlyLimit: 5000, bulkSendLimit: -1 }

    const givenPaid = (fields: Record<string, unknown> = {}) => {
      mockSubscriptionModel.findOne.mockResolvedValue({ plan: proPlan._id, ...fields })
      mockPlanModel.findById.mockResolvedValue(proPlan)
    }

    const givenCounts = (today: number, last30Days: number) =>
      mockSmsModel.countDocuments.mockResolvedValueOnce(today).mockResolvedValueOnce(last30Days)

    const originalSetting = process.env.RECEIVE_SMS_OVER_LIMIT

    beforeEach(() => {
      delete process.env.RECEIVE_SMS_OVER_LIMIT
      givenUser({ emailVerifiedAt: new Date() })
    })

    afterEach(() => {
      if (originalSetting === undefined) delete process.env.RECEIVE_SMS_OVER_LIMIT
      else process.env.RECEIVE_SMS_OVER_LIMIT = originalSetting
    })

    const monthlyReached = expect.objectContaining({
      type: BillingNotificationType.MONTHLY_LIMIT_REACHED,
    })

    it('lets a paid plan send past its monthly limit within the allowance', async () => {
      givenPaid()
      givenCounts(10, 5000)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
      expect(mockBillingNotifications.notifyOnce).not.toHaveBeenCalledWith(monthlyReached)
    })

    it('allows a paid send that lands exactly on the allowance', async () => {
      givenPaid()
      givenCounts(10, 5499)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
    })

    it('blocks a paid send past the allowance and emails once', async () => {
      givenPaid()
      givenCounts(10, 5500)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
      expect(mockBillingNotifications.notifyOnce).toHaveBeenCalledTimes(1)
      expect(mockBillingNotifications.notifyOnce).toHaveBeenCalledWith(monthlyReached)
    })

    it('stores a paid receive past the allowance as over the limit', async () => {
      givenPaid()
      givenCounts(10, 5500)

      await expect(service.canPerformAction(userId, 'receive_sms', 1)).resolves.toEqual({
        overLimit: true,
      })
      expect(mockBillingNotifications.notifyOnce).toHaveBeenCalledWith(monthlyReached)
    })

    it('counts the whole batch against the allowance', async () => {
      givenPaid()
      givenCounts(10, 5400)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 200)).rejects.toMatchObject({
        status: 429,
      })
    })

    it('gives a free plan no allowance', async () => {
      givenCounts(10, 300)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
      expect(mockBillingNotifications.notifyOnce).toHaveBeenCalledWith(monthlyReached)
    })

    it('applies the allowance to a custom monthly limit', async () => {
      givenPaid({ customMonthlyLimit: 1000 })
      givenCounts(10, 1099)
      givenCounts(10, 1100)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
    })
  })

  describe('approaching limit notices', () => {
    const proPlan = { _id: 'plan_pro', name: 'pro', dailyLimit: -1, monthlyLimit: 5000, bulkSendLimit: -1 }

    const givenPaid = () => {
      mockSubscriptionModel.findOne.mockResolvedValue({ plan: proPlan._id })
      mockPlanModel.findById.mockResolvedValue(proPlan)
    }

    const givenCounts = (today: number, last30Days: number) =>
      mockSmsModel.countDocuments.mockResolvedValueOnce(today).mockResolvedValueOnce(last30Days)

    const noticeOf = (type: BillingNotificationType) =>
      mockBillingNotifications.notifyOnce.mock.calls
        .map(([input]) => input)
        .find((input) => input.type === type)

    beforeEach(() => givenUser({ emailVerifiedAt: new Date() }))

    it('warns when a send brings the account to 80% of its monthly limit', async () => {
      givenPaid()
      givenCounts(10, 3999)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
      expect(noticeOf(BillingNotificationType.MONTHLY_LIMIT_APPROACHING)).toMatchObject({
        meta: { processedSmsLastMonth: 4000, monthlyLimit: 5000, planName: 'pro' },
        emailKey: 'U1_paid',
      })
    })

    it('warns when a receive brings the account to 80% of its monthly limit', async () => {
      givenPaid()
      givenCounts(10, 3999)

      await service.canPerformAction(userId, 'receive_sms', 1)

      expect(noticeOf(BillingNotificationType.MONTHLY_LIMIT_APPROACHING)).toBeDefined()
    })

    it('does not warn below 80%', async () => {
      givenPaid()
      givenCounts(10, 3998)

      await service.canPerformAction(userId, 'send_sms', 1)

      expect(mockBillingNotifications.notifyOnce).not.toHaveBeenCalled()
    })

    it('does not send the 80% warning inside the paid allowance', async () => {
      givenPaid()
      givenCounts(10, 5000)

      await service.canPerformAction(userId, 'send_sms', 1)

      expect(mockBillingNotifications.notifyOnce).not.toHaveBeenCalled()
    })

    it('warns a free account nearing its daily limit', async () => {
      givenCounts(39, 39)

      await service.canPerformAction(userId, 'send_sms', 1)

      expect(noticeOf(BillingNotificationType.DAILY_LIMIT_APPROACHING)).toMatchObject({
        meta: { processedSmsToday: 40, dailyLimit: 50, planName: 'free' },
        emailKey: 'U3',
      })
      expect(noticeOf(BillingNotificationType.MONTHLY_LIMIT_APPROACHING)).toBeUndefined()
    })

    it('still allows the send when the notice fails', async () => {
      givenPaid()
      givenCounts(10, 3999)
      mockBillingNotifications.notifyOnce.mockRejectedValue(new Error('queue unavailable'))

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
    })
  })

  describe('limit check order and usage email variants', () => {
    const plans = {
      pro: { _id: 'plan_pro', name: 'pro', dailyLimit: -1, monthlyLimit: 5000, bulkSendLimit: -1 },
      scale: { _id: 'plan_scale', name: 'scale', dailyLimit: -1, monthlyLimit: 25000, bulkSendLimit: -1 },
      custom: { _id: 'plan_c', name: 'custom-acme', dailyLimit: 1000, monthlyLimit: 10000, bulkSendLimit: 500 },
    }
    const onPlan = (plan: any) => {
      mockSubscriptionModel.findOne.mockResolvedValue({ plan: plan._id })
      mockPlanModel.findById.mockResolvedValue(plan)
    }
    const givenCounts = (today: number, last30Days: number) =>
      mockSmsModel.countDocuments.mockResolvedValueOnce(today).mockResolvedValueOnce(last30Days)
    const notices = () => mockBillingNotifications.notifyOnce.mock.calls.map(([n]) => n)

    beforeEach(() => {
      delete process.env.RECEIVE_SMS_OVER_LIMIT
      givenUser({ emailVerifiedAt: new Date() })
    })

    it('reports a batch over the batch limit as U5 and nothing else', async () => {
      givenCounts(0, 0)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 60)).rejects.toMatchObject({
        status: 429,
      })

      expect(notices()).toHaveLength(1)
      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.BULK_SMS_LIMIT_REACHED,
        emailKey: 'U5',
        recordHit: false,
        meta: { limitTripped: 'bulk', attempted: 60 },
      })
    })

    it('checks the monthly limit before the daily one', async () => {
      givenCounts(50, 300)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })

      expect(notices()).toHaveLength(1)
      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.MONTHLY_LIMIT_REACHED,
        emailKey: 'U2',
      })
    })

    it('reports the daily limit as U4 on the free plan', async () => {
      givenCounts(50, 120)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })

      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.DAILY_LIMIT_REACHED,
        emailKey: 'U4',
        recordHit: true,
        meta: { limitTripped: 'daily', processedSmsToday: 50 },
      })
    })

    it('reports the batch size version of U5 without a limit hit', async () => {
      givenCounts(0, 0)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 60)).rejects.toThrow()

      expect(notices()[0]).toMatchObject({ emailKey: 'U5', recordHit: false })
      expect(notices()[0].meta).not.toHaveProperty('roomWindow')
    })

    it('counts a batch larger than the room left today as a daily hit and sends U5', async () => {
      givenCounts(49, 100)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 5)).rejects.toMatchObject({
        status: 429,
        response: {
          message: 'This batch had 5 recipients and your account has 1 message left today. Nothing was sent.',
        },
      })

      expect(notices()).toHaveLength(1)
      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.DAILY_LIMIT_REACHED,
        title: 'Your batch did not fit',
        message: 'This batch had 5 recipients and your account has 1 message left today. Nothing was sent.',
        emailKey: 'U5',
        recordHit: true,
        meta: { roomWindow: 'daily', roomLeft: 1, attempted: 5 },
      })
    })

    it('counts a batch larger than the monthly room as a monthly hit', async () => {
      givenCounts(0, 290)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 20)).rejects.toThrow()

      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.MONTHLY_LIMIT_REACHED,
        title: 'Your batch did not fit',
        message:
          'This batch had 20 recipients and your account has 10 messages left in its monthly allowance. Nothing was sent.',
        emailKey: 'U5',
        recordHit: true,
        meta: { roomWindow: 'monthly', roomLeft: 10 },
      })
    })

    it('uses the window with less room when both are short', async () => {
      givenCounts(45, 290)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 12)).rejects.toThrow()

      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.DAILY_LIMIT_REACHED,
        meta: { roomWindow: 'daily', roomLeft: 5 },
      })
    })

    it('reports a reached daily limit as U4 even when the monthly room is also short', async () => {
      givenCounts(50, 290)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 20)).rejects.toThrow()

      expect(notices()[0]).toMatchObject({ emailKey: 'U4', recordHit: true })
    })

    it('records the hit and notice but no email for a paid plan whose batch does not fit', async () => {
      onPlan(plans.pro)
      givenCounts(10, 5450)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 100)).rejects.toMatchObject({
        status: 429,
      })

      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.MONTHLY_LIMIT_REACHED,
        title: 'Your batch did not fit',
        emailKey: null,
        recordHit: true,
        meta: { roomWindow: 'monthly', roomLeft: 50 },
      })
    })

    it.each([
      ['pro', 'U2_paid'],
      ['scale', 'U2_top'],
    ])('picks the monthly email for %s', async (name, key) => {
      const plan = plans[name]
      onPlan(plan)
      givenCounts(10, Math.floor(plan.monthlyLimit * 1.1))

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })

      expect(notices()[0]).toMatchObject({ emailKey: key, meta: { planName: name } })
    })

    it('sends no daily or batch email to a custom plan', async () => {
      onPlan(plans.custom)
      givenCounts(1000, 2000)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
      })
      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.DAILY_LIMIT_REACHED,
        emailKey: null,
      })

      jest.clearAllMocks()
      givenCounts(0, 0)
      await expect(service.canPerformAction(userId, 'bulk_send_sms', 600)).rejects.toMatchObject({
        status: 429,
      })
      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.BULK_SMS_LIMIT_REACHED,
        emailKey: null,
      })
    })

    it('counts today from midnight UTC', async () => {
      givenCounts(0, 0)

      await service.canPerformAction(userId, 'send_sms', 1)

      const since = mockSmsModel.countDocuments.mock.calls[0][0].createdAt.$gte as Date
      expect(since.getUTCHours()).toBe(0)
      expect(since.getUTCMinutes()).toBe(0)
      expect(Date.now() - since.getTime()).toBeLessThan(24 * 3600 * 1000)
    })
  })

  describe('unpaid renewal grace period', () => {
    const DAY = 24 * 60 * 60 * 1000
    const proPlan = { _id: 'plan_pro', name: 'pro', dailyLimit: -1, monthlyLimit: 5000, bulkSendLimit: -1 }
    const customPlan = { _id: 'plan_c', name: 'custom-acme', dailyLimit: 1000, monthlyLimit: 10000, bulkSendLimit: 500 }
    const daysAgo = (days: number) => new Date(Date.now() - days * DAY)
    const givenPastDue = (days: number, fields: Record<string, unknown> = {}, plan: any = proPlan) => {
      mockSubscriptionModel.findOne.mockResolvedValue({
        plan: plan._id,
        status: 'past_due',
        pastDueAt: daysAgo(days),
        ...fields,
      })
      mockPlanModel.findById.mockResolvedValue(plan)
    }
    const givenCounts = (today: number, thisPeriod: number) =>
      mockSmsModel.countDocuments.mockResolvedValueOnce(today).mockResolvedValueOnce(thisPeriod)
    const notices = () => mockBillingNotifications.notifyOnce.mock.calls.map(([n]) => n)
    const original = process.env.PAYMENT_GRACE_DAYS

    beforeEach(() => {
      process.env.PAYMENT_GRACE_DAYS = '3'
      givenUser({ emailVerifiedAt: new Date() })
    })

    afterEach(() => {
      if (original === undefined) delete process.env.PAYMENT_GRACE_DAYS
      else process.env.PAYMENT_GRACE_DAYS = original
    })

    it.each([undefined, '', 'soon', '-1'])('keeps the plan limits when the setting is %p', async (value) => {
      if (value === undefined) delete process.env.PAYMENT_GRACE_DAYS
      else process.env.PAYMENT_GRACE_DAYS = value
      givenPastDue(10)
      givenCounts(60, 400)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
    })

    it('keeps the plan limits inside the grace period', async () => {
      givenPastDue(2)
      givenCounts(60, 400)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
    })

    it('applies the free daily limit after the grace period', async () => {
      givenPastDue(4)
      givenCounts(50, 120)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
        response: {
          hasReachedLimit: true,
          paymentHold: true,
          dailyLimit: 50,
          monthlyLimit: 300,
          message: expect.stringContaining('payment did not go through'),
        },
      })

      expect(notices()).toHaveLength(1)
      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.DAILY_LIMIT_REACHED,
        title: 'Your limits are reduced until your payment goes through',
        emailKey: null,
        recordHit: false,
        meta: { paymentHold: true, planName: 'pro' },
      })
      expect(notices()[0].message).not.toContain('upgrade')
    })

    it('applies the free monthly limit without the paid allowance', async () => {
      givenPastDue(4)
      givenCounts(10, 300)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
        response: { paymentHold: true, monthlyLimit: 300 },
      })
      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.MONTHLY_LIMIT_REACHED,
        emailKey: null,
      })
    })

    it('applies the free batch limit after the grace period', async () => {
      givenPastDue(4)
      givenCounts(0, 0)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 60)).rejects.toMatchObject({
        status: 429,
        response: { paymentHold: true, bulkSendLimit: 50 },
      })
    })

    it('allows a send within the reduced limits and raises no usage notice', async () => {
      givenPastDue(4)
      givenCounts(45, 100)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
      expect(mockBillingNotifications.notifyOnce).not.toHaveBeenCalled()
    })

    describe('at the boundary', () => {
      const now = new Date('2026-11-15T12:00:00.000Z')

      beforeEach(() => {
        jest.useFakeTimers().setSystemTime(now)
        givenUser({ emailVerifiedAt: now })
      })

      afterEach(() => jest.useRealTimers())

      const givenPastDueAt = (pastDueAt: unknown) => {
        mockSubscriptionModel.findOne.mockResolvedValue({
          plan: proPlan._id,
          status: 'past_due',
          pastDueAt,
        })
        mockPlanModel.findById.mockResolvedValue(proPlan)
      }

      it('starts exactly at the end of the grace period', async () => {
        givenPastDueAt(new Date(now.getTime() - 3 * DAY))
        givenCounts(50, 120)

        await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
          response: { paymentHold: true },
        })
      })

      it('keeps the plan limits one millisecond earlier', async () => {
        givenPastDueAt(new Date(now.getTime() - 3 * DAY + 1))
        givenCounts(60, 400)

        await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
          overLimit: false,
        })
      })

      it('reads a date stored as text', async () => {
        givenPastDueAt(new Date(now.getTime() - 4 * DAY).toISOString())
        givenCounts(50, 120)

        await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
          response: { paymentHold: true },
        })
      })

      it('applies at once when the setting is 0', async () => {
        process.env.PAYMENT_GRACE_DAYS = '0'
        givenPastDueAt(now)
        givenCounts(50, 120)

        await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
          response: { paymentHold: true },
        })
      })
    })

    it('never loosens a limit set on the account', async () => {
      givenPastDue(4, { customDailyLimit: 10, customMonthlyLimit: 100, customBulkSendLimit: 5 })
      givenCounts(10, 20)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        response: { paymentHold: true, dailyLimit: 10, monthlyLimit: 100, bulkSendLimit: 5 },
      })
    })

    it('tightens a looser limit set on the account', async () => {
      givenPastDue(4, { customDailyLimit: 2000, customMonthlyLimit: -1 })
      givenCounts(50, 120)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        response: { paymentHold: true, dailyLimit: 50, monthlyLimit: 300 },
      })
    })

    it('ignores the status on the free plan', async () => {
      mockSubscriptionModel.findOne.mockResolvedValue({
        plan: freePlan._id,
        status: 'past_due',
        pastDueAt: daysAgo(10),
      })
      mockPlanModel.findById.mockResolvedValue(freePlan)
      givenCounts(50, 120)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        response: { message: expect.stringContaining('upgrade your plan') },
      })
      expect(notices()[0]).toMatchObject({ emailKey: 'U4', recordHit: true })
    })

    it('explains a batch that does not fit the reduced limits', async () => {
      givenPastDue(4)
      givenCounts(45, 100)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 10)).rejects.toMatchObject({
        status: 429,
        response: {
          paymentHold: true,
          message: expect.stringMatching(
            /^This batch had 10 recipients and your account has 5 messages left today\. Nothing was sent\. Your limits are reduced because your last payment did not go through\./,
          ),
        },
      })
      expect(notices()[0]).toMatchObject({
        title: 'Your limits are reduced until your payment goes through',
        emailKey: null,
      })
    })

    it('reports an oversized batch without an email', async () => {
      givenPastDue(4)
      givenCounts(0, 0)

      await expect(service.canPerformAction(userId, 'bulk_send_sms', 60)).rejects.toMatchObject({
        response: { message: expect.stringContaining('batches are limited to 50 recipients') },
      })
      expect(notices()[0]).toMatchObject({
        type: BillingNotificationType.BULK_SMS_LIMIT_REACHED,
        emailKey: null,
        recordHit: false,
        meta: { paymentHold: true },
      })
    })

    describe('received messages', () => {
      const originalReceive = process.env.RECEIVE_SMS_OVER_LIMIT

      afterEach(() => {
        if (originalReceive === undefined) delete process.env.RECEIVE_SMS_OVER_LIMIT
        else process.env.RECEIVE_SMS_OVER_LIMIT = originalReceive
      })

      it('are stored over the reduced limits by default', async () => {
        delete process.env.RECEIVE_SMS_OVER_LIMIT
        givenPastDue(4)
        givenCounts(50, 120)

        await expect(service.canPerformAction(userId, 'receive_sms', 1)).resolves.toEqual({
          overLimit: true,
        })
        expect(notices()[0]).toMatchObject({
          title: 'Your limits are reduced until your payment goes through',
          emailKey: null,
          recordHit: false,
        })
      })

      it('are refused when the setting says so', async () => {
        process.env.RECEIVE_SMS_OVER_LIMIT = 'reject'
        givenPastDue(4)
        givenCounts(50, 120)

        await expect(service.canPerformAction(userId, 'receive_sms', 1)).rejects.toMatchObject({
          status: 429,
          response: { paymentHold: true },
        })
      })
    })

    it('reports the reduced limits on the current subscription', async () => {
      const subscription = {
        plan: proPlan,
        status: 'past_due',
        pastDueAt: daysAgo(4),
        toObject: () => ({ status: 'past_due' }),
      }
      mockSubscriptionModel.findOne.mockReturnValue({
        populate: jest.fn().mockResolvedValue(subscription),
      })
      givenCounts(12, 80)

      await expect(
        service.getCurrentSubscription({ _id: userId, createdAt: daysAgo(90) }),
      ).resolves.toMatchObject({
        status: 'past_due',
        usage: { paymentHold: true, dailyLimit: 50, monthlyLimit: 300 },
      })
    })

    it.each([
      ['the status is active again', { status: 'active' }],
      ['the status is missing', { status: undefined }],
      ['the date is missing', { pastDueAt: undefined }],
      ['the date is not a date', { pastDueAt: 'never' }],
    ])('keeps the plan limits when %s', async (_name, fields) => {
      givenPastDue(10, fields)
      givenCounts(60, 400)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
    })

    it('keeps the limits of a custom plan', async () => {
      givenPastDue(10, {}, customPlan)
      givenCounts(60, 400)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
    })

    it('keeps the plan limits when the free plan cannot be read', async () => {
      givenPastDue(10)
      mockPlanModel.findOne.mockResolvedValue(null)
      givenCounts(60, 400)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).resolves.toEqual({
        overLimit: false,
      })
    })

    it('reports the reduced limits in the usage summary', async () => {
      select.mockResolvedValue({ _id: userId, createdAt: daysAgo(90) })
      givenPastDue(4)
      givenCounts(12, 80)

      await expect(service.getUsage(userId)).resolves.toMatchObject({
        paymentHold: true,
        dailyLimit: 50,
        monthlyLimit: 300,
        bulkSendLimit: 50,
        dailyRemaining: 38,
        monthlyRemaining: 220,
      })
    })

    it('reports the plan limits in the usage summary inside the grace period', async () => {
      select.mockResolvedValue({ _id: userId, createdAt: daysAgo(90) })
      givenPastDue(1)
      givenCounts(12, 80)

      await expect(service.getUsage(userId)).resolves.toMatchObject({
        paymentHold: false,
        dailyLimit: -1,
        monthlyLimit: 5000,
      })
    })
  })

  describe('billing period', () => {
    const signedUp = new Date('2026-01-17T22:15:00.000Z')
    const proPlan = { _id: 'plan_pro', name: 'pro', dailyLimit: -1, monthlyLimit: 5000, bulkSendLimit: -1 }
    const monthlySince = () =>
      mockSmsModel.countDocuments.mock.calls[1][0].createdAt.$gte as Date

    beforeEach(() => {
      jest.useFakeTimers({ now: new Date('2026-10-04T08:00:00.000Z') })
      givenUser({ emailVerifiedAt: new Date(), createdAt: signedUp })
    })

    afterEach(() => jest.useRealTimers())

    it('counts a free account from its last signup anniversary', async () => {
      await service.canPerformAction(userId, 'send_sms', 1)

      expect(monthlySince().toISOString()).toBe('2026-09-17T22:15:00.000Z')
    })

    it('counts a paid account from its last subscription anniversary and ignores stored period ends', async () => {
      mockSubscriptionModel.findOne.mockResolvedValue({
        plan: proPlan._id,
        subscriptionStartDate: new Date('2026-06-03T08:00:00.000Z'),
        currentPeriodEnd: new Date('2026-07-03T08:00:00.000Z'),
        subscriptionEndDate: new Date('2026-07-03T08:00:00.000Z'),
      })
      mockPlanModel.findById.mockResolvedValue(proPlan)

      await service.canPerformAction(userId, 'send_sms', 1)

      expect(monthlySince().toISOString()).toBe('2026-10-03T08:00:00.000Z')
    })

    it('falls back to the user id time when the signup date is missing', async () => {
      givenUser({ emailVerifiedAt: new Date(), createdAt: undefined })

      await service.canPerformAction(userId, 'send_sms', 1)

      // 507f1f77... was generated on 2012-10-17T21:13:27Z.
      expect(monthlySince().toISOString()).toBe('2026-09-17T21:13:27.000Z')
    })

    it('says when the allowance resets', async () => {
      mockSmsModel.countDocuments.mockResolvedValueOnce(0).mockResolvedValueOnce(300)

      await expect(service.canPerformAction(userId, 'send_sms', 1)).rejects.toMatchObject({
        status: 429,
        response: {
          monthlyResetAt: new Date('2026-10-17T22:15:00.000Z'),
          message: expect.stringContaining(
            'Sending starts again when the allowance resets on 17 October at 22:15 UTC',
          ),
        },
      })
      expect(mockBillingNotifications.notifyOnce).toHaveBeenCalledWith(
        expect.objectContaining({
          meta: expect.objectContaining({
            monthlyPeriodStart: new Date('2026-09-17T22:15:00.000Z'),
            monthlyResetAt: new Date('2026-10-17T22:15:00.000Z'),
          }),
        }),
      )
    })

    it('passes the period to the approaching notice', async () => {
      mockSmsModel.countDocuments.mockResolvedValueOnce(0).mockResolvedValueOnce(250)

      await service.canPerformAction(userId, 'send_sms', 1)

      expect(mockBillingNotifications.notifyOnce).toHaveBeenCalledWith(
        expect.objectContaining({
          type: BillingNotificationType.MONTHLY_LIMIT_APPROACHING,
          message:
            'Your account has used 251 of its 300 messages for this billing period, counting sent and received. 49 are left. The allowance resets on 17 October at 22:15 UTC.',
          meta: expect.objectContaining({
            monthlyPeriodStart: new Date('2026-09-17T22:15:00.000Z'),
          }),
        }),
      )
    })
  })
})

/*
 * Reporting a sale to an ad platform more than once teaches it to bid on the
 * wrong thing, so the first-payment event has to survive the shapes Polar
 * actually sends: created then active for one signup, an upgrade that creates a
 * second subscription row, a renewal, and a re-subscribe after a revoke.
 */
describe('BillingService - first payment reporting', () => {
  let service: BillingService

  const userId = '507f1f77bcf86cd799439011'
  const proPlan = { _id: 'plan_pro', name: 'pro' }

  const mockPlanModel = { findOne: jest.fn() }
  const mockSubscriptionModel = {
    find: jest.fn(),
    findOneAndUpdate: jest.fn(),
    updateMany: jest.fn(),
  }
  const mockUserModel = { findById: jest.fn() }
  const mockUsersService = { markMilestone: jest.fn() }
  const mockAnalyticsService = { purchase: jest.fn(), checkoutStarted: jest.fn() }
  const emptyModel = {}

  const activePayment = {
    userId,
    newPlanName: 'pro',
    status: 'active',
    amount: 1200,
    currency: 'usd',
    polarSubscriptionId: 'sub_1',
  }

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BillingService,
        { provide: getModelToken(Plan.name), useValue: mockPlanModel },
        {
          provide: getModelToken(Subscription.name),
          useValue: mockSubscriptionModel,
        },
        { provide: getModelToken(User.name), useValue: mockUserModel },
        { provide: getModelToken(SMS.name), useValue: emptyModel },
        {
          provide: getModelToken(PolarWebhookPayload.name),
          useValue: emptyModel,
        },
        { provide: getModelToken(CheckoutSession.name), useValue: emptyModel },
        { provide: getModelToken(CheckoutAttempt.name), useValue: emptyModel },
        { provide: BillingNotificationsService, useValue: {} },
        { provide: UsersService, useValue: mockUsersService },
        { provide: AnalyticsService, useValue: mockAnalyticsService },
        { provide: CheckoutPromotionService, useValue: noPromotion },
      ],
    }).compile()

    service = module.get<BillingService>(BillingService)

    jest.clearAllMocks()
    mockPlanModel.findOne.mockResolvedValue(proPlan)
    mockSubscriptionModel.find.mockResolvedValue([])
    mockSubscriptionModel.findOneAndUpdate.mockResolvedValue({ _id: 'row_1' })
    mockSubscriptionModel.updateMany.mockResolvedValue({ modifiedCount: 0 })
    mockUserModel.findById.mockResolvedValue({
      _id: userId,
      email: 'ada@example.com',
    })
    mockUsersService.markMilestone.mockResolvedValue(true)
  })

  it('clears the end cause when the subscription runs again', async () => {
    await service.switchPlan(activePayment)

    const [filter, update] = mockSubscriptionModel.findOneAndUpdate.mock.calls[0]
    expect(filter).toMatchObject({ polarSubscriptionId: 'sub_1', plan: proPlan._id, polarEndedAt: null })
    expect(update.$unset).toEqual({ churnCause: 1 })
    expect(update.$set.isActive).toBe(true)
  })

  it.each([
    ['scheduled to cancel', { cancelAtPeriodEnd: true }],
    ['past due', { status: 'past_due' }],
  ])('keeps the end cause while the subscription is %s', async (_l, change) => {
    await service.switchPlan({ ...activePayment, ...change })

    expect(mockSubscriptionModel.findOneAndUpdate.mock.calls[0][1]).not.toHaveProperty('$unset')
  })

  it('reports the sale the first time an account pays', async () => {
    await service.switchPlan(activePayment)

    expect(mockUsersService.markMilestone).toHaveBeenCalledWith(
      userId,
      'firstPaidAt',
    )
    expect(mockAnalyticsService.purchase).toHaveBeenCalledWith(
      expect.objectContaining({ email: 'ada@example.com' }),
      expect.objectContaining({
        amount: 1200,
        currency: 'usd',
        plan: 'pro',
        subscriptionId: 'sub_1',
      }),
    )
  })

  it('reports nothing on a renewal, an upgrade, or a re-subscribe', async () => {
    // The milestone is already stamped, so every later payment is a no-op
    // regardless of whether the subscription row was created or updated.
    mockUsersService.markMilestone.mockResolvedValue(false)

    await service.switchPlan(activePayment)

    // An upgrade creates a second row for the new plan, which a row count
    // would have treated as a brand new sale.
    await service.switchPlan({ ...activePayment, newPlanName: 'scale' })

    expect(mockAnalyticsService.purchase).not.toHaveBeenCalled()
  })

  it('ignores a subscription that is not active yet', async () => {
    // subscription.created can arrive before the card is charged.
    await service.switchPlan({ ...activePayment, status: 'incomplete' })
    await service.switchPlan({ ...activePayment, status: 'trialing' })

    expect(mockUsersService.markMilestone).not.toHaveBeenCalled()
    expect(mockAnalyticsService.purchase).not.toHaveBeenCalled()
  })

  it('ignores an event that carries no money', async () => {
    await service.switchPlan({ ...activePayment, amount: undefined })
    await service.switchPlan({ ...activePayment, amount: 0 })

    expect(mockUsersService.markMilestone).not.toHaveBeenCalled()
    expect(mockAnalyticsService.purchase).not.toHaveBeenCalled()
  })

  it('still switches the plan when reporting fails', async () => {
    mockUsersService.markMilestone.mockRejectedValue(new Error('mongo down'))

    await expect(service.switchPlan(activePayment)).resolves.toEqual({
      success: true,
      plan: 'pro',
    })
  })
})

describe('BillingService - reads raise no usage notices', () => {
  it('getCurrentSubscription does not notify at 100% usage', async () => {
    const notifyOnce = jest.fn()
    const freePlan = { name: 'free', dailyLimit: 50, monthlyLimit: 300, bulkSendLimit: 50 }
    const service = new BillingService(
      { findOne: jest.fn().mockResolvedValue(freePlan) } as any,
      { findOne: jest.fn(() => ({ populate: jest.fn().mockResolvedValue(null) })) } as any,
      {} as any,
      { countDocuments: jest.fn().mockResolvedValue(300) } as any,
      {} as any,
      {} as any,
      { notifyOnce } as any,
      {} as any,
      {} as any,
      {} as any,
      { getLivePromotion: async () => null } as any,
    )

    const result = await service.getCurrentSubscription({
      _id: '507f1f77bcf86cd799439011',
      createdAt: new Date('2020-01-17T22:15:00.000Z'),
    })

    expect(result.usage.monthlyRemaining).toBe(0)
    expect(result.usage.monthlyResetAt.getTime()).toBeGreaterThan(Date.now())
    expect(result.usage.monthlyPeriodStart.getUTCDate()).toBe(17)
    expect(notifyOnce).not.toHaveBeenCalled()
  })
})

describe('BillingService - payment retry state and end cause', () => {
  const eventAt = new Date('2026-09-20T12:00:00Z')
  const build = ({ pastDue = null as any, storedPastDue = null as any } = {}) => {
    const subscriptionModel = {
      updateMany: jest.fn().mockResolvedValue({}),
      exists: jest.fn().mockResolvedValue(pastDue),
    }
    const payloadModel = { exists: jest.fn().mockResolvedValue(storedPastDue) }
    const service = new BillingService(
      {} as any,
      subscriptionModel as any,
      {} as any,
      {} as any,
      payloadModel as any,
      {} as any,
      {} as any,
      {} as any,
      {} as any,
      {} as any,
      { getLivePromotion: async () => null } as any,
    )
    return { service, subscriptionModel, payloadModel }
  }
  const failedCancel = {
    polarSubscriptionId: 'sub_1',
    status: 'canceled',
    cancelAtPeriodEnd: false,
    endsAt: new Date('2026-09-20T13:00:00Z'),
    eventAt,
  }

  const newer = {
    polarSubscriptionId: 'sub_1',
    $or: [{ statusEventAt: null }, { statusEventAt: { $lt: eventAt } }],
  }

  it('keeps the first retry period start when the provider gives none', async () => {
    const { service, subscriptionModel } = build()

    await service.syncPastDue({ polarSubscriptionId: 'sub_1', status: 'past_due', eventAt })

    expect(subscriptionModel.updateMany).toHaveBeenNthCalledWith(
      1,
      { ...newer, isActive: true, pastDueAt: null },
      { $set: { pastDueAt: eventAt, statusEventAt: eventAt } },
    )
    expect(subscriptionModel.updateMany).toHaveBeenNthCalledWith(
      2,
      { ...newer, isActive: true },
      { $set: { statusEventAt: eventAt } },
    )
  })

  it('uses the provider time when present', async () => {
    const { service, subscriptionModel } = build()

    await service.syncPastDue({
      polarSubscriptionId: 'sub_1',
      status: 'past_due',
      pastDueAt: '2026-09-18T00:00:00Z',
      eventAt,
    })

    expect(subscriptionModel.updateMany).toHaveBeenCalledWith(
      { ...newer, isActive: true },
      { $set: { pastDueAt: new Date('2026-09-18T00:00:00Z'), statusEventAt: eventAt } },
    )
  })

  it('clears the retry period only for an event newer than the last one applied', async () => {
    const { service, subscriptionModel } = build()

    await service.syncPastDue({ polarSubscriptionId: 'sub_1', status: 'active', eventAt })

    expect(subscriptionModel.updateMany).toHaveBeenCalledWith(newer, {
      $set: { statusEventAt: eventAt },
      $unset: { pastDueAt: 1 },
    })
  })

  it('ignores other statuses', async () => {
    const { service, subscriptionModel } = build()

    await service.syncPastDue({ polarSubscriptionId: 'sub_1', status: 'canceled', eventAt })

    expect(subscriptionModel.updateMany).not.toHaveBeenCalled()
  })

  it('reads an immediate end after a retry period as payment_failed', async () => {
    const { service } = build({ pastDue: { _id: 's' } })

    await expect(service.churnCause(failedCancel)).resolves.toBe('payment_failed')
  })

  it('falls back to a stored past_due payload from the last 35 days', async () => {
    const { service, payloadModel } = build({ storedPastDue: { _id: 'p' } })

    await expect(service.churnCause(failedCancel)).resolves.toBe('payment_failed')
    const filter = payloadModel.exists.mock.calls[0][0]
    expect(filter).toMatchObject({
      'payload.data.id': 'sub_1',
      'payload.data.status': 'past_due',
    })
    expect(eventAt.getTime() - filter.createdAt.$gte.getTime()).toBe(35 * 86400000)
  })

  it.each([
    ['a scheduled cancellation', { cancelAtPeriodEnd: true }],
    ['a status that is still active', { status: 'active' }],
    ['an end more than 3 hours away', { endsAt: new Date('2026-09-20T15:30:00Z') }],
    ['no end date', { endsAt: null }],
  ])('reads %s as customer', async (_label, change) => {
    const { service } = build({ pastDue: { _id: 's' } })

    await expect(service.churnCause({ ...failedCancel, ...change })).resolves.toBe('customer')
  })

  it('reads an immediate end without a retry period as customer', async () => {
    const { service } = build()

    await expect(service.churnCause(failedCancel)).resolves.toBe('customer')
  })
})

describe('BillingService - new checkout session', () => {
  it('restarts the stored session on every new checkout', async () => {
    const plan = { name: 'pro', polarMonthlyProductId: 'prod_m', polarYearlyProductId: 'prod_y' }
    const checkoutSessionModel = {
      findOne: jest.fn().mockResolvedValue(null),
      updateOne: jest.fn().mockReturnValue({ catch: jest.fn() }),
    }
    const service = new BillingService(
      { findOne: jest.fn().mockResolvedValue(plan) } as any,
      { findOne: jest.fn(() => ({ populate: jest.fn().mockResolvedValue(null) })) } as any,
      {} as any,
      {} as any,
      {} as any,
      checkoutSessionModel as any,
      {} as any,
      {} as any,
      { checkoutStarted: jest.fn() } as any,
      {} as any,
      { getLivePromotion: async () => null } as any,
    )
    ;(service as any).polarApi = {
      checkouts: {
        create: jest.fn().mockResolvedValue({
          id: 'co_2',
          url: 'https://pay.test/co_2',
          expires_at: '2026-09-28T00:00:00Z',
        }),
      },
      discounts: { get: jest.fn() },
    }
    delete process.env.POLAR_DEFAULT_DISCOUNT_ID

    await service.getCheckoutUrl({
      user: { _id: new Types.ObjectId('507f1f77bcf86cd799439011'), email: 'a@example.com' },
      payload: { planName: 'pro', billingInterval: 'monthly' },
      req: { ip: '127.0.0.1', headers: {} },
    })

    expect((service as any).polarApi.checkouts.create).toHaveBeenCalledWith(
      expect.objectContaining({
        products: ['prod_m', 'prod_y'],
        external_customer_id: '507f1f77bcf86cd799439011',
        customer_email: 'a@example.com',
        customer_ip_address: '127.0.0.1',
        success_url: expect.stringContaining('checkout-success=1'),
      }),
    )

    const [filter, update, options] = checkoutSessionModel.updateOne.mock.calls[0]
    expect(filter).toEqual({ user: expect.any(Types.ObjectId) })
    expect(update.$set).toMatchObject({
      checkoutSessionId: 'co_2',
      isCompleted: false,
      isAbandoned: false,
    })
    expect(update.$set.sessionStartedAt).toBeInstanceOf(Date)
    expect(update.$set.expiresAt).toEqual(new Date('2026-09-28T00:00:00Z'))
    expect(update.$unset).toEqual({ completedAt: 1 })
    expect(options).toEqual({ upsert: true })
  })
})

describe('BillingService - Polar SDK calls', () => {
  const env = { ...process.env }
  const userId = new Types.ObjectId('507f1f77bcf86cd799439011')

  const build = ({
    plan = null as any,
    current = null as any,
    promotion = null as any,
  } = {}) => {
    const subscriptionModel = {
      findOne: jest.fn(() => ({ populate: jest.fn().mockResolvedValue(current) })),
      updateOne: jest.fn().mockReturnValue({ catch: jest.fn() }),
    }
    const checkoutSessionModel = {
      updateOne: jest.fn().mockReturnValue({ catch: jest.fn() }),
    }
    const checkoutAttemptModel = { create: jest.fn().mockResolvedValue({}) }
    const service = new BillingService(
      { findOne: jest.fn().mockResolvedValue(plan) } as any,
      subscriptionModel as any,
      {} as any,
      {} as any,
      {} as any,
      checkoutSessionModel as any,
      {} as any,
      {} as any,
      {} as any,
      checkoutAttemptModel as any,
      { getLivePromotion: async () => promotion } as any,
    )
    return { service, subscriptionModel, checkoutAttemptModel }
  }

  afterEach(() => {
    process.env = env
    jest.restoreAllMocks()
  })

  describe('webhook validation', () => {
    const secret = 'whsec_test_secret'

    const signed = (event: Record<string, any>, key = secret) => {
      const body = Buffer.from(JSON.stringify(event))
      const id = 'msg_1'
      const timestamp = Math.floor(Date.now() / 1000).toString()
      // The previous SDK signed with the UTF-8 bytes of the whole secret
      const signature = createHmac('sha256', Buffer.from(key, 'utf8'))
        .update(`${id}.${timestamp}.${body.toString()}`)
        .digest('base64')
      return {
        body,
        headers: {
          'webhook-id': id,
          'webhook-timestamp': timestamp,
          'webhook-signature': `v1,${signature}`,
        },
      }
    }

    beforeEach(() => {
      process.env = { ...env, POLAR_WEBHOOK_SECRET: secret }
      jest.spyOn(console, 'log').mockImplementation(() => undefined)
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
    })

    it('returns the raw event for a valid signature', async () => {
      const { service } = build()
      const event = {
        type: 'subscription.updated',
        timestamp: '2026-09-29T00:00:00Z',
        data: { id: 'sub_1', cancel_at_period_end: true },
      }
      const { body, headers } = signed(event)

      await expect(service.validatePolarWebhookPayload(body, headers)).resolves.toEqual(event)
    })

    it('returns null for a signed event type the SDK does not know', async () => {
      const { service } = build()
      const { body, headers } = signed({ type: 'something.new', data: {} })

      await expect(service.validatePolarWebhookPayload(body, headers)).resolves.toBeNull()
    })

    it('rejects a payload signed with another secret', async () => {
      const { service } = build()
      const { body, headers } = signed({ type: 'subscription.updated', data: {} }, 'whsec_other')

      await expect(service.validatePolarWebhookPayload(body, headers)).rejects.toThrow(
        'Invalid webhook payload',
      )
    })
  })

  describe('plan change', () => {
    const plan = { name: 'pro', polarMonthlyProductId: 'prod_pro_m', polarYearlyProductId: 'prod_pro_y' }
    const current = {
      _id: 'local_sub',
      plan: { name: 'starter' },
      recurringInterval: 'month',
      polarSubscriptionId: 'sub_1',
    }
    const polarSubscription = {
      id: 'sub_1',
      status: 'active',
      product_id: 'prod_starter_m',
      customer_id: 'cus_1',
      cancel_at_period_end: true,
    }
    const updated = {
      ...polarSubscription,
      product_id: 'prod_pro_m',
      cancel_at_period_end: false,
      current_period_start: '2026-09-01T00:00:00Z',
      current_period_end: '2026-10-01T00:00:00Z',
      started_at: '2026-08-01T00:00:00Z',
      created_at: '2026-07-31T00:00:00Z',
      canceled_at: null,
      amount: 1499,
      currency: 'usd',
      recurring_interval: 'month',
    }

    it('updates the subscription by id and stores dates as Date values', async () => {
      const { service } = build({ plan, current })
      const update = jest.fn().mockResolvedValue(updated)
      ;(service as any).polarApi = {
        subscriptions: { get: jest.fn().mockResolvedValue(polarSubscription), update },
      }
      const switchPlan = jest.spyOn(service, 'switchPlan').mockResolvedValue({} as any)

      await service.changePlan({
        user: { _id: userId },
        payload: { planName: 'pro', billingInterval: 'monthly' },
      })

      expect((service as any).polarApi.subscriptions.get).toHaveBeenCalledWith('sub_1')
      expect(update).toHaveBeenNthCalledWith(1, 'sub_1', { cancel_at_period_end: false })
      expect(update).toHaveBeenNthCalledWith(2, 'sub_1', { product_id: 'prod_pro_m' })
      expect(switchPlan).toHaveBeenCalledWith({
        userId: userId.toString(),
        newPlanPolarProductId: 'prod_pro_m',
        currentPeriodStart: new Date('2026-09-01T00:00:00Z'),
        currentPeriodEnd: new Date('2026-10-01T00:00:00Z'),
        subscriptionStartDate: new Date('2026-08-01T00:00:00Z'),
        endsAt: undefined,
        endedAt: undefined,
        modifiedAt: undefined,
        status: 'active',
        amount: 1499,
        currency: 'usd',
        recurringInterval: 'month',
        polarSubscriptionId: 'sub_1',
        polarCustomerId: 'cus_1',
        cancelAtPeriodEnd: false,
      })
    })

    describe('live promotion', () => {
      const promotion = {
        discount: {
          id: 'disc_live',
          name: 'Spring offer',
          type: 'percentage',
          basis_points: 3000,
          duration: 'forever',
          starts_at: null,
          ends_at: null,
          max_redemptions: null,
          redemptions_count: 0,
          products: [{ id: 'prod_pro_y' }],
        },
      }
      const active = { ...polarSubscription, cancel_at_period_end: false }
      const flush = () => new Promise((resolve) => setImmediate(resolve))
      const change = (
        service: BillingService,
        billingInterval = 'yearly',
        extra: Record<string, unknown> = {},
      ) =>
        service.changePlan({
          user: { _id: userId },
          payload: { planName: 'pro', billingInterval, ...extra },
        })
      const setup = (subscription: any = active) => {
        const built = build({ plan, current, promotion })
        const update = jest.fn().mockResolvedValue({
          ...updated,
          product_id: 'prod_pro_y',
          discount_id: 'disc_live',
        })
        ;(built.service as any).polarApi = {
          subscriptions: { get: jest.fn().mockResolvedValue(subscription), update },
        }
        const switchPlan = jest.spyOn(built.service, 'switchPlan').mockResolvedValue({} as any)
        return { ...built, update, switchPlan }
      }

      it('applies a covering promotion in the same update as the product', async () => {
        const { service, update, switchPlan, checkoutAttemptModel } = setup()

        await change(service)
        await flush()

        expect(update).toHaveBeenCalledTimes(1)
        expect(update).toHaveBeenCalledWith('sub_1', {
          product_id: 'prod_pro_y',
          discount_id: 'disc_live',
        })
        expect(switchPlan.mock.calls[0][0].discountId).toBe('disc_live')
        expect(checkoutAttemptModel.create.mock.calls[0][0].discountId).toBe('disc_live')
      })

      it('keeps a discount the subscription already has', async () => {
        const { service, update, checkoutAttemptModel } = setup({
          ...active,
          discount_id: 'disc_existing',
        })

        await change(service)
        await flush()

        expect(update).toHaveBeenCalledWith('sub_1', { product_id: 'prod_pro_y' })
        expect(checkoutAttemptModel.create.mock.calls[0][0].discountId).toBeNull()
      })

      it('sends no discount when the promotion does not cover the new product', async () => {
        const { service, update } = setup()

        await change(service, 'monthly')

        expect(update).toHaveBeenCalledWith('sub_1', { product_id: 'prod_pro_m' })
      })

      it('retries once without the discount when Polar refuses it', async () => {
        const { service, update, checkoutAttemptModel } = setup()
        const warn = jest.spyOn(console, 'warn').mockImplementation(() => undefined)
        update.mockRejectedValueOnce(
          new errors.HTTPValidationError(422, {
            detail: [
              {
                loc: ['body', 'discount_id'],
                msg: 'Discount does not apply',
                type: 'value_error',
              },
            ],
          } as any),
        )

        await change(service)
        await flush()

        expect(update).toHaveBeenCalledTimes(2)
        expect(update).toHaveBeenNthCalledWith(1, 'sub_1', {
          product_id: 'prod_pro_y',
          discount_id: 'disc_live',
        })
        expect(update).toHaveBeenNthCalledWith(2, 'sub_1', { product_id: 'prod_pro_y' })
        expect(checkoutAttemptModel.create.mock.calls[0][0].discountId).toBeNull()
        expect(warn).toHaveBeenCalledWith(
          'plan change with promotion discount disc_live was refused (422) for plan pro (yearly), retrying without it',
        )
      })

      describe('when the subscriber confirmed the sale price', () => {
        const shown = { promotionShown: true }

        it('applies the promotion', async () => {
          const { service, update } = setup()

          await change(service, 'yearly', shown)

          expect(update).toHaveBeenCalledWith('sub_1', {
            product_id: 'prod_pro_y',
            discount_id: 'disc_live',
          })
        })

        it('refuses without retrying when Polar refuses the discount', async () => {
          const { service, update } = setup()
          update.mockRejectedValueOnce(
            new errors.HTTPValidationError(422, {
              detail: [{ loc: ['body', 'discount_id'], msg: 'No', type: 'value_error' }],
            } as any),
          )

          await expect(change(service, 'yearly', shown)).rejects.toMatchObject({
            response: { code: 'PROMOTION_UNAVAILABLE' },
          })
          expect(update).toHaveBeenCalledTimes(1)
        })

        it('restores a lifted cancellation when Polar refuses the discount', async () => {
          jest.spyOn(console, 'error').mockImplementation(() => undefined)
          const { service, update } = setup({ ...active, cancel_at_period_end: true })
          update
            .mockResolvedValueOnce({ ...active, cancel_at_period_end: false })
            .mockRejectedValueOnce(
              new errors.HTTPValidationError(422, {
                detail: [{ loc: ['body', 'discount_id'], msg: 'No', type: 'value_error' }],
              } as any),
            )

          await expect(change(service, 'yearly', shown)).rejects.toMatchObject({
            response: { code: 'PROMOTION_UNAVAILABLE' },
          })
          expect(update).toHaveBeenCalledTimes(3)
          expect(update).toHaveBeenNthCalledWith(3, 'sub_1', { cancel_at_period_end: true })
        })

        it('refuses when the live percentage differs from the one shown', async () => {
          const { service, update } = setup()

          await expect(
            change(service, 'yearly', { ...shown, promotionPercentOff: 50 }),
          ).rejects.toMatchObject({ response: { code: 'PROMOTION_UNAVAILABLE' } })
          expect(update).not.toHaveBeenCalled()
        })

        it.each([
          ['a string percentage', { ...shown, promotionPercentOff: '30' }],
          ['a string flag', { promotionShown: 'true' }],
        ])('refuses %s', async (_label, extra) => {
          const { service, update } = setup()

          await expect(change(service, 'yearly', extra)).rejects.toMatchObject({
            response: { code: 'PROMOTION_UNAVAILABLE' },
          })
          expect(update).not.toHaveBeenCalled()
        })

        it('goes ahead when the live percentage matches the one shown', async () => {
          const { service, update } = setup()

          await change(service, 'yearly', { ...shown, promotionPercentOff: 30 })

          expect(update).toHaveBeenCalledTimes(1)
        })

        it('logs when Polar drops the confirmed discount', async () => {
          const error = jest.spyOn(console, 'error').mockImplementation(() => undefined)
          const { service, update } = setup()
          update.mockResolvedValueOnce({ ...updated, product_id: 'prod_pro_y', discount_id: null })

          await change(service, 'yearly', shown)

          expect(error).toHaveBeenCalledWith(
            'plan change on sub_1 went through without the confirmed promotion discount disc_live',
          )
        })

        it('refuses before any update when the promotion does not apply', async () => {
          const { service, update } = setup({
            ...active,
            cancel_at_period_end: true,
            discount_id: 'disc_existing',
          })

          await expect(change(service, 'yearly', shown)).rejects.toMatchObject({
            response: { code: 'PROMOTION_UNAVAILABLE' },
          })
          expect(update).not.toHaveBeenCalled()
        })
      })

      it('records no discount when Polar drops it from the update', async () => {
        const { service, update, checkoutAttemptModel } = setup()
        update.mockResolvedValueOnce({ ...updated, product_id: 'prod_pro_y', discount_id: null })

        await change(service)
        await flush()

        expect(checkoutAttemptModel.create.mock.calls[0][0].discountId).toBeNull()
      })

      it('lifts a scheduled cancellation, then applies the promotion with the product', async () => {
        const { service, update } = setup({ ...active, cancel_at_period_end: true })

        await change(service)

        expect(update).toHaveBeenCalledTimes(2)
        expect(update).toHaveBeenNthCalledWith(1, 'sub_1', { cancel_at_period_end: false })
        expect(update).toHaveBeenNthCalledWith(2, 'sub_1', {
          product_id: 'prod_pro_y',
          discount_id: 'disc_live',
        })
      })

      it('does not retry a 422 that is not about the discount', async () => {
        jest.spyOn(console, 'error').mockImplementation(() => undefined)
        const { service, update } = setup()
        update.mockRejectedValueOnce(
          new errors.HTTPValidationError(422, {
            detail: [{ loc: ['body', 'product_id'], msg: 'Invalid', type: 'value_error' }],
          } as any),
        )

        await expect(change(service)).rejects.toMatchObject({
          response: { code: 'PLAN_CHANGE_FAILED' },
        })
        expect(update).toHaveBeenCalledTimes(1)
      })

      it.each([
        ['applies', active, 'yearly', true],
        ['does not apply to a subscription with a discount', { ...active, discount_id: 'disc_x' }, 'yearly', false],
        ['does not apply to an uncovered product', active, 'monthly', false],
      ])('tells the preview the promotion %s', async (_label, subscription, billingInterval, expected) => {
        const { service } = setup(subscription)

        const result: any = await service.getCheckoutUrl({
          user: { _id: userId },
          payload: { planName: 'pro', billingInterval },
          req: { headers: {} },
        })

        expect(result.planChange.promotionApplies).toBe(expected)
      })

      it('does not retry a declined payment', async () => {
        jest.spyOn(console, 'error').mockImplementation(() => undefined)
        const { service, update } = setup()
        update.mockRejectedValueOnce(
          new errors.SubscriptionsUpdate402Error(402, {
            error: 'PaymentFailed',
            detail: 'declined',
          } as any),
        )

        await expect(change(service)).rejects.toMatchObject({
          response: { code: 'PAYMENT_FAILED' },
        })
        expect(update).toHaveBeenCalledTimes(1)
      })
    })

    it('flags a scheduled cancellation on the plan change screen', async () => {
      const { service } = build({ plan, current })
      ;(service as any).polarApi = {
        subscriptions: { get: jest.fn().mockResolvedValue(polarSubscription) },
      }

      const result: any = await service.getCheckoutUrl({
        user: { _id: userId },
        payload: { planName: 'pro', billingInterval: 'monthly' },
        req: { headers: {} },
      })

      expect(result.planChange.cancelAtPeriodEnd).toBe(true)
    })

    it.each([
      ['PaymentFailed', { error: 'PaymentFailed', detail: 'declined' }],
      ['PaymentActionRequired', { error: 'PaymentActionRequired', detail: '3ds' }],
    ])('maps a 402 %s to PAYMENT_FAILED', async (_label, body) => {
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
      const { service } = build({ plan, current })
      ;(service as any).polarApi = {
        subscriptions: {
          get: jest.fn().mockResolvedValue({ ...polarSubscription, cancel_at_period_end: false }),
          update: jest
            .fn()
            .mockRejectedValue(new errors.SubscriptionsUpdate402Error(402, body as any)),
        },
      }

      await expect(
        service.changePlan({
          user: { _id: userId },
          payload: { planName: 'pro', billingInterval: 'monthly' },
        }),
      ).rejects.toMatchObject({
        status: 400,
        response: {
          code: 'PAYMENT_FAILED',
          message: 'Your card was declined. Update your payment method, then try again.',
        },
      })
    })

    it('finds the subscription by external customer id when the stored id fails', async () => {
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
      const { service, subscriptionModel } = build({ plan, current })
      const list = jest.fn().mockResolvedValue({ items: [polarSubscription], pagination: {} })
      ;(service as any).polarApi = {
        subscriptions: {
          get: jest.fn().mockRejectedValue(new Error('not found')),
          list,
          update: jest.fn().mockResolvedValue(updated),
        },
      }
      jest.spyOn(service, 'switchPlan').mockResolvedValue({} as any)

      await service.changePlan({
        user: { _id: userId },
        payload: { planName: 'pro', billingInterval: 'monthly' },
      })

      expect(list).toHaveBeenCalledWith({
        external_customer_id: userId.toString(),
        active: true,
        limit: 1,
      })
      expect(subscriptionModel.updateOne).toHaveBeenCalledWith(
        { _id: 'local_sub' },
        { polarSubscriptionId: 'sub_1', polarCustomerId: 'cus_1' },
      )
    })

    describe('same plan', () => {
      const onPro = { ...current, plan: { name: 'pro' } }
      const request = (service: BillingService) =>
        service.changePlan({
          user: { _id: userId },
          payload: { planName: 'pro', billingInterval: 'monthly' },
        })

      it('reports a payment issue before "already on plan"', async () => {
        const { service } = build({ plan, current: onPro })
        ;(service as any).polarApi = {
          subscriptions: {
            get: jest.fn().mockResolvedValue({
              ...polarSubscription,
              status: 'past_due',
              product_id: 'prod_pro_m',
            }),
          },
        }

        await expect(request(service)).rejects.toMatchObject({
          response: { code: 'PAYMENT_ISSUE' },
        })
      })

      it('uses the stored status when Polar has no subscription', async () => {
        jest.spyOn(console, 'error').mockImplementation(() => undefined)
        jest.spyOn(console, 'warn').mockImplementation(() => undefined)
        const { service } = build({
          plan,
          current: { ...onPro, status: 'past_due' },
        })
        ;(service as any).polarApi = {
          subscriptions: {
            get: jest.fn().mockRejectedValue(new Error('not found')),
            list: jest.fn().mockResolvedValue({ items: [], pagination: {} }),
          },
        }

        await expect(request(service)).rejects.toMatchObject({
          response: { code: 'PAYMENT_ISSUE' },
        })
      })

      it('ignores a leftover retry date once the stored status has moved on', async () => {
        jest.spyOn(console, 'error').mockImplementation(() => undefined)
        jest.spyOn(console, 'warn').mockImplementation(() => undefined)
        const { service } = build({
          plan,
          current: { ...onPro, status: 'canceled', pastDueAt: new Date('2026-10-01T00:00:00Z') },
        })
        ;(service as any).polarApi = {
          subscriptions: {
            get: jest.fn().mockRejectedValue(new Error('not found')),
            list: jest.fn().mockResolvedValue({ items: [], pagination: {} }),
          },
        }

        await expect(request(service)).rejects.toMatchObject({
          response: { code: 'ALREADY_ON_PLAN' },
        })
      })

      it('still reports "already on plan" when payments are fine', async () => {
        const { service } = build({ plan, current: onPro })
        ;(service as any).polarApi = {
          subscriptions: {
            get: jest.fn().mockResolvedValue({
              ...polarSubscription,
              product_id: 'prod_pro_m',
            }),
          },
        }

        await expect(request(service)).rejects.toMatchObject({
          response: { code: 'ALREADY_ON_PLAN' },
        })
      })
    })
  })
})

describe('BillingService - checkout attempts', () => {
  const userId = new Types.ObjectId('507f1f77bcf86cd799439011')
  const plan = { name: 'pro', polarMonthlyProductId: 'prod_m', polarYearlyProductId: 'prod_y' }
  const flush = () => new Promise((resolve) => setImmediate(resolve))

  const build = ({ current = null as any, cached = null as any } = {}) => {
    const checkoutSessionModel = {
      findOne: jest.fn().mockResolvedValue(cached),
      updateOne: jest.fn().mockReturnValue({ catch: jest.fn() }),
    }
    const checkoutAttemptModel = { create: jest.fn().mockResolvedValue({}) }
    const service = new BillingService(
      { findOne: jest.fn().mockResolvedValue(plan) } as any,
      {
        findOne: jest.fn(() => ({ populate: jest.fn().mockResolvedValue(current) })),
        updateOne: jest.fn().mockReturnValue({ catch: jest.fn() }),
      } as any,
      {} as any,
      {} as any,
      {} as any,
      checkoutSessionModel as any,
      {} as any,
      {} as any,
      { checkoutStarted: jest.fn() } as any,
      checkoutAttemptModel as any,
      { getLivePromotion: async () => null } as any,
    )
    const create = jest.fn().mockResolvedValue({
      id: 'co_9',
      url: 'https://pay.test/co_9',
      expires_at: '2026-11-01T00:00:00Z',
    })
    ;(service as any).polarApi = { checkouts: { create }, discounts: { get: jest.fn() } }
    return { service, checkoutAttemptModel, create }
  }

  const checkout = (service: BillingService, extra: Record<string, unknown> = {}) =>
    service.getCheckoutUrl({
      user: { _id: userId, email: 'a@example.com' },
      payload: { planName: 'pro', billingInterval: 'yearly', ...extra },
      req: { ip: '127.0.0.1', headers: {} },
    })

  beforeEach(() => {
    delete process.env.POLAR_DEFAULT_DISCOUNT_ID
  })
  afterEach(() => jest.restoreAllMocks())

  it('records a new checkout with its source and tags the provider metadata', async () => {
    const { service, checkoutAttemptModel, create } = build()

    await checkout(service, {
      from: 'app_billing',
      ref: 'x-1',
      priorFrom: 'email',
      priorRef: 'U1',
      fromCookie: false,
    })
    await flush()

    expect(checkoutAttemptModel.create).toHaveBeenCalledWith({
      user: userId,
      kind: 'checkout',
      planName: 'pro',
      billingInterval: 'yearly',
      from: 'app_billing',
      ref: 'x-1',
      priorFrom: 'email',
      priorRef: 'U1',
      fromCookie: false,
      checkoutSessionId: 'co_9',
      reusedCheckout: false,
      discountId: null,
    })
    expect(create.mock.calls[0][0].metadata).toMatchObject({
      checkoutFrom: 'app_billing',
      checkoutRef: 'x-1',
    })
  })

  it('drops invalid source values without failing the checkout', async () => {
    const { service, checkoutAttemptModel, create } = build()

    await expect(
      checkout(service, {
        from: 'App Billing!',
        ref: 'a'.repeat(65),
        priorFrom: 42,
        priorRef: 'ok_ref',
        fromCookie: 'yes',
      }),
    ).resolves.toEqual({ redirectUrl: 'https://pay.test/co_9' })
    await flush()

    const attempt = checkoutAttemptModel.create.mock.calls[0][0]
    expect(attempt).toMatchObject({ priorRef: 'ok_ref' })
    expect(attempt).not.toHaveProperty('from')
    expect(attempt).not.toHaveProperty('ref')
    expect(attempt).not.toHaveProperty('priorFrom')
    expect(attempt).not.toHaveProperty('fromCookie')
    expect(create.mock.calls[0][0].metadata).not.toHaveProperty('checkoutFrom')
    expect(create.mock.calls[0][0].metadata).not.toHaveProperty('checkoutRef')
  })

  it('records a reused cached checkout with its id', async () => {
    const cached = {
      checkoutSessionId: 'co_cached',
      checkoutUrl: 'https://pay.test/co_cached',
      planName: 'pro',
      billingInterval: 'yearly',
    }
    const { service, checkoutAttemptModel, create } = build({ cached })

    await expect(checkout(service, { from: 'email', ref: 'U2' })).resolves.toEqual({
      redirectUrl: 'https://pay.test/co_cached',
    })
    await flush()

    expect(create).not.toHaveBeenCalled()
    expect(checkoutAttemptModel.create).toHaveBeenCalledWith({
      user: userId,
      kind: 'checkout',
      planName: 'pro',
      billingInterval: 'yearly',
      from: 'email',
      ref: 'U2',
      checkoutSessionId: 'co_cached',
      reusedCheckout: true,
      discountId: null,
    })
  })

  it('never fails the checkout when the attempt write fails', async () => {
    const { service, checkoutAttemptModel } = build()
    const error = jest.spyOn(console, 'error').mockImplementation(() => undefined)
    checkoutAttemptModel.create.mockRejectedValue(new Error('db down'))

    await expect(checkout(service, { from: 'app_billing' })).resolves.toEqual({
      redirectUrl: 'https://pay.test/co_9',
    })
    await flush()

    expect(error).toHaveBeenCalledWith('failed to record checkout attempt', 'db down')
  })

  describe('plan change', () => {
    const current = {
      _id: 'local_sub',
      plan: { name: 'starter' },
      recurringInterval: 'month',
      polarSubscriptionId: 'sub_1',
    }
    const polarSubscription = {
      id: 'sub_1',
      status: 'active',
      product_id: 'prod_starter_m',
      customer_id: 'cus_1',
      cancel_at_period_end: false,
    }

    it('does not record the preview', async () => {
      const { service, checkoutAttemptModel } = build({ current })
      ;(service as any).polarApi = {
        subscriptions: { get: jest.fn().mockResolvedValue(polarSubscription) },
      }

      const result: any = await checkout(service, { from: 'app_billing' })
      await flush()

      expect(result.planChange).toBeDefined()
      expect(checkoutAttemptModel.create).not.toHaveBeenCalled()
    })

    it('records a completed plan change', async () => {
      const { service, checkoutAttemptModel } = build({ current })
      ;(service as any).polarApi = {
        subscriptions: {
          get: jest.fn().mockResolvedValue(polarSubscription),
          update: jest.fn().mockResolvedValue({ ...polarSubscription, product_id: 'prod_y' }),
        },
      }
      jest.spyOn(service, 'switchPlan').mockResolvedValue({} as any)

      await service.changePlan({
        user: { _id: userId },
        payload: {
          planName: 'pro',
          billingInterval: 'yearly',
          from: 'app_billing_yearly',
          priorFrom: 'email',
          priorRef: 'yearly_switch',
        },
      })
      await flush()

      expect(checkoutAttemptModel.create).toHaveBeenCalledWith({
        user: userId,
        kind: 'plan_change',
        planName: 'pro',
        billingInterval: 'yearly',
        from: 'app_billing_yearly',
        priorFrom: 'email',
        priorRef: 'yearly_switch',
        completedAt: expect.any(Date),
        discountId: null,
      })
    })

    it('records nothing when the change fails', async () => {
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
      const { service, checkoutAttemptModel } = build({ current })
      ;(service as any).polarApi = {
        subscriptions: {
          get: jest.fn().mockResolvedValue(polarSubscription),
          update: jest.fn().mockRejectedValue(new Error('down')),
        },
      }

      await expect(
        service.changePlan({
          user: { _id: userId },
          payload: { planName: 'pro', billingInterval: 'yearly', from: 'app_billing' },
        }),
      ).rejects.toBeDefined()
      await flush()

      expect(checkoutAttemptModel.create).not.toHaveBeenCalled()
    })
  })
})

describe('BillingService - webhook limit', () => {
  let service: BillingService
  const userId = '507f1f77bcf86cd799439011'

  const mockPlanModel = { findOne: jest.fn() }
  const mockSubscriptionModel = { findOne: jest.fn() }
  const emptyModel = {}

  const subscribed = (subscription: Record<string, unknown> | null) =>
    mockSubscriptionModel.findOne.mockReturnValue({
      populate: jest.fn().mockResolvedValue(subscription),
    })

  const basePlan = { dailyLimit: 50, monthlyLimit: 300, bulkSendLimit: 50 }
  const originalEnv = process.env.MAX_WEBHOOKS_PER_USER

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BillingService,
        { provide: getModelToken(Plan.name), useValue: mockPlanModel },
        {
          provide: getModelToken(Subscription.name),
          useValue: mockSubscriptionModel,
        },
        { provide: getModelToken(User.name), useValue: emptyModel },
        { provide: getModelToken(SMS.name), useValue: emptyModel },
        {
          provide: getModelToken(PolarWebhookPayload.name),
          useValue: emptyModel,
        },
        { provide: getModelToken(CheckoutSession.name), useValue: emptyModel },
        { provide: getModelToken(CheckoutAttempt.name), useValue: emptyModel },
        { provide: BillingNotificationsService, useValue: {} },
        { provide: UsersService, useValue: {} },
        { provide: AnalyticsService, useValue: {} },
        { provide: CheckoutPromotionService, useValue: noPromotion },
      ],
    }).compile()

    service = module.get<BillingService>(BillingService)
    jest.clearAllMocks()
    delete process.env.MAX_WEBHOOKS_PER_USER
  })

  afterAll(() => {
    if (originalEnv === undefined) delete process.env.MAX_WEBHOOKS_PER_USER
    else process.env.MAX_WEBHOOKS_PER_USER = originalEnv
  })

  it('uses the subscription override over the plan value', async () => {
    subscribed({
      customWebhookLimit: 40,
      plan: { ...basePlan, name: 'pro', webhookLimit: 10 },
    })

    const limits = await service.getUserLimits(userId)

    expect(limits.webhookLimit).toBe(40)
  })

  it('uses the plan value when there is no override', async () => {
    subscribed({ plan: { ...basePlan, name: 'pro', webhookLimit: 10 } })

    const limits = await service.getUserLimits(userId)

    expect(limits.webhookLimit).toBe(10)
  })

  it('uses the free plan value when there is no subscription', async () => {
    subscribed(null)
    mockPlanModel.findOne.mockResolvedValue({
      ...basePlan,
      name: 'free',
      webhookLimit: 2,
    })

    const limits = await service.getUserLimits(userId)

    expect(limits.webhookLimit).toBe(2)
  })

  it('falls back to 5 when neither the plan nor the env sets a limit', async () => {
    subscribed({ plan: { ...basePlan, name: 'pro' } })

    const limits = await service.getUserLimits(userId)

    expect(limits.webhookLimit).toBe(5)
  })

  it('falls back to MAX_WEBHOOKS_PER_USER without capping it at 25', async () => {
    process.env.MAX_WEBHOOKS_PER_USER = '100'
    subscribed(null)
    mockPlanModel.findOne.mockResolvedValue({ ...basePlan, name: 'free' })

    const limits = await service.getUserLimits(userId)

    expect(limits.webhookLimit).toBe(100)
  })

  it.each([
    ['an override', { customWebhookLimit: -1, plan: { ...basePlan, webhookLimit: 10 } }],
    ['the plan', { plan: { ...basePlan, webhookLimit: -1 } }],
  ])('keeps -1 from %s as unlimited', async (_source, subscription) => {
    subscribed(subscription)

    const limits = await service.getUserLimits(userId)

    expect(limits.webhookLimit).toBe(-1)
  })

  it('keeps MAX_WEBHOOKS_PER_USER=-1 as unlimited', async () => {
    process.env.MAX_WEBHOOKS_PER_USER = '-1'
    subscribed({ plan: { ...basePlan, name: 'pro' } })

    const limits = await service.getUserLimits(userId)

    expect(limits.webhookLimit).toBe(-1)
  })

  it.each(['abc', '0', '-5'])(
    'uses 5 when MAX_WEBHOOKS_PER_USER is %s',
    async (value) => {
      process.env.MAX_WEBHOOKS_PER_USER = value
      subscribed({ plan: { ...basePlan, name: 'pro' } })

      const limits = await service.getUserLimits(userId)

      expect(limits.webhookLimit).toBe(5)
    },
  )
})

describe('BillingService - checkout promotion', () => {
  const userId = new Types.ObjectId('507f1f77bcf86cd799439011')
  const plan = {
    name: 'pro',
    monthlyPrice: 1000,
    yearlyPrice: 9000,
    polarMonthlyProductId: 'prod_m',
    polarYearlyProductId: 'prod_y',
    isActive: true,
  }
  const discount = {
    id: 'disc_live',
    name: 'Spring offer',
    type: 'percentage',
    basis_points: 2000,
    duration: 'forever',
    starts_at: null,
    ends_at: '2030-03-31T00:00:00Z',
    max_redemptions: null,
    redemptions_count: 0,
    products: [{ id: 'prod_y' }],
  }
  const live = { discount }
  const flush = () => new Promise((resolve) => setImmediate(resolve))

  const build = ({ promotion = live as any, cached = null as any, plans = [plan] as any[] } = {}) => {
    const planModel = {
      findOne: jest.fn().mockResolvedValue(plan),
      find: jest.fn(() => ({ lean: jest.fn().mockResolvedValue(plans) })),
    }
    const checkoutSessionModel = {
      findOne: jest.fn().mockResolvedValue(cached),
      updateOne: jest.fn().mockReturnValue({ catch: jest.fn() }),
    }
    const checkoutAttemptModel = { create: jest.fn().mockResolvedValue({}) }
    const service = new BillingService(
      planModel as any,
      { findOne: jest.fn(() => ({ populate: jest.fn().mockResolvedValue(null) })) } as any,
      {} as any,
      {} as any,
      {} as any,
      checkoutSessionModel as any,
      {} as any,
      {} as any,
      { checkoutStarted: jest.fn() } as any,
      checkoutAttemptModel as any,
      { getLivePromotion: async () => promotion } as any,
    )
    const create = jest.fn().mockResolvedValue({
      id: 'co_new',
      url: 'https://pay.test/co_new',
      expires_at: '2030-03-02T00:00:00Z',
    })
    const getDiscount = jest.fn()
    ;(service as any).polarApi = { checkouts: { create }, discounts: { get: getDiscount } }
    return { service, create, getDiscount, checkoutSessionModel, checkoutAttemptModel }
  }

  const checkout = (service: BillingService, extra: Record<string, unknown> = {}) =>
    service.getCheckoutUrl({
      user: { _id: userId, email: 'a@example.com' },
      payload: { planName: 'pro', billingInterval: 'yearly', ...extra },
      req: { ip: '127.0.0.1', headers: {} },
    })

  afterEach(() => jest.restoreAllMocks())

  describe('getPlans', () => {
    it('adds the promotion to covered plans and null to the rest', async () => {
      const free = { name: 'free', monthlyPrice: 0, yearlyPrice: 0, isActive: true }
      const { service } = build({ plans: [free, plan] })

      const result = await service.getPlans()

      expect(Array.isArray(result)).toBe(true)
      expect(result[0]).toEqual({ ...free, promotion: null })
      expect(result[1]).toEqual({
        ...plan,
        promotion: {
          label: 'Spring offer',
          percentOff: 20,
          endsAt: '2030-03-31T00:00:00.000Z',
          duration: 'forever',
          durationInMonths: null,
          monthlyPrice: null,
          yearlyPrice: 7200,
          newCheckoutsOnly: false,
        },
      })
    })

    it('returns every plan with a null promotion when none is live', async () => {
      const { service } = build({ promotion: null })

      await expect(service.getPlans()).resolves.toEqual([{ ...plan, promotion: null }])
    })
  })

  describe('getCheckoutUrl', () => {
    it('attaches the live discount when it covers the chosen interval', async () => {
      const { service, create, checkoutSessionModel, checkoutAttemptModel } = build()

      await checkout(service)
      await flush()

      expect(create.mock.calls[0][0].discount_id).toBe('disc_live')
      expect(checkoutSessionModel.updateOne.mock.calls[0][1].$set.discountId).toBe('disc_live')
      expect(checkoutAttemptModel.create.mock.calls[0][0].discountId).toBe('disc_live')
    })

    it('attaches nothing when the promotion does not cover the chosen interval', async () => {
      const { service, create, checkoutSessionModel } = build()

      await checkout(service, { billingInterval: 'monthly' })

      expect(create.mock.calls[0][0]).not.toHaveProperty('discount_id')
      expect(checkoutSessionModel.updateOne.mock.calls[0][1].$set.discountId).toBeNull()
    })

    it('attaches nothing when no promotion is live', async () => {
      const { service, create } = build({ promotion: null })

      await checkout(service)

      expect(create.mock.calls[0][0]).not.toHaveProperty('discount_id')
    })

    it('ignores a discount id sent by the client', async () => {
      const { service, create, getDiscount } = build({ promotion: null })

      await checkout(service, { discountId: 'disc_client' })

      expect(create.mock.calls[0][0]).not.toHaveProperty('discount_id')
      expect(getDiscount).not.toHaveBeenCalled()
    })

    it('ignores a client discount id while a promotion is live', async () => {
      const { service, create } = build()

      await checkout(service, { discountId: 'disc_client' })

      expect(create.mock.calls[0][0].discount_id).toBe('disc_live')
    })

    const discountRefused = () =>
      new errors.HTTPValidationError(422, {
        detail: [
          {
            loc: ['body', 'discount_id'],
            msg: 'Discount does not apply',
            type: 'value_error',
            input: { customer_email: 'a@example.com' },
          },
        ],
      } as any)

    it('retries once without the discount when Polar refuses the discount', async () => {
      const { service, create, checkoutSessionModel, checkoutAttemptModel } = build()
      const warn = jest.spyOn(console, 'warn').mockImplementation(() => undefined)
      create.mockRejectedValueOnce(discountRefused())

      await expect(checkout(service)).resolves.toEqual({ redirectUrl: 'https://pay.test/co_new' })
      await flush()

      expect(create).toHaveBeenCalledTimes(2)
      expect(create.mock.calls[0][0].discount_id).toBe('disc_live')
      expect(create.mock.calls[1][0]).not.toHaveProperty('discount_id')
      expect(checkoutSessionModel.updateOne.mock.calls[0][1].$set.discountId).toBeNull()
      expect(checkoutAttemptModel.create.mock.calls[0][0].discountId).toBeNull()
      expect(warn).toHaveBeenCalledWith(
        'checkout with promotion discount disc_live was refused (422) for plan pro (yearly), retrying without it',
      )
      expect(warn.mock.calls[0][0]).not.toContain('a@example.com')
    })

    it.each([
      ['a network error', () => new Error('fetch failed')],
      ['a server error', () => Object.assign(new Error('server error'), { statusCode: 503 })],
      [
        'a validation error on another field',
        () =>
          new errors.HTTPValidationError(422, {
            detail: [
              {
                loc: ['body', 'customer_email'],
                msg: 'Invalid email',
                type: 'value_error',
                input: { discount_id: 'disc_live' },
              },
            ],
          } as any),
      ],
    ])('does not retry at full price after %s', async (_label, make) => {
      const { service, create } = build()
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
      const warn = jest.spyOn(console, 'warn').mockImplementation(() => undefined)
      create.mockRejectedValue(make())

      await expect(checkout(service)).rejects.toThrow('Failed to create checkout')
      expect(create).toHaveBeenCalledTimes(1)
      expect(warn).not.toHaveBeenCalled()
    })

    it('starts the checkout without a discount when the promotion lookup throws', async () => {
      const { service, create } = build()
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
      ;(service as any).checkoutPromotion = {
        getLivePromotion: async () => {
          throw new Error('unexpected')
        },
      }

      await expect(checkout(service)).resolves.toEqual({ redirectUrl: 'https://pay.test/co_new' })
      expect(create.mock.calls[0][0]).not.toHaveProperty('discount_id')
    })

    it('does not retry a failed checkout that had no discount', async () => {
      const { service, create } = build({ promotion: null })
      jest.spyOn(console, 'error').mockImplementation(() => undefined)
      create.mockRejectedValue(new Error('polar down'))

      await expect(checkout(service)).rejects.toThrow('Failed to create checkout')
      expect(create).toHaveBeenCalledTimes(1)
    })

    describe('cached checkout reuse', () => {
      const cached = {
        checkoutSessionId: 'co_cached',
        checkoutUrl: 'https://pay.test/co_cached',
        planName: 'pro',
        billingInterval: 'yearly',
      }

      it('reuses a cached checkout that carries the live discount', async () => {
        const { service, create } = build({ cached: { ...cached, discountId: 'disc_live' } })

        await expect(checkout(service)).resolves.toEqual({ redirectUrl: cached.checkoutUrl })
        expect(create).not.toHaveBeenCalled()
      })

      it('replaces a cached checkout created before the promotion', async () => {
        const { service, create } = build({ cached })

        await expect(checkout(service)).resolves.toEqual({ redirectUrl: 'https://pay.test/co_new' })
        expect(create.mock.calls[0][0].discount_id).toBe('disc_live')
      })

      it('replaces a cached checkout that carries an ended discount', async () => {
        const { service, create } = build({
          promotion: null,
          cached: { ...cached, discountId: 'disc_old' },
        })

        await expect(checkout(service)).resolves.toEqual({ redirectUrl: 'https://pay.test/co_new' })
        expect(create.mock.calls[0][0]).not.toHaveProperty('discount_id')
      })

      it('reuses a cached checkout without a discount when none is live', async () => {
        const { service, create } = build({ promotion: null, cached })

        await expect(checkout(service)).resolves.toEqual({ redirectUrl: cached.checkoutUrl })
        expect(create).not.toHaveBeenCalled()
      })
    })
  })
})
