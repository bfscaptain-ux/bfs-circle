import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
} from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { Model, Types } from 'mongoose'
import { Plan, PlanDocument } from './schemas/plan.schema'
import {
  Subscription,
  SubscriptionDocument,
} from './schemas/subscription.schema'
import {
  createPolar,
  webhooks,
  type models,
  type Polar,
} from '@polar-sh/sdk/2026-10'
import { User, UserDocument } from '../users/schemas/user.schema'
import { UsersService } from '../users/users.service'
import { AnalyticsService } from '../analytics/analytics.service'
import { CheckoutResponseDTO, PlanDTO } from './billing.dto'
import { SMSDocument } from '../gateway/schemas/sms.schema'
import { SMS } from '../gateway/schemas/sms.schema'
import {
  PolarWebhookPayload,
  PolarWebhookPayloadDocument,
} from './schemas/polar-webhook-payload.schema'
import {
  CheckoutSession,
  CheckoutSessionDocument,
} from './schemas/checkout-session.schema'
import {
  CheckoutAttempt,
  CheckoutAttemptDocument,
} from './schemas/checkout-attempt.schema'
import { checkoutSource } from './checkout-source'
import {
  CheckoutPromotionService,
  isDiscountRejection,
  planPromotion,
  promotionCovers,
} from './checkout-promotion.service'
import {
  BillingNotificationsService,
  BillingNotificationType,
} from './billing-notifications.service'
import { resolveClientAddress } from '../common/client-address'
import {
  BillingPeriod,
  billingPeriod,
  dailyWindowStart,
  periodAnchor,
} from '../notifications/rules/usage-window'
import { usageEmailKey } from './usage-emails'
import {
  decideSync,
  ENDED_STATUSES,
  REPLACED_STATUS,
} from './polar-subscription-sync'
import { formatDateTime, pluralize, verifyLink } from '../mail/email-render'
import {
  appPublicUrl,
  billingUrl,
  defaultBillingInterval,
  emailLinkSecret,
} from '../mail/email-links'

// Paid plans are allowed a little past their nominal monthly limit before sends
// are refused. Exported because notification targeting measures usage against
// the same effective allowance, and two copies of this number would drift.
export const PAID_MONTHLY_LIMIT_MULTIPLIER = 1.1

// Webhook limit for plans that do not set webhookLimit. -1 means unlimited.
export function defaultWebhookLimit(): number {
  const raw = parseInt(process.env.MAX_WEBHOOKS_PER_USER ?? '5', 10)
  if (raw === -1) return -1
  if (Number.isNaN(raw) || raw < 1) return 5
  return raw
}

/** One Polar subscription state, as a webhook or an API response carries it. */
export type PolarSubscriptionSync = {
  userId?: string
  newPlanName?: string
  newPlanPolarProductId?: string
  currentPeriodStart?: Date | null
  currentPeriodEnd?: Date | null
  subscriptionStartDate?: Date | null
  status?: string
  amount?: number
  currency?: string
  recurringInterval?: string
  polarSubscriptionId?: string
  polarCustomerId?: string
  cancelAtPeriodEnd?: boolean
  /** When a scheduled cancellation takes effect. */
  endsAt?: Date | null
  endedAt?: Date | null
  modifiedAt?: Date | null
  /** The event was subscription.revoked. */
  revoked?: boolean
  /** Polar discount on the subscription, null when none. */
  discountId?: string | null
}

const PAYMENT_ISSUE_STATUSES = ['past_due', 'incomplete', 'unpaid']

/**
 * How long an unpaid renewal keeps the plan's message limits, from
 * PAYMENT_GRACE_DAYS. Null when unset or invalid: the limits never change.
 */
const paymentGraceMs = (): number | null => {
  const raw = process.env.PAYMENT_GRACE_DAYS?.trim()
  if (!raw) return null
  const days = Number(raw)
  return Number.isFinite(days) && days >= 0 ? days * 24 * 60 * 60 * 1000 : null
}

// Update fields left undefined are not written.
const defined = <T extends Record<string, any>>(fields: T): Partial<T> =>
  Object.fromEntries(
    Object.entries(fields).filter(([, value]) => value !== undefined),
  ) as Partial<T>

// Polar returns timestamps as ISO strings
export const toDate = (value?: string | null): Date | null | undefined =>
  value == null ? (value as null | undefined) : new Date(value)

const LIMIT_HIT_LOG_INTERVAL_MS = 60 * 60 * 1000
const LIMIT_HIT_LOG_MAX_KEYS = 10_000

@Injectable()
export class BillingService {
  private polarApi: Polar
  private limitHitLog = new Map<string, { at: number; suppressed: number }>()

  constructor(
    @InjectModel(Plan.name) private planModel: Model<PlanDocument>,
    @InjectModel(Subscription.name)
    private subscriptionModel: Model<SubscriptionDocument>,
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    @InjectModel(SMS.name) private smsModel: Model<SMSDocument>,
    @InjectModel(PolarWebhookPayload.name)
    private polarWebhookPayloadModel: Model<PolarWebhookPayloadDocument>,
    @InjectModel(CheckoutSession.name)
    private checkoutSessionModel: Model<CheckoutSessionDocument>,
    private readonly billingNotifications: BillingNotificationsService,
    private readonly usersService: UsersService,
    private readonly analyticsService: AnalyticsService,
    @InjectModel(CheckoutAttempt.name)
    private checkoutAttemptModel: Model<CheckoutAttemptDocument>,
    private readonly checkoutPromotion: CheckoutPromotionService,
  ) {
    this.polarApi = createPolar({
      accessToken: process.env.POLAR_ACCESS_TOKEN ?? '',
      environment:
        process.env.POLAR_SERVER === 'production' ? 'production' : 'sandbox',
    })
  }

  async getPlans(): Promise<PlanDTO[]> {
    const [plans, live] = await Promise.all([
      this.planModel.find({ isActive: true }).lean<PlanDTO[]>(),
      this.checkoutPromotion.getLivePromotion(),
    ])
    return plans.map((plan) => ({ ...plan, promotion: planPromotion(plan, live) }))
  }

  /**
   * The discount a plan change to this product gets, or null. A subscription
   * that already has a discount keeps it. Never throws.
   */
  private async planChangeDiscount(
    polarSubscription: models.Subscription,
    productId?: string,
  ): Promise<{ id: string; percentOff: number } | null> {
    if (polarSubscription.discount_id) return null
    try {
      const live = await this.checkoutPromotion.getLivePromotion()
      return live && promotionCovers(live.discount, productId)
        ? { id: live.discount.id, percentOff: live.discount.basis_points / 100 }
        : null
    } catch (error) {
      console.error('failed to resolve the plan change discount', error?.message)
      return null
    }
  }

  /** The discount a new checkout for this product gets, or null. Never throws. */
  private async checkoutDiscountId(productId?: string): Promise<string | null> {
    try {
      const live = await this.checkoutPromotion.getLivePromotion()
      return live && promotionCovers(live.discount, productId) ? live.discount.id : null
    } catch (error) {
      console.error('failed to resolve the checkout discount', error?.message)
      return null
    }
  }

  async getCurrentSubscription(user: any) {
    const subscription = await this.subscriptionModel
      .findOne({
        user: user._id,
        isActive: true,
      })
      .populate('plan')

    if (subscription) {
      return {
        ...subscription.toObject(),
        usage: await this.usageSummary(user, subscription, subscription.plan),
      }
    }

    const plan = await this.planModel.findOne({ name: 'free' })

    return {
      plan,
      isActive: true,
      usage: await this.usageSummary(user, null, plan),
    }
  }

  // The monthly allowance is counted over this period. See usage-window.ts.
  private usagePeriod(
    user: any,
    subscription: any,
    plan: any,
    now: Date,
  ): BillingPeriod {
    const anchor = periodAnchor({
      signupAt:
        user?.createdAt ?? new Types.ObjectId(String(user._id)).getTimestamp(),
      subscription: subscription
        ? {
            planName: plan?.name,
            subscriptionStartDate: subscription.subscriptionStartDate,
            createdAt: subscription.createdAt,
          }
        : null,
    })
    return billingPeriod(anchor ?? now, now)
  }

  private async usageSummary(user: any, subscription: any, plan: any) {
    const now = new Date()
    const period = this.usagePeriod(user, subscription, plan, now)
    const processedSmsToday = await this.smsModel.countDocuments({
      user: user._id,
      createdAt: { $gte: dailyWindowStart(now) },
    })
    const processedSmsLastMonth = await this.smsModel.countDocuments({
      user: user._id,
      createdAt: { $gte: period.start },
    })

    const {
      dailyLimit,
      monthlyLimit,
      bulkSendLimit,
      deviceLimit,
      webhookLimit,
      paymentHold,
    } = await this.messageLimits(subscription, plan, now)
    const remaining = (limit: number, used: number) =>
      limit === -1 ? -1 : limit - used
    const percent = (limit: number, used: number) =>
      limit === -1 ? 0 : Math.round((used / limit) * 100)

    return {
      processedSmsToday,
      processedSmsLastMonth,
      monthlyPeriodStart: period.start,
      monthlyResetAt: period.end,
      dailyLimit,
      monthlyLimit,
      bulkSendLimit,
      deviceLimit,
      webhookLimit,
      paymentHold,
      dailyRemaining: remaining(dailyLimit, processedSmsToday),
      monthlyRemaining: remaining(monthlyLimit, processedSmsLastMonth),
      dailyUsagePercentage: percent(dailyLimit, processedSmsToday),
      monthlyUsagePercentage: percent(monthlyLimit, processedSmsLastMonth),
    }
  }

  async getCheckoutUrl({
    user,
    payload,
    req,
  }: {
    user: any
    payload: any
    req: any
  }): Promise<CheckoutResponseDTO> {
    const billingInterval =
      payload.billingInterval === 'yearly' ? 'yearly' : 'monthly'

    // A user with an active paid Polar subscription must not get a new
    // checkout (it would create a second subscription and double-bill them);
    // their existing Polar subscription gets updated instead, after the
    // frontend shows a confirmation screen
    const planChange = await this.resolvePlanChange({
      user,
      planName: payload.planName,
      billingInterval,
    })

    if (planChange.isPlanChange) {
      const currentPlan = planChange.currentSubscription.plan as Plan
      return {
        planChange: {
          currentPlan: currentPlan.name,
          currentInterval:
            this.normalizeBillingInterval(
              planChange.currentSubscription.recurringInterval,
            ) ?? 'monthly',
          newPlan: planChange.selectedPlan.name,
          newInterval: billingInterval,
          isUpgrade:
            (planChange.selectedPlan.monthlyPrice ?? 0) >
            (currentPlan.monthlyPrice ?? 0),
          cancelAtPeriodEnd: !!planChange.polarSubscription.cancel_at_period_end,
          promotionApplies: !!(await this.planChangeDiscount(
            planChange.polarSubscription,
            planChange.targetProductId,
          )),
        },
      }
    }

    const selectedPlan = planChange.selectedPlan
    const source = checkoutSource(payload)
    // The client's discountId is ignored: only the live promotion applies.
    const discountId = await this.checkoutDiscountId(
      billingInterval === 'yearly'
        ? selectedPlan.polarYearlyProductId
        : selectedPlan.polarMonthlyProductId,
    )

    const existingCheckoutSession = await this.checkoutSessionModel.findOne({
      user: user._id,
      expiresAt: { $gt: new Date() },
      isCompleted: { $ne: true },
      isAbandoned: { $ne: true },
    })

    // Only reuse a cached checkout created for the same plan, billing
    // interval and discount, otherwise Polar would preselect the wrong product
    // or charge a stale price
    if (
      existingCheckoutSession &&
      existingCheckoutSession.planName === payload.planName &&
      existingCheckoutSession.billingInterval === billingInterval &&
      (existingCheckoutSession.discountId ?? null) === discountId
    ) {
      this.recordCheckoutAttempt({
        user: user._id,
        kind: 'checkout',
        planName: payload.planName,
        billingInterval,
        ...source,
        checkoutSessionId: existingCheckoutSession.checkoutSessionId,
        reusedCheckout: true,
        discountId,
      })
      return { redirectUrl: existingCheckoutSession.checkoutUrl }
    }

    try {
      // Polar preselects the first product in the list, so order it by the
      // billing interval the user chose
      const orderedProductIds = (
        billingInterval === 'yearly'
          ? [selectedPlan.polarYearlyProductId, selectedPlan.polarMonthlyProductId]
          : [selectedPlan.polarMonthlyProductId, selectedPlan.polarYearlyProductId]
      ).filter(Boolean)

      // Resolved once so the billing provider and the conversion event agree
      // on who started this checkout.
      const clientAddress = resolveClientAddress(req)

      const checkoutOptions: models.CheckoutCreate = {
        products: orderedProductIds,
        success_url: `${process.env.FRONTEND_URL}/dashboard/account?checkout-success=1&checkout_id={CHECKOUT_ID}`,
        customer_email: user.email,
        customer_name: user.name,
        customer_ip_address: clientAddress.ip,
        metadata: {
          userId: user._id?.toString(),
          ...(user.signupSource && { signupSource: user.signupSource }),
          ...(user.attribution?.first?.campaign && {
            utmCampaign: user.attribution.first.campaign,
          }),
          ...(source.from && { checkoutFrom: source.from }),
          ...(source.ref && { checkoutRef: source.ref }),
        },
        external_customer_id: user._id?.toString(),
      }

      // A discount Polar refuses must never block a checkout: retry once
      // without it. Any other failure takes the normal error path.
      let appliedDiscountId = discountId
      let checkout: models.Checkout
      try {
        checkout = await this.polarApi.checkouts.create(
          discountId ? { ...checkoutOptions, discount_id: discountId } : checkoutOptions,
        )
      } catch (error) {
        if (!discountId || !isDiscountRejection(error)) throw error
        console.warn(
          `checkout with promotion discount ${discountId} was refused (${error?.statusCode}) for plan ${selectedPlan.name} (${billingInterval}), retrying without it`,
        )
        appliedDiscountId = null
        checkout = await this.polarApi.checkouts.create(checkoutOptions)
      }

      this.analyticsService.checkoutStarted(user as any, payload.planName, {
        ...clientAddress,
        userAgent: req.headers?.['user-agent'],
      })

      this.checkoutSessionModel
        .updateOne(
          {
            user: user._id,
          },
          {
            $set: {
              user: user._id,
              checkoutSessionId: checkout.id,
              checkoutUrl: checkout.url,
              planName: payload.planName,
              billingInterval,
              expiresAt: new Date(checkout.expires_at),
              payload: checkout,
              sessionStartedAt: new Date(),
              discountId: appliedDiscountId,
              isCompleted: false,
              isAbandoned: false,
            },
            $unset: { completedAt: 1 },
          },
          { upsert: true },
        )
        .catch((error) => {
          console.error(error)
        })

      this.recordCheckoutAttempt({
        user: user._id,
        kind: 'checkout',
        planName: payload.planName,
        billingInterval,
        ...source,
        checkoutSessionId: checkout.id,
        reusedCheckout: false,
        discountId: appliedDiscountId,
      })

      return { redirectUrl: checkout.url }
    } catch (error) {
      console.error(error)
      throw new Error('Failed to create checkout')
    }
  }

  private recordCheckoutAttempt(attempt: CheckoutAttempt) {
    Promise.resolve()
      .then(() => this.checkoutAttemptModel.create(attempt))
      .catch((error) => {
        console.error('failed to record checkout attempt', error?.message)
      })
  }

  // Polar reports recurringInterval as 'month'/'year', checkout requests use
  // 'monthly'/'yearly'
  private normalizeBillingInterval(
    interval?: string,
  ): 'monthly' | 'yearly' | undefined {
    if (interval === 'month' || interval === 'monthly') return 'monthly'
    if (interval === 'year' || interval === 'yearly') return 'yearly'
    return undefined
  }

  // Decides whether a checkout request is actually a plan change on an
  // existing paid Polar subscription. Throws for requests that are valid in
  // neither path (same plan+interval, custom plans, payment issues).
  private async resolvePlanChange({
    user,
    planName,
    billingInterval,
  }: {
    user: any
    planName: string
    billingInterval: 'monthly' | 'yearly'
  }): Promise<{
    selectedPlan: PlanDocument
    isPlanChange: boolean
    currentSubscription?: SubscriptionDocument
    polarSubscription?: models.Subscription
    targetProductId?: string
  }> {
    // a missing plan name is a client bug, not an unpurchasable plan
    if (!planName || typeof planName !== 'string') {
      console.error(
        `Checkout requested without a plan name (received: ${JSON.stringify(planName)})`,
      )
      throw new BadRequestException({
        message: 'No plan was selected. Please pick a plan and try again.',
        code: 'PLAN_NAME_REQUIRED',
      })
    }

    const selectedPlan = await this.planModel.findOne({ name: planName })

    if (!selectedPlan) {
      console.error(`Checkout requested for unknown plan "${planName}"`)
      throw new BadRequestException({
        message: `Plan "${planName}" was not found.`,
        code: 'PLAN_NOT_FOUND',
      })
    }

    if (
      !selectedPlan.polarMonthlyProductId &&
      !selectedPlan.polarYearlyProductId
    ) {
      console.error(
        `Plan "${planName}" has no Polar product ids and cannot be purchased`,
      )
      throw new BadRequestException('Plan cannot be purchased')
    }

    const currentSubscription = await this.subscriptionModel
      .findOne({ user: user._id, isActive: true })
      .populate('plan')

    const currentPlan = currentSubscription?.plan as Plan | undefined
    const currentInterval = this.normalizeBillingInterval(
      currentSubscription?.recurringInterval,
    )

    if (currentPlan?.name?.startsWith('custom')) {
      throw new BadRequestException({
        message:
          'You are on a custom plan, please contact billing@textbee.dev to change your plan',
        code: 'CONTACT_BILLING',
      })
    }

    // Same plan with a different billing interval is a valid change
    // (e.g. pro monthly -> pro yearly), each interval is a separate product
    const isSamePlan =
      currentPlan?.name === planName &&
      (!currentInterval || currentInterval === billingInterval)
    const alreadyOnPlan = () =>
      new BadRequestException({
        message: `You are already on ${planName} plan, please contact billing@textbee.dev to get a custom plan`,
        code: 'ALREADY_ON_PLAN',
      })

    if (!currentPlan || currentPlan.name === 'free') {
      if (isSamePlan) throw alreadyOnPlan()
      return { selectedPlan, isPlanChange: false, currentSubscription }
    }

    let polarSubscription: models.Subscription | null = null
    if (currentSubscription.polarSubscriptionId) {
      try {
        polarSubscription = await this.polarApi.subscriptions.get(
          currentSubscription.polarSubscriptionId,
        )
      } catch (error) {
        console.error('failed to fetch polar subscription by stored id', error)
      }
    }

    // Older subscriptions predate storing polarSubscriptionId; checkouts have
    // always set externalCustomerId to the user id, so recover it from there
    if (!polarSubscription || polarSubscription.status === 'canceled') {
      try {
        const page = await this.polarApi.subscriptions.list({
          external_customer_id: user._id.toString(),
          active: true,
          limit: 1,
        })
        polarSubscription = page?.items?.[0] ?? null

        if (polarSubscription) {
          this.subscriptionModel
            .updateOne(
              { _id: currentSubscription._id },
              {
                polarSubscriptionId: polarSubscription.id,
                polarCustomerId: polarSubscription.customer_id,
              },
            )
            .catch((error) => {
              console.error(error)
            })
        }
      } catch (error) {
        console.error('failed to list polar subscriptions', error)
      }
    }

    // A payment problem is the real blocker, so it is reported before "already on plan".
    const hasPaymentIssue = polarSubscription
      ? PAYMENT_ISSUE_STATUSES.includes(polarSubscription.status)
      : PAYMENT_ISSUE_STATUSES.includes(currentSubscription.status)
    if (hasPaymentIssue) {
      throw new BadRequestException({
        message:
          'Your subscription has a payment issue. Please update your payment method in the customer portal before changing plans.',
        code: 'PAYMENT_ISSUE',
      })
    }

    if (isSamePlan) throw alreadyOnPlan()

    if (!polarSubscription) {
      // Paid subscription with no Polar record (e.g. manually granted):
      // a regular checkout is the correct path for these users
      console.warn(
        `No active polar subscription found for user ${user._id} on paid plan ${currentPlan.name}, falling back to checkout`,
      )
      return { selectedPlan, isPlanChange: false, currentSubscription }
    }

    const targetProductId =
      billingInterval === 'yearly'
        ? selectedPlan.polarYearlyProductId
        : selectedPlan.polarMonthlyProductId

    if (!targetProductId) {
      throw new BadRequestException(
        `Plan ${planName} cannot be purchased with ${billingInterval} billing`,
      )
    }

    // Catches drift between our DB and Polar
    if (polarSubscription.product_id === targetProductId) {
      throw alreadyOnPlan()
    }

    return {
      selectedPlan,
      isPlanChange: true,
      currentSubscription,
      polarSubscription,
      targetProductId,
    }
  }

  async changePlan({ user, payload }: { user: any; payload: any }) {
    const billingInterval =
      payload.billingInterval === 'yearly' ? 'yearly' : 'monthly'

    const { isPlanChange, selectedPlan, polarSubscription, targetProductId } =
      await this.resolvePlanChange({
        user,
        planName: payload.planName,
        billingInterval,
      })

    if (!isPlanChange) {
      throw new BadRequestException({
        message:
          'No active paid subscription found to change, please use the checkout instead',
        code: 'NO_ACTIVE_SUBSCRIPTION',
      })
    }

    const discount = await this.planChangeDiscount(
      polarSubscription,
      targetProductId,
    )
    const discountId = discount?.id ?? null
    // The client confirmed a sale price, so never charge more without asking
    const promotionShown = payload.promotionShown === true
    const promotionUnavailable = () =>
      new BadRequestException({
        message:
          'The sale price is no longer available for this change. Refresh the page to see the current price.',
        code: 'PROMOTION_UNAVAILABLE',
      })
    // A present but malformed promotion field never reads as absent
    const shownPercentOff = payload.promotionPercentOff
    const hasShownPercent =
      shownPercentOff !== undefined && shownPercentOff !== null
    if (
      (payload.promotionShown !== undefined &&
        typeof payload.promotionShown !== 'boolean') ||
      (promotionShown &&
        (!discount ||
          (hasShownPercent && shownPercentOff !== discount.percentOff)))
    ) {
      throw promotionUnavailable()
    }

    let cancellationLifted = false
    try {
      // A product update on a subscription scheduled for cancellation is
      // rejected by Polar; changing plans clearly signals intent to stay
      if (polarSubscription.cancel_at_period_end) {
        await this.polarApi.subscriptions.update(polarSubscription.id, {
          cancel_at_period_end: false,
        })
        cancellationLifted = true
      }

      // prorationBehavior omitted on purpose: use the Polar org default.
      // A discount Polar refuses retries once without it, unless the client
      // confirmed the sale price.
      let appliedDiscountId = discountId
      let updated: models.Subscription
      try {
        updated = await this.polarApi.subscriptions.update(
          polarSubscription.id,
          discountId
            ? { product_id: targetProductId, discount_id: discountId }
            : { product_id: targetProductId },
        )
      } catch (error) {
        if (!discountId || !isDiscountRejection(error)) throw error
        if (promotionShown) {
          if (cancellationLifted) {
            await this.polarApi.subscriptions
              .update(polarSubscription.id, { cancel_at_period_end: true })
              .catch((restoreError) => {
                console.error(
                  `failed to restore the scheduled cancellation on ${polarSubscription.id}`,
                  restoreError?.message,
                )
              })
          }
          throw promotionUnavailable()
        }
        console.warn(
          `plan change with promotion discount ${discountId} was refused (${error?.statusCode}) for plan ${selectedPlan.name} (${billingInterval}), retrying without it`,
        )
        appliedDiscountId = null
        updated = await this.polarApi.subscriptions.update(
          polarSubscription.id,
          { product_id: targetProductId },
        )
      }

      if (promotionShown && updated.discount_id !== discountId) {
        console.error(
          `plan change on ${polarSubscription.id} went through without the confirmed promotion discount ${discountId}`,
        )
      }

      // Update local state right away so the dashboard reflects the change;
      // the subscription.updated webhook that follows is an idempotent no-op
      await this.switchPlan({
        userId: user._id.toString(),
        newPlanPolarProductId: updated.product_id ?? targetProductId,
        currentPeriodStart: toDate(updated.current_period_start),
        currentPeriodEnd: toDate(updated.current_period_end),
        subscriptionStartDate: toDate(updated.started_at ?? updated.created_at),
        endsAt: toDate(updated.ends_at),
        endedAt: toDate(updated.ended_at),
        modifiedAt: toDate(updated.modified_at),
        status: updated.status,
        amount: updated.amount,
        currency: updated.currency,
        recurringInterval: updated.recurring_interval,
        polarSubscriptionId: updated.id,
        polarCustomerId: updated.customer_id,
        cancelAtPeriodEnd: updated.cancel_at_period_end,
        discountId: updated.discount_id,
      })

      // An open cached checkout for the old plan must not be reusable anymore
      this.checkoutSessionModel
        .updateOne(
          { user: user._id, isCompleted: { $ne: true } },
          { isAbandoned: true },
        )
        .catch((error) => {
          console.error(error)
        })

      this.recordCheckoutAttempt({
        user: user._id,
        kind: 'plan_change',
        planName: selectedPlan.name,
        billingInterval,
        ...checkoutSource(payload),
        completedAt: new Date(),
        discountId:
          appliedDiscountId && updated.discount_id === appliedDiscountId
            ? appliedDiscountId
            : null,
      })

      return { success: true, plan: selectedPlan.name }
    } catch (error) {
      if (error instanceof HttpException) {
        throw error
      }
      console.error('failed to change plan', error)

      // The SDK raises SubscriptionsUpdate402Error when the charge is declined
      const statusCode = error?.statusCode
      if (statusCode === 402) {
        throw new BadRequestException({
          message:
            'Your card was declined. Update your payment method, then try again.',
          code: 'PAYMENT_FAILED',
        })
      }
      if (statusCode === 403) {
        throw new BadRequestException({
          message:
            'Your subscription is canceled or ending and cannot be changed. Please resume it in the customer portal or contact billing@textbee.dev.',
          code: 'SUBSCRIPTION_ENDING',
        })
      }
      if (statusCode === 409) {
        throw new BadRequestException({
          message:
            'A plan change is already in progress for your subscription. Please try again later or contact billing@textbee.dev.',
          code: 'PENDING_UPDATE',
        })
      }
      throw new BadRequestException({
        message:
          'Failed to change plan, please try again or contact billing@textbee.dev',
        code: 'PLAN_CHANGE_FAILED',
      })
    }
  }

  async getActiveSubscription(userId: string) {
    const user = await this.userModel.findById(new Types.ObjectId(userId))
    const plans = await this.planModel.find()

    const customPlans = plans.filter((plan) => plan.name?.startsWith('custom'))
    const scalePlan = plans.find((plan) => plan.name === 'scale')
    const proPlan = plans.find((plan) => plan.name === 'pro')
    const freePlan = plans.find((plan) => plan.name === 'free')

    const customPlanSubscription = await this.subscriptionModel.findOne({
      user: user._id,
      plan: { $in: customPlans.map((plan) => plan._id) },
      isActive: true,
    })

    if (customPlanSubscription) {
      return customPlanSubscription.populate('plan')
    }

    if (scalePlan) {
      const scalePlanSubscription = await this.subscriptionModel.findOne({
        user: user._id,
        plan: scalePlan._id,
        isActive: true,
      })

      if (scalePlanSubscription) {
        return scalePlanSubscription.populate('plan')
      }
    }

    const proPlanSubscription = await this.subscriptionModel.findOne({
      user: user._id,
      plan: proPlan._id,
      isActive: true,
    })

    if (proPlanSubscription) {
      return proPlanSubscription.populate('plan')
    }

    const freePlanSubscription = await this.subscriptionModel.findOne({
      user: user._id,
      plan: freePlan._id,
      isActive: true,
    })

    if (freePlanSubscription) {
      return freePlanSubscription.populate('plan')
    }

    // create a new free plan subscription
    // const newFreePlanSubscription = await this.subscriptionModel.create({
    //   user: user._id,
    //   plan: freePlan._id,
    //   isActive: true,
    //   startDate: new Date(),
    // })

    // return newFreePlanSubscription.populate('plan')
    return {
      user,
      plan: freePlan,
      isActive: true,
      status: 'active',
      amount: 0,
    }
  }

  private getEffectiveLimits(subscription: any, plan: any) {
    if (!subscription) {
      return {
        dailyLimit: plan?.dailyLimit ?? 1000,
        monthlyLimit: plan?.monthlyLimit ?? 30000,
        bulkSendLimit: plan?.bulkSendLimit ?? 500,
        deviceLimit: plan?.deviceLimit ?? -1,
        webhookLimit: plan?.webhookLimit ?? defaultWebhookLimit(),
      }
    }

    return {
      dailyLimit: subscription.customDailyLimit ?? plan?.dailyLimit ?? 1000,
      monthlyLimit: subscription.customMonthlyLimit ?? plan?.monthlyLimit ?? 30000,
      bulkSendLimit: subscription.customBulkSendLimit ?? plan?.bulkSendLimit ?? 500,
      deviceLimit:
        subscription.customDeviceLimit ?? plan?.deviceLimit ?? -1,
      webhookLimit:
        subscription.customWebhookLimit ??
        plan?.webhookLimit ??
        defaultWebhookLimit(),
    }
  }

  /**
   * True once a renewal has stayed unpaid past the grace period. The
   * subscription keeps its plan; only the message limits change. Needs both
   * the status and the date, so one stale field cannot limit a paid account.
   */
  private isOnPaymentHold(subscription: any, plan: any, now: Date) {
    const graceMs = paymentGraceMs()
    if (graceMs === null || !subscription?.pastDueAt) return false
    if (subscription.status !== 'past_due') return false
    if (!plan?.name || plan.name === 'free' || plan.name.startsWith('custom')) {
      return false
    }
    const since = new Date(subscription.pastDueAt).getTime()
    return Number.isFinite(since) && now.getTime() - since >= graceMs
  }

  /** Effective limits, with the free plan's message limits while on payment hold. */
  private async messageLimits(subscription: any, plan: any, now: Date) {
    const limits = this.getEffectiveLimits(subscription, plan)
    if (!this.isOnPaymentHold(subscription, plan, now)) {
      return { ...limits, paymentHold: false }
    }
    const freePlan = await this.planModel.findOne({ name: 'free' })
    if (!freePlan) return { ...limits, paymentHold: false }
    // Never looser than a limit already set on the account. -1 is unlimited.
    const tighter = (own: number, free: number) => {
      if (typeof free !== 'number') return own
      if (typeof own !== 'number' || own === -1) return free
      return free === -1 ? own : Math.min(own, free)
    }
    return {
      ...limits,
      dailyLimit: tighter(limits.dailyLimit, freePlan.dailyLimit),
      monthlyLimit: tighter(limits.monthlyLimit, freePlan.monthlyLimit),
      bulkSendLimit: tighter(limits.bulkSendLimit, freePlan.bulkSendLimit),
      paymentHold: true,
    }
  }

  private notifyApproachingLimits(
    userId: Types.ObjectId,
    planName: string,
    used: { today: number; thisPeriod: number },
    limits: { dailyLimit: number; monthlyLimit: number },
    period: BillingPeriod,
  ) {
    const notify = (
      type: BillingNotificationType,
      title: string,
      message: string,
      meta: Record<string, any>,
    ) =>
      this.billingNotifications
        .notifyOnce({
          userId,
          type,
          title,
          message,
          meta: { ...meta, planName },
          emailKey: usageEmailKey(type, planName),
        })
        .catch(() => {})

    const { dailyLimit, monthlyLimit } = limits
    if (dailyLimit > 0 && used.today >= dailyLimit * 0.8 && used.today < dailyLimit) {
      notify(
        BillingNotificationType.DAILY_LIMIT_APPROACHING,
        "You're close to today's message limit",
        `Your account has used ${used.today} of its ${dailyLimit} messages for today, counting sent and received. ${dailyLimit - used.today} are left.`,
        { processedSmsToday: used.today, dailyLimit },
      )
    }
    if (
      monthlyLimit > 0 &&
      used.thisPeriod >= monthlyLimit * 0.8 &&
      used.thisPeriod < monthlyLimit
    ) {
      notify(
        BillingNotificationType.MONTHLY_LIMIT_APPROACHING,
        "You're close to your monthly message limit",
        `Your account has used ${used.thisPeriod} of its ${monthlyLimit} messages for this billing period, counting sent and received. ${monthlyLimit - used.thisPeriod} are left. The allowance resets on ${formatDateTime(period.end, new Date())}.`,
        {
          processedSmsLastMonth: used.thisPeriod,
          monthlyLimit,
          monthlyPeriodStart: period.start,
          monthlyResetAt: period.end,
        },
      )
    }
  }

  private isLimitExempt(userId: string) {
    return (process.env.LIMIT_EXEMPT_USER_IDS ?? '')
      .split(',')
      .map((id) => id.trim())
      .includes(String(userId))
  }

  private receivesOverLimitAllowed() {
    return process.env.RECEIVE_SMS_OVER_LIMIT !== 'reject'
  }

  async getUserLimits(userId: string) {
    const subscription = await this.subscriptionModel
      .findOne({ user: new Types.ObjectId(userId), isActive: true })
      .populate('plan')

    if (!subscription) {
      // Default to free plan limits
      const freePlan = await this.planModel.findOne({ name: 'free' })
      return this.getEffectiveLimits(null, freePlan)
    }

    // Use custom limits if set, otherwise fall back to plan limits
    return this.getEffectiveLimits(subscription, subscription.plan)
  }

  async notifyDeviceLimitReached(
    userId: Types.ObjectId | string,
    deviceLimit: number,
    activeDeviceCount: number,
  ) {
    const subscription = await this.subscriptionModel
      .findOne({ user: new Types.ObjectId(String(userId)), isActive: true })
      .populate('plan')
    const planName = (subscription?.plan as Plan | undefined)?.name ?? 'free'
    await this.billingNotifications.notifyOnce({
      userId,
      type: BillingNotificationType.DEVICE_LIMIT_REACHED,
      title: 'Active device limit reached',
      message: `Your plan allows up to ${deviceLimit} active device(s) and you have ${activeDeviceCount}. Disable or delete another device, or upgrade your plan to connect more devices.`,
      meta: {
        deviceLimit,
        activeDeviceCount,
        planName,
      },
      emailKey: usageEmailKey(
        BillingNotificationType.DEVICE_LIMIT_REACHED,
        planName,
      ),
    })
  }

  /**
   * Applies one Polar subscription state to the local rows. Rows are keyed by
   * the Polar subscription id and plan: a plan change keeps the old plan's row
   * as history, and a new purchase gets a row of its own. Which events apply,
   * and when a plan set by hand survives, is decided in
   * polar-subscription-sync.ts.
   */
  async switchPlan(input: PolarSubscriptionSync) {
    const { polarSubscriptionId } = input
    const now = new Date()
    const rows = polarSubscriptionId
      ? await this.subscriptionModel.find({ polarSubscriptionId })
      : []
    const userId = input.userId || (rows[0] ? String(rows[0].user) : undefined)
    if (!userId || !Types.ObjectId.isValid(userId)) {
      throw new Error(`No user for Polar subscription ${polarSubscriptionId}`)
    }
    const user = new Types.ObjectId(userId)
    const plan = await this.planFor(input.newPlanPolarProductId, input.newPlanName)

    const decision = decideSync({
      snapshot: {
        productId: input.newPlanPolarProductId,
        status: input.status,
        modifiedAt: input.modifiedAt,
        endedAt: input.endedAt,
        revoked: input.revoked,
      },
      rows,
      now,
    })

    if (decision.action === 'ignore') {
      console.log(
        `Ignored a ${decision.reason} event for Polar subscription ${polarSubscriptionId}`,
      )
      return { success: true, plan: plan?.name, ignored: decision.reason }
    }

    if (decision.action === 'end') {
      await this.endPolarSubscription({
        user,
        plan,
        input,
        hasRows: rows.length > 0,
        endedAt: decision.endedAt,
      })
      console.log(`Ended Polar subscription ${polarSubscriptionId} for user ${userId}`)
      return { success: true, plan: plan?.name }
    }

    if (!plan) {
      throw new Error('Plan not found')
    }
    const planId = decision.keepPlan ?? plan._id

    // Two live Polar subscriptions on one account: the newest started one wins,
    // so renewals of the older one cannot flip the plan back and forth.
    const rivals = polarSubscriptionId
      ? await this.subscriptionModel.find({
          user,
          isActive: true,
          polarSubscriptionId: { $nin: [null, polarSubscriptionId] },
          polarEndedAt: null,
        })
      : []
    const started = input.subscriptionStartDate?.getTime() ?? 0
    const outranked = rivals.some(
      (row: any) =>
        !ENDED_STATUSES.has(row.status) &&
        (row.subscriptionStartDate?.getTime?.() ?? 0) > started,
    )
    if (outranked) {
      console.warn(
        `User ${userId} has more than one live Polar subscription; ${polarSubscriptionId} is not the newest`,
      )
    }

    // A running subscription has no end cause.
    const running = input.status === 'active' && !input.cancelAtPeriodEnd
    const update = {
      $set: defined({
        user,
        plan: planId,
        isActive: !outranked,
        currentPeriodStart: input.currentPeriodStart,
        currentPeriodEnd: input.currentPeriodEnd,
        subscriptionStartDate: input.subscriptionStartDate,
        subscriptionEndDate: input.cancelAtPeriodEnd
          ? (input.endsAt ?? input.currentPeriodEnd ?? null)
          : null,
        status: input.status,
        amount: input.amount,
        currency: input.currency,
        recurringInterval: input.recurringInterval,
        polarSubscriptionId,
        polarCustomerId: input.polarCustomerId,
        cancelAtPeriodEnd: input.cancelAtPeriodEnd,
        polarProductId: input.newPlanPolarProductId,
        discountId: input.discountId,
      }),
      // Only moves forward, so a late write can never lower it.
      ...(input.modifiedAt && { $max: { polarEventAt: input.modifiedAt } }),
      ...(running && { $unset: { churnCause: 1 } }),
    }
    // The decision above read the rows earlier; a webhook handled at the same
    // time may have ended or advanced the row since. The filter repeats both
    // checks, so such a write finds no row, collides on the unique index, and
    // is dropped.
    const key = polarSubscriptionId
      ? {
          polarSubscriptionId,
          plan: planId,
          polarEndedAt: null,
          ...(input.modifiedAt
            ? {
                $or: [
                  { polarEventAt: null },
                  { polarEventAt: { $lte: input.modifiedAt } },
                ],
              }
            : { polarEventAt: null }),
        }
      : { user, plan: planId }
    const current = await this.upsertSubscription(key, update)
    if (!current) {
      console.log(
        `Dropped a concurrent event for Polar subscription ${polarSubscriptionId}`,
      )
      return { success: true, plan: plan.name, ignored: 'stale' as const }
    }

    // A revoke handled at the same time can end another plan's row of this
    // subscription while this one was written; the end wins.
    const linked = polarSubscriptionId
      ? await this.subscriptionModel.find({ polarSubscriptionId })
      : []
    const ended = linked.find((row: any) => row.polarEndedAt)
    if (ended) {
      await this.endPolarSubscription({
        user,
        plan,
        input,
        hasRows: true,
        endedAt: ended.polarEndedAt,
      })
      return { success: true, plan: plan.name, ignored: 'ended' as const }
    }

    // A plan change of this subscription handled at the same time with a
    // newer event wins; this row becomes its history.
    const eventAt = (row: any) => row?.polarEventAt?.getTime?.() ?? -Infinity
    const newer = linked.some(
      (row: any) =>
        String(row._id) !== String(current._id) &&
        eventAt(row) > eventAt(current),
    )
    const replace = {
      $set: { isActive: false, status: REPLACED_STATUS, subscriptionEndDate: now },
      $unset: { churnCause: 1 },
    }
    if (newer) {
      // Only while the row still holds this event; a newer one may own it now.
      await this.subscriptionModel.updateMany(
        {
          _id: current._id,
          user,
          polarEndedAt: null,
          polarEventAt: current.polarEventAt ?? null,
        },
        replace,
      )
      return { success: true, plan: plan.name, ignored: 'stale' as const }
    }
    let deactivated = 0
    if (polarSubscriptionId) {
      // The other plan rows of this subscription, never one a newer event wrote.
      const history = {
        polarSubscriptionId,
        user,
        _id: { $ne: current._id },
        polarEndedAt: null,
        ...(current.polarEventAt && {
          $or: [
            { polarEventAt: null },
            { polarEventAt: { $lte: current.polarEventAt } },
          ],
        }),
      }
      const replaced = await this.subscriptionModel.updateMany(
        { ...history, isActive: true },
        replace,
      )
      // Rows another subscription turned off earlier keep their end date.
      await this.subscriptionModel.updateMany(
        {
          ...history,
          isActive: false,
          status: { $nin: [REPLACED_STATUS, ...ENDED_STATUSES] },
        },
        { $set: { status: REPLACED_STATUS }, $unset: { churnCause: 1 } },
      )
      deactivated += replaced?.modifiedCount ?? 0
    }

    if (!outranked) {
      // Rows of this subscription were handled above, by event time.
      const others = {
        user,
        isActive: true,
        _id: { $ne: current._id },
        ...(polarSubscriptionId && {
          polarSubscriptionId: { $ne: polarSubscriptionId },
        }),
      }
      // Rows without a Polar id are replaced. Another Polar subscription keeps
      // its status: Polar still bills it.
      const replaced = await this.subscriptionModel.updateMany(
        { ...others, polarSubscriptionId: null },
        replace,
      )
      const result = await this.subscriptionModel.updateMany(others, {
        $set: { isActive: false, subscriptionEndDate: now },
      })
      deactivated += (replaced?.modifiedCount ?? 0) + (result?.modifiedCount ?? 0)
    }
    console.log(`Deactivated subscriptions: ${deactivated}`)

    // Two plan events of this subscription can still pass the checks above at
    // the same time; the newest event keeps the row.
    if (polarSubscriptionId) {
      const live = await this.subscriptionModel.find({
        polarSubscriptionId,
        user,
        isActive: true,
      })
      if (live.length > 1) {
        // Rows without an event time rank last; a tie goes to this event's row.
        const rank = (row: any) => row?.polarEventAt?.getTime?.() ?? 0
        const mine = (row: any) => Number(String(row._id) === String(current._id))
        const [, ...stale] = [...live].sort(
          (a: any, b: any) => rank(b) - rank(a) || mine(b) - mine(a),
        )
        await this.subscriptionModel.updateMany(
          { _id: { $in: stale.map((row: any) => row._id) } },
          replace,
        )
      }
    }

    await this.reportFirstPayment({
      userId,
      plan: plan.name,
      status: input.status,
      amount: input.amount,
      currency: input.currency,
      polarSubscriptionId,
    })

    return { success: true, plan: plan.name }
  }

  private async planFor(polarProductId?: string, planName?: string) {
    if (polarProductId) {
      return this.planModel.findOne({
        $or: [
          { polarMonthlyProductId: polarProductId },
          { polarYearlyProductId: polarProductId },
        ],
      })
    }
    if (planName) return this.planModel.findOne({ name: planName })
    return null
  }

  // Concurrent webhooks race the upsert; the unique index turns the loser into an update.
  private async upsertSubscription(key: Record<string, any>, update: any) {
    try {
      return await this.subscriptionModel.findOneAndUpdate(key, update, {
        upsert: true,
        returnDocument: 'after',
      })
    } catch (error) {
      const raced =
        error?.code === 11000 &&
        error?.keyPattern?.polarSubscriptionId !== undefined
      if (!raced) throw error
      return this.subscriptionModel.findOneAndUpdate(key, update, { returnDocument: 'after' })
    }
  }

  /** Ends every row of a Polar subscription. Ending is final; see decideSync. */
  private async endPolarSubscription({
    user,
    plan,
    input,
    hasRows,
    endedAt,
  }: {
    user: Types.ObjectId
    plan: PlanDocument | null
    input: PolarSubscriptionSync
    hasRows: boolean
    endedAt: Date
  }) {
    const { polarSubscriptionId } = input
    const status =
      input.status && ENDED_STATUSES.has(input.status) ? input.status : 'canceled'
    endedAt = new Date(endedAt)

    if (polarSubscriptionId && hasRows) {
      await this.subscriptionModel.updateMany(
        { polarSubscriptionId, isActive: true },
        { $set: { isActive: false, status, subscriptionEndDate: endedAt } },
      )
      await this.subscriptionModel.updateMany(
        { polarSubscriptionId, polarEndedAt: null },
        { $set: { polarEndedAt: endedAt } },
      )
      await this.restoreLiveSubscription(user)
      return
    }

    if (!plan) {
      console.error(
        `Polar subscription ${polarSubscriptionId} ended on an unknown product ${input.newPlanPolarProductId}`,
      )
      return
    }

    // No row carries this id: a row from before ids were stored, or the end
    // arrived before the start. Either way the end is recorded, so a late
    // start event finds it and cannot revive the subscription.
    const fields = defined({
      polarSubscriptionId,
      polarCustomerId: input.polarCustomerId,
      polarProductId: input.newPlanPolarProductId,
      isActive: false,
      status,
      subscriptionStartDate: input.subscriptionStartDate,
      subscriptionEndDate: endedAt,
      polarEndedAt: endedAt,
      currentPeriodStart: input.currentPeriodStart,
      currentPeriodEnd: input.currentPeriodEnd,
      amount: input.amount,
      currency: input.currency,
      recurringInterval: input.recurringInterval,
      cancelAtPeriodEnd: input.cancelAtPeriodEnd,
    })
    // Only a row that started with this subscription is taken for it, so the
    // end of an unrelated old purchase cannot end a live row.
    const started = input.subscriptionStartDate?.getTime()
    const legacy = (
      await this.subscriptionModel.find({
        user,
        plan: plan._id,
        isActive: true,
        polarSubscriptionId: null,
        assignedBy: null,
      })
    ).find(
      (row: any) =>
        started !== undefined &&
        Math.abs((row.subscriptionStartDate?.getTime?.() ?? NaN) - started) <=
          2 * 60 * 1000,
    )
    if (legacy) {
      await this.subscriptionModel.updateMany({ _id: legacy._id }, { $set: fields })
      return
    }
    if (!polarSubscriptionId) return
    await this.upsertSubscription(
      { polarSubscriptionId, plan: plan._id },
      { $set: { user, plan: plan._id, ...fields } },
    )
  }

  /**
   * Reports a sale to the ad platforms the first time an account actually pays.
   * The milestone write is the only gate, which makes renewals, upgrades and
   * re-subscribes idempotent: whichever webhook arrives first wins, and every
   * later one is a no-op.
   *
   * subscription.created can arrive before payment succeeds, so a status that
   * is not active is ignored rather than reported as revenue.
   */
  private async reportFirstPayment({
    userId,
    plan,
    status,
    amount,
    currency,
    polarSubscriptionId,
  }: {
    userId: string
    plan?: string
    status?: string
    amount?: number
    currency?: string
    polarSubscriptionId?: string
  }) {
    if (status !== 'active') return
    if (typeof amount !== 'number' || amount <= 0) return

    try {
      const isFirstPayment = await this.usersService.markMilestone(
        userId,
        'firstPaidAt',
      )
      if (!isFirstPayment) return

      // Loaded only now, and only once per account, because the conversion
      // event needs the email to hash for matching.
      const user = await this.userModel.findById(userId)
      if (!user) return

      this.analyticsService.purchase(user as any, {
        amount,
        currency,
        plan,
        subscriptionId: polarSubscriptionId,
      })
    } catch (error) {
      console.error('Failed to report first payment', error)
    }
  }

  /** Stores when the current payment retry period started, and clears it once paid. */
  async syncPastDue({
    polarSubscriptionId,
    status,
    pastDueAt,
    eventAt,
  }: {
    polarSubscriptionId?: string
    status?: string
    pastDueAt?: Date | string
    eventAt: Date
  }) {
    if (!polarSubscriptionId) return
    if (status !== 'past_due' && status !== 'active') return
    // Events can arrive out of order; only a newer status change is applied.
    const newer = {
      polarSubscriptionId,
      $or: [{ statusEventAt: null }, { statusEventAt: { $lt: eventAt } }],
    }
    if (status === 'active') {
      await this.subscriptionModel.updateMany(newer, {
        $set: { statusEventAt: eventAt },
        $unset: { pastDueAt: 1 },
      })
      return
    }
    if (pastDueAt) {
      await this.subscriptionModel.updateMany(
        { ...newer, isActive: true },
        { $set: { pastDueAt: new Date(pastDueAt), statusEventAt: eventAt } },
      )
      return
    }
    // Keeps the first start of the retry period.
    await this.subscriptionModel.updateMany(
      { ...newer, isActive: true, pastDueAt: null },
      { $set: { pastDueAt: eventAt, statusEventAt: eventAt } },
    )
    await this.subscriptionModel.updateMany(
      { ...newer, isActive: true },
      { $set: { statusEventAt: eventAt } },
    )
  }

  /** payment_failed when the provider ended the plan right after a failed renewal. */
  async churnCause({
    polarSubscriptionId,
    status,
    cancelAtPeriodEnd,
    endsAt,
    eventAt,
  }: {
    polarSubscriptionId?: string
    status?: string
    cancelAtPeriodEnd?: boolean
    endsAt?: Date | string | null
    eventAt: Date
  }): Promise<'customer' | 'payment_failed'> {
    const ends = endsAt ? new Date(endsAt).getTime() : NaN
    const endsNow =
      status === 'canceled' &&
      cancelAtPeriodEnd === false &&
      Math.abs(ends - eventAt.getTime()) <= 3 * 60 * 60 * 1000
    if (!endsNow || !polarSubscriptionId) return 'customer'

    const pastDue = await this.subscriptionModel.exists({
      polarSubscriptionId,
      pastDueAt: { $ne: null },
    })
    if (pastDue) return 'payment_failed'

    const recentPastDue = await this.polarWebhookPayloadModel.exists({
      'payload.data.id': polarSubscriptionId,
      'payload.data.status': 'past_due',
      createdAt: { $gte: new Date(eventAt.getTime() - 35 * 24 * 60 * 60 * 1000) },
    })
    return recentPastDue ? 'payment_failed' : 'customer'
  }

  /**
   * Records why a Polar subscription is ending, on its current row only. Rows
   * a plan change left behind keep no cause, so the ended-plan emails that
   * read it go out once.
   */
  async recordChurnCause({
    polarSubscriptionId,
    churnCause,
  }: {
    polarSubscriptionId?: string
    churnCause?: 'customer' | 'payment_failed'
  }) {
    if (!polarSubscriptionId || !churnCause) return
    const rows = await this.subscriptionModel.find({ polarSubscriptionId })
    const current = rows.filter(
      (row: any) =>
        row.isActive ||
        (row.polarEndedAt &&
          row.subscriptionEndDate?.getTime?.() === row.polarEndedAt.getTime()),
    )
    if (!current.length) return
    await this.subscriptionModel.updateMany(
      { _id: { $in: current.map((row: any) => row._id) } },
      { $set: { churnCause } },
    )
  }

  /**
   * When an account's active row ended while another Polar subscription it
   * pays for is still live, that one takes over at once rather than at its
   * next renewal.
   */
  private async restoreLiveSubscription(user: Types.ObjectId) {
    const active = await this.subscriptionModel.find({ user, isActive: true })
    if (active.length) return
    const live = (
      await this.subscriptionModel.find({
        user,
        isActive: false,
        polarEndedAt: null,
        polarSubscriptionId: { $nin: [null] },
      })
      // Only rows this sync wrote, which carry their product; older history
      // rows may hold plans set by hand long ago.
    ).filter(
      (row: any) =>
        row.polarProductId &&
        !ENDED_STATUSES.has(row.status) &&
        row.status !== REPLACED_STATUS,
    )
    if (!live.length) return
    const at = (value: any) => value?.getTime?.() ?? 0
    // The newest started subscription, and its newest row (the current plan).
    live.sort(
      (a: any, b: any) =>
        at(b.subscriptionStartDate) - at(a.subscriptionStartDate) ||
        at(b.polarEventAt) - at(a.polarEventAt) ||
        at(b.updatedAt) - at(a.updatedAt),
    )
    await this.subscriptionModel.updateMany(
      { _id: live[0]._id },
      { $set: { isActive: true, subscriptionEndDate: null } },
    )
  }

  // Clients that keep calling past a limit would otherwise flood the error log.
  private logLimitHit(key: string, details: Record<string, unknown>) {
    const now = Date.now()
    const last = this.limitHitLog.get(key)
    if (last && now - last.at < LIMIT_HIT_LOG_INTERVAL_MS) {
      last.suppressed++
      return
    }

    this.limitHitLog.delete(key)
    if (this.limitHitLog.size >= LIMIT_HIT_LOG_MAX_KEYS) {
      this.limitHitLog.delete(this.limitHitLog.keys().next().value)
    }
    this.limitHitLog.set(key, { at: now, suppressed: 0 })

    console.warn(
      `canPerformAction: hasReachedLimit ${JSON.stringify({
        ...details,
        suppressed: last?.suppressed ?? 0,
      })}`,
    )
  }

  async canPerformAction(
    userId: string,
    action: 'send_sms' | 'receive_sms' | 'bulk_send_sms',
    value: number,
  ): Promise<{ overLimit: boolean }> {
    try {
      const user = await this.userModel
        .findById(userId)
        .select('+emailVerificationWaivedAt')
      if (!user) {
        throw new HttpException(
          { message: 'User not found' },
          HttpStatus.NOT_FOUND,
        )
      }

      if (user.isBanned) {
        throw new HttpException(
          {
            message: 'Sorry, we cannot process your request at the moment',
          },
          HttpStatus.FORBIDDEN,
        )
      }

      if (!user.emailVerifiedAt && !user.emailVerificationWaivedAt) {
        console.warn('canPerformAction: User email not verified')
        throw new HttpException(
          {
            message: 'Please verify your email to continue',
          },
          HttpStatus.BAD_REQUEST,
        )
      }

      if (this.isLimitExempt(userId)) {
        return { overLimit: false }
      }

      let plan: PlanDocument
      const subscription = await this.subscriptionModel.findOne({
        user: user._id,
        isActive: true,
      })

      if (!subscription) {
        plan = await this.planModel.findOne({ name: 'free' })
      } else {
        plan = await this.planModel.findById(subscription.plan)
      }

      const now = new Date()
      const effectiveLimits = await this.messageLimits(subscription, plan, now)
      const { paymentHold } = effectiveLimits

      if (plan.name?.startsWith('custom')) {
        // For custom plans, check if custom limits are set to unlimited (-1)
        if (
          effectiveLimits.dailyLimit === -1 &&
          effectiveLimits.monthlyLimit === -1 &&
          effectiveLimits.bulkSendLimit === -1
        ) {
          return { overLimit: false }
        }
        // Otherwise, continue with limit checks using effective limits
      }

      const period = this.usagePeriod(user, subscription, plan, now)
      const processedSmsToday = await this.smsModel.countDocuments({
        user: user._id,
        createdAt: { $gte: dailyWindowStart(now) },
      })
      const processedSmsLastMonth = await this.smsModel.countDocuments({
        user: user._id,
        createdAt: { $gte: period.start },
      })

      const { dailyLimit, monthlyLimit, bulkSendLimit } = effectiveLimits
      const dailyFinite = dailyLimit !== -1
      const monthlyFinite = monthlyLimit !== -1
      // Paid plans may run a little past their nominal monthly limit.
      const monthlyCeiling =
        monthlyFinite && plan.name !== 'free' && !paymentHold
          ? Math.floor(monthlyLimit * PAID_MONTHLY_LIMIT_MULTIPLIER)
          : monthlyLimit

      // Checked in this order: batch size, then the billing period, then today.
      // A batch larger than the room left in a window counts as a hit on that window.
      const monthlyRoom = monthlyFinite ? monthlyCeiling - processedSmsLastMonth : Infinity
      const dailyRoom = dailyFinite ? dailyLimit - processedSmsToday : Infinity
      let tripped: 'bulk' | 'monthly' | 'daily' | null = null
      let reached = false
      if (bulkSendLimit !== -1 && value > bulkSendLimit) {
        tripped = 'bulk'
        reached = true
      } else if (monthlyFinite && monthlyRoom <= 0) {
        tripped = 'monthly'
        reached = true
      } else if (dailyFinite && dailyRoom <= 0) {
        tripped = 'daily'
        reached = true
      } else if (value > Math.min(monthlyRoom, dailyRoom)) {
        tripped = dailyRoom <= monthlyRoom ? 'daily' : 'monthly'
      }

      if (tripped) {
        const room = tripped === 'daily' ? dailyRoom : monthlyRoom
        const roomText = `${pluralize(room, 'message', 'messages')} left ${
          tripped === 'daily' ? 'today' : 'in its monthly allowance'
        }`
        const fixPayment = `Update your payment method to restore your plan's limits: ${billingUrl()}`
        const holdMessage = !reached
          ? `This batch had ${value} recipients and your account has ${roomText}. Nothing was sent. Your limits are reduced because your last payment did not go through. ${fixPayment}`
          : {
              bulk: `This batch has ${value} recipients. Your last payment did not go through, so batches are limited to ${bulkSendLimit} recipients for now. Nothing was sent. ${fixPayment}`,
              monthly: `Your last payment did not go through, so your account is limited to ${monthlyLimit} messages for this billing period, and they are used. Sent and received messages both count. ${fixPayment}`,
              daily: `Your last payment did not go through, so your account is limited to ${dailyLimit} messages a day, and today's are used. Sent and received messages both count. ${fixPayment}`,
            }[tripped]
        const planMessage = !reached
          ? `This batch had ${value} recipients and your account has ${roomText}. Nothing was sent.`
          : {
              bulk: `This batch has ${value} recipients, and your plan allows ${bulkSendLimit} per batch. Nothing was sent. Split it into smaller batches or upgrade your plan.`,
              monthly: `Your account has used its ${monthlyLimit} messages for this billing period. Sent and received messages both count. Sending starts again when the allowance resets on ${formatDateTime(period.end, now)}, or upgrade your plan to keep sending now.`,
              daily: `Your account has used all ${dailyLimit} messages your plan allows today. Sent and received messages both count. Sending starts again at midnight UTC, or upgrade your plan to keep sending now.`,
            }[tripped]
        const message = paymentHold ? holdMessage : planMessage

        const storeReceive =
          action === 'receive_sms' && this.receivesOverLimitAllowed()

        if (!storeReceive) {
          this.logLimitHit(`${userId}:${tripped}`, {
            userId,
            action,
            value,
            tripped,
            reached,
            dailyLimit,
            dailyRemaining: dailyLimit - processedSmsToday,
            monthlyLimit,
            monthlyRemaining: monthlyLimit - processedSmsLastMonth,
            bulkSendLimit,
            ...(paymentHold && { paymentHold: true }),
          })
        }

        const type = {
          bulk: BillingNotificationType.BULK_SMS_LIMIT_REACHED,
          monthly: BillingNotificationType.MONTHLY_LIMIT_REACHED,
          daily: BillingNotificationType.DAILY_LIMIT_REACHED,
        }[tripped]
        const planTitle = !reached
          ? 'Your batch did not fit'
          : {
              bulk: 'Your batch was too big for your plan',
              monthly: "You've reached your monthly message limit",
              daily: "You've reached today's message limit",
            }[tripped]
        const title = paymentHold
          ? 'Your limits are reduced until your payment goes through'
          : planTitle
        const planEmailKey = reached
          ? usageEmailKey(type, plan.name)
          : usageEmailKey(BillingNotificationType.BULK_SMS_LIMIT_REACHED, plan.name)
        // The usage emails offer an upgrade, which is the wrong action here.
        const emailKey = paymentHold ? null : planEmailKey
        // A failed notice must never let an over-limit action through.
        const notification = this.billingNotifications.notifyOnce({
          userId: user._id,
          type,
          title,
          message,
          meta: {
            processedSmsToday,
            processedSmsLastMonth,
            attempted: value,
            dailyLimit,
            monthlyLimit,
            bulkSendLimit,
            planName: plan.name,
            limitTripped: tripped,
            ...(paymentHold && { paymentHold: true }),
            monthlyPeriodStart: period.start,
            monthlyResetAt: period.end,
            ...(!reached && { roomWindow: tripped, roomLeft: room }),
          },
          emailKey,
          recordHit: tripped !== 'bulk' && !paymentHold,
        })
        const logged = notification.catch((error) => {
          console.error('canPerformAction: failed to record a limit notice', {
            userId,
            error: error?.message ?? error,
          })
        })
        if (!storeReceive) await logged

        if (storeReceive) {
          return { overLimit: true }
        }

        throw new HttpException(
          {
            message: message,
            hasReachedLimit: true,
            dailyLimit,
            dailyRemaining: dailyLimit - processedSmsToday,
            monthlyRemaining: monthlyLimit - processedSmsLastMonth,
            monthlyResetAt: period.end,
            bulkSendLimit,
            monthlyLimit,
            ...(paymentHold && { paymentHold: true }),
          },
          HttpStatus.TOO_MANY_REQUESTS,
        )
      }

      if (!paymentHold) {
        this.notifyApproachingLimits(
          user._id,
          plan.name,
          {
            today: processedSmsToday + value,
            thisPeriod: processedSmsLastMonth + value,
          },
          effectiveLimits,
          period,
        )
      }

      return { overLimit: false }
    } catch (error) {
      if (error instanceof HttpException) {
        throw error
      }
      console.error('canPerformAction: Exception in canPerformAction', {
        userId,
        action,
        error: error?.stack ?? error,
      })
      return { overLimit: false }
    }
  }

  async getUsage(userId: string) {
    const user = await this.userModel.findById(userId).select('createdAt')
    const subscription = await this.subscriptionModel.findOne({
      user: new Types.ObjectId(userId),
      isActive: true,
    })

    let plan: PlanDocument
    if (!subscription) {
      plan = await this.planModel.findOne({ name: 'free' })
    } else {
      plan = await this.planModel.findById(subscription.plan)
    }

    return this.usageSummary(
      user ?? { _id: new Types.ObjectId(userId) },
      subscription,
      plan,
    )
  }

  async validatePolarWebhookPayload(payload: any, headers: any) {
    const webhookHeaders = {
      'webhook-id': headers['webhook-id'] ?? '',
      'webhook-timestamp': headers['webhook-timestamp'] ?? '',
      'webhook-signature': headers['webhook-signature'] ?? '',
    }
    try {
      const webhookPayload = await webhooks.validateEvent(
        payload,
        webhookHeaders,
        process.env.POLAR_WEBHOOK_SECRET ?? '',
      )
      return webhookPayload
    } catch (error) {
      // Signed but newer than this SDK knows; acknowledge so Polar stops retrying
      if (error instanceof webhooks.PolarWebhookUnknownTypeError) {
        console.log('ignoring unknown polar webhook event type', error.eventType)
        return null
      }
      console.log('failed to validate polar webhook payload')
      console.error(error)
      throw new Error('Invalid webhook payload')
    }
  }

  async storePolarWebhookPayload(payload: any) {
    const userId = payload.data?.metadata?.userId || payload.data?.user_id
    const eventType = payload.type
    const name = payload.data?.customer?.name || payload.data?.customer_name
    const email = payload.data?.customer?.email || payload.data?.customer_email
    const productId = payload.data?.product?.id || payload.data?.product_id
    const productName = payload.data?.product?.name || payload.data?.product_name

    await this.polarWebhookPayloadModel.create({
      userId,
      eventType,
      name,
      email,
      payload,
      productId,
      productName,
    })
  }

  private linkId(token: unknown, purpose: string): string | null {
    const secret = emailLinkSecret()
    if (!secret) return null
    return verifyLink(secret, token, purpose, Math.floor(Date.now() / 1000))
  }

  /** Where a signed card update link leads: the customer portal, or the billing page. */
  async cardUpdateRedirect(token: unknown): Promise<string> {
    const fallback = billingUrl()
    const polarSubscriptionId = this.linkId(token, 'card')
    if (!polarSubscriptionId) return fallback
    try {
      const subscription = await this.subscriptionModel.findOne({
        polarSubscriptionId,
        polarCustomerId: { $nin: [null, ''] },
      })
      if (!subscription?.polarCustomerId) return fallback
      const session = await this.polarApi.customerSessions.create({
        customer_id: subscription.polarCustomerId,
        return_url: fallback,
      })
      const url = session?.customer_portal_url
      return typeof url === 'string' && url.startsWith('https://') ? url : fallback
    } catch (error) {
      console.error('failed to open the customer portal from an email link', error?.message)
      return fallback
    }
  }

  /** Where a signed checkout link leads: the open checkout, or a new one for the same plan. */
  async checkoutResumeRedirect(token: unknown): Promise<string> {
    const checkoutSessionId = this.linkId(token, 'checkout-resume')
    if (!checkoutSessionId) return billingUrl()
    let session: CheckoutSessionDocument | null = null
    try {
      session = await this.checkoutSessionModel.findOne({ checkoutSessionId })
    } catch (error) {
      console.error('failed to load a checkout from an email link', error?.message)
    }
    const isOpen = (row: CheckoutSessionDocument | null) =>
      !!row &&
      !row.isCompleted &&
      !row.isAbandoned &&
      row.expiresAt?.getTime() > Date.now() &&
      !!row.checkoutUrl?.startsWith('https://')
    if (isOpen(session) && (await this.resumeDiscountMatches(session))) {
      // The checkout may have completed or expired during the discount check.
      let current: CheckoutSessionDocument | null = null
      try {
        current = await this.checkoutSessionModel.findOne({ checkoutSessionId })
      } catch (error) {
        console.error('failed to reload a checkout from an email link', error?.message)
      }
      if (isOpen(current)) return current.checkoutUrl
    }
    const plan = encodeURIComponent(session?.planName || 'pro')
    const interval =
      session?.billingInterval === 'yearly' || session?.billingInterval === 'monthly'
        ? session.billingInterval
        : defaultBillingInterval()
    return `${appPublicUrl()}/checkout/${plan}?billingInterval=${interval}&from=email&ref=checkout_resume`
  }

  /** Whether an open checkout carries the discount a new one would get now. */
  private async resumeDiscountMatches(session: CheckoutSessionDocument): Promise<boolean> {
    const stored = session.discountId ?? null
    const live = await this.checkoutPromotion.getLivePromotion()
    if (!live) return stored === null
    try {
      const plan = await this.planModel.findOne({ name: session.planName })
      const productId =
        session.billingInterval === 'yearly'
          ? plan?.polarYearlyProductId
          : plan?.polarMonthlyProductId
      return stored === (promotionCovers(live.discount, productId) ? live.discount.id : null)
    } catch (error) {
      console.error('failed to load the plan of a resumed checkout', error?.message)
      return false
    }
  }

  /**
   * Where a signed switch-to-yearly link leads: the yearly confirm screen for
   * the current plan, or the customer portal when the card failed, which
   * returns to the billing page.
   */
  async yearlySwitchRedirect(token: unknown): Promise<string> {
    const polarSubscriptionId = this.linkId(token, 'yearly')
    if (!polarSubscriptionId) return billingUrl()
    let subscription: SubscriptionDocument | null = null
    try {
      subscription = await this.subscriptionModel
        .findOne({ polarSubscriptionId, isActive: true })
        .populate('plan')
    } catch (error) {
      console.error('failed to load a subscription from an email link', error?.message)
    }
    const plan = subscription?.plan as Plan | undefined
    if (!plan?.name || plan.name.startsWith('custom') || !plan.polarYearlyProductId) {
      return billingUrl()
    }
    if (
      this.normalizeBillingInterval(subscription.recurringInterval) !== 'monthly' ||
      subscription.cancelAtPeriodEnd === true ||
      ['incomplete', 'unpaid'].includes(subscription.status)
    ) {
      return billingUrl()
    }
    const baseMonthly =
      typeof subscription.amount === 'number' && subscription.amount > 0
        ? subscription.amount / 100
        : (plan.monthlyPrice ?? 0) / 100
    const yearly = (plan.yearlyPrice ?? 0) / 100
    if (!(baseMonthly > 0) || !(yearly > 0)) return billingUrl()
    const savingPercent = Math.round(
      ((baseMonthly * 12 - yearly) / (baseMonthly * 12)) * 100,
    )
    if (savingPercent < 1) return billingUrl()
    const planPath = encodeURIComponent(plan.name)
    const target = `${appPublicUrl()}/checkout/${planPath}?billingInterval=yearly&from=email&ref=yearly_switch`
    if (subscription.status !== 'past_due' || !subscription.polarCustomerId) {
      return target
    }
    try {
      const session = await this.polarApi.customerSessions.create({
        customer_id: subscription.polarCustomerId,
        return_url: `${appPublicUrl()}/dashboard/account/billing?from=email&ref=yearly_switch`,
      })
      const url = session?.customer_portal_url
      return typeof url === 'string' && url.startsWith('https://') ? url : target
    } catch (error) {
      console.error('failed to open the customer portal from an email link', error?.message)
      return target
    }
  }

  /**
   * Mirror a Polar checkout's terminal status onto our cached checkout session.
   *
   * Without this nothing ever writes isCompleted, so a checkout the customer
   * already paid for stayed reusable until it expired, and the completed count
   * read as zero. Keyed on checkoutSessionId rather than user because the cache
   * holds one row per user: once a newer checkout replaces it, a late webhook
   * for the old id should match nothing rather than clobber the new row.
   */
  async syncCheckoutSessionStatus({
    checkoutSessionId,
    status,
  }: {
    checkoutSessionId: string
    status: string
  }) {
    if (!checkoutSessionId) return

    // open and confirmed are still in flight, and failed is retryable, so the
    // cached session stays valid for all three.
    let update: Record<string, any> | null = null
    if (status === 'succeeded') {
      update = { isCompleted: true, completedAt: new Date() }
    } else if (status === 'expired') {
      update = { isAbandoned: true }
    }
    if (!update) return

    await this.checkoutSessionModel
      .updateOne({ checkoutSessionId }, update)
      .catch((error) => {
        console.error('failed to sync checkout session status', error)
      })

    if (status === 'succeeded') {
      try {
        const latest = await this.checkoutAttemptModel
          .findOne({ checkoutSessionId })
          .sort({ createdAt: -1 })
          .select('_id completedAt')
          .lean()
        if (latest && !latest.completedAt) {
          await this.checkoutAttemptModel.updateOne(
            { _id: latest._id, completedAt: { $exists: false } },
            { $set: { completedAt: update.completedAt } },
          )
        }
      } catch (error) {
        console.error('failed to complete checkout attempt', error?.message)
      }
    }
  }
}
