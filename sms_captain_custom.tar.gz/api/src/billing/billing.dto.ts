import { ApiProperty } from '@nestjs/swagger'

export class PlanPromotionDTO {
  @ApiProperty({
    type: String,
    description: 'Name of the promotion, as set on the Polar discount.',
    example: 'Spring offer',
  })
  label: string

  @ApiProperty({
    type: Number,
    description: 'Percentage taken off the list price, such as 20 for 20% off.',
    example: 20,
  })
  percentOff: number

  @ApiProperty({
    type: String,
    format: 'date-time',
    nullable: true,
    description:
      'When the promotion stops applying to new checkouts and plan changes, as an ISO 8601 time. Null when it has no end date.',
  })
  endsAt: string | null

  @ApiProperty({
    enum: ['once', 'repeating', 'forever'],
    description:
      'How long a subscription keeps the discount: the first payment only (once), a number of months (repeating), or every renewal while it stays active (forever).',
  })
  duration: 'once' | 'repeating' | 'forever'

  @ApiProperty({
    type: Number,
    nullable: true,
    description: 'Number of months the discount lasts when duration is repeating. Null otherwise.',
  })
  durationInMonths: number | null

  @ApiProperty({
    type: Number,
    nullable: true,
    description:
      'Monthly price in cents after the discount. Null when the promotion does not cover monthly billing for this plan.',
  })
  monthlyPrice: number | null

  @ApiProperty({
    type: Number,
    nullable: true,
    description:
      'Yearly price in cents after the discount. Null when the promotion does not cover yearly billing for this plan.',
  })
  yearlyPrice: number | null

  @ApiProperty({
    type: Boolean,
    description:
      'Always false: the discount applies to new checkouts and to plan changes on a subscription that has no discount yet.',
  })
  newCheckoutsOnly: false
}

export class PlanDTO {
  @ApiProperty({
    type: String,
    description: 'Plan identifier, used as planName when starting a checkout.',
    example: 'pro',
  })
  name: string

  @ApiProperty({
    type: Number,
    description: 'Monthly price in the plan currency.',
  })
  monthlyPrice: number

  @ApiProperty({
    type: Number,
    required: false,
    description: 'Yearly price, when the plan can be billed yearly.',
  })
  yearlyPrice?: number

  @ApiProperty({
    type: String,
    required: false,
    description: 'Polar product backing this plan.',
  })
  polarProductId?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Polar product for monthly billing.',
  })
  polarMonthlyProductId?: string

  @ApiProperty({
    type: String,
    required: false,
    description: 'Polar product for yearly billing.',
  })
  polarYearlyProductId?: string

  @ApiProperty({
    type: Boolean,
    description: 'Whether the plan can be subscribed to right now.',
  })
  isActive: boolean

  @ApiProperty({
    type: PlanPromotionDTO,
    required: false,
    nullable: true,
    description:
      'Promotion this plan is currently eligible for. It is applied automatically at checkout, and on a plan change when the subscription has no discount yet, subject to the payment provider accepting it. Null when no promotion is live or it does not cover this plan.',
  })
  promotion?: PlanPromotionDTO | null
}

export class PlansResponseDTO extends Array<PlanDTO> {}

export class CheckoutInputDTO {
  @ApiProperty({
    type: String,
    required: true,
    description: 'Plan to subscribe to, by name.',
    example: 'pro',
  })
  planName: string

  @ApiProperty({
    type: String,
    required: false,
    deprecated: true,
    description:
      'Ignored. A live promotion is applied automatically, and other discounts are entered on the checkout page.',
  })
  discountId?: string

  @ApiProperty({
    enum: ['monthly', 'yearly'],
    required: false,
    description: 'Billing period. Defaults to monthly.',
  })
  billingInterval?: 'monthly' | 'yearly'

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Where the request started, such as a page or an email. Lowercase letters, digits and underscores, up to 40 characters. An invalid value is ignored.',
    example: 'app_billing',
  })
  from?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Detail for from, such as an email or notice id. Letters, digits, underscores and hyphens, up to 64 characters. An invalid value is ignored.',
  })
  ref?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'An earlier from value seen in the same browser. Same format as from. An invalid value is ignored.',
  })
  priorFrom?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'The ref that came with priorFrom. Same format as ref. An invalid value is ignored.',
  })
  priorRef?: string

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether from and ref were read from a stored value rather than the link.',
  })
  fromCookie?: boolean
}

export class PlanChangePreviewDTO {
  @ApiProperty({ type: String, description: 'Plan the account is on now.' })
  currentPlan: string

  @ApiProperty({
    enum: ['monthly', 'yearly'],
    description: 'Billing period in force now.',
  })
  currentInterval: string

  @ApiProperty({ type: String, description: 'Plan being moved to.' })
  newPlan: string

  @ApiProperty({
    enum: ['monthly', 'yearly'],
    description: 'Billing period being moved to.',
  })
  newInterval: string

  @ApiProperty({
    type: Boolean,
    description: 'Whether the change raises the plan level.',
  })
  isUpgrade: boolean

  @ApiProperty({
    type: Boolean,
    description: 'Whether the current subscription ends at the period end.',
  })
  cancelAtPeriodEnd: boolean

  @ApiProperty({
    type: Boolean,
    description:
      'Whether the live promotion applies to this change. False when none is live, it does not cover the new plan, or the subscription already has a discount.',
  })
  promotionApplies: boolean
}

export class CheckoutResponseDTO {
  @ApiProperty({
    type: String,
    required: false,
    description: 'Polar checkout URL to send the user to.',
  })
  redirectUrl?: string

  // returned instead of redirectUrl when the user already has an active paid
  // Polar subscription, so the frontend shows a confirmation screen
  @ApiProperty({
    type: PlanChangePreviewDTO,
    required: false,
    description:
      'Returned instead of redirectUrl when the account already pays for a plan. Confirm it, then call POST /billing/change-plan.',
  })
  planChange?: PlanChangePreviewDTO
}

export class ChangePlanInputDTO {
  @ApiProperty({
    type: String,
    required: true,
    description: 'Plan to switch to, by name.',
    example: 'pro',
  })
  planName: string

  @ApiProperty({
    enum: ['monthly', 'yearly'],
    required: false,
    description: 'Billing period to switch to.',
  })
  billingInterval?: 'monthly' | 'yearly'

  @ApiProperty({
    type: Boolean,
    required: false,
    description:
      'True when the subscriber confirmed the promotion price. The change is then refused with PROMOTION_UNAVAILABLE, and nothing is charged, if the promotion does not apply.',
  })
  promotionShown?: boolean

  @ApiProperty({
    type: Number,
    required: false,
    description:
      'The promotion percentage the subscriber confirmed, such as 20. With promotionShown, a different live percentage refuses the change with PROMOTION_UNAVAILABLE.',
  })
  promotionPercentOff?: number

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Where the request started, such as a page or an email. Lowercase letters, digits and underscores, up to 40 characters. An invalid value is ignored.',
    example: 'app_billing',
  })
  from?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'Detail for from, such as an email or notice id. Letters, digits, underscores and hyphens, up to 64 characters. An invalid value is ignored.',
  })
  ref?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'An earlier from value seen in the same browser. Same format as from. An invalid value is ignored.',
  })
  priorFrom?: string

  @ApiProperty({
    type: String,
    required: false,
    description:
      'The ref that came with priorFrom. Same format as ref. An invalid value is ignored.',
  })
  priorRef?: string

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether from and ref were read from a stored value rather than the link.',
  })
  fromCookie?: boolean
}

export class ChangePlanResponseDTO {
  @ApiProperty({ type: Boolean, description: 'Whether the switch succeeded.' })
  success: boolean

  @ApiProperty({ type: String, description: 'Plan the account is now on.' })
  plan: string
}

export class SubscriptionUsageDTO {
  @ApiProperty({ type: Number, description: 'Messages processed today.' })
  processedSmsToday: number

  @ApiProperty({
    type: Number,
    description:
      'Messages processed in the current billing period. The name is kept for compatibility.',
  })
  processedSmsLastMonth: number

  @ApiProperty({
    type: Date,
    description:
      'Start of the current billing period. Free accounts count from the signup date each month, paid accounts from the plan start date.',
  })
  monthlyPeriodStart: Date

  @ApiProperty({
    type: Date,
    description: 'When the monthly allowance resets and the next billing period starts.',
  })
  monthlyResetAt: Date

  @ApiProperty({
    type: Number,
    description: 'Messages allowed per day. -1 means unlimited.',
  })
  dailyLimit: number

  @ApiProperty({
    type: Number,
    description: 'Messages allowed per billing period. -1 means unlimited.',
  })
  monthlyLimit: number

  @ApiProperty({
    type: Number,
    description: 'Messages allowed in one bulk send. -1 means unlimited.',
  })
  bulkSendLimit: number

  @ApiProperty({
    type: Number,
    description: 'Devices allowed on the account. -1 means unlimited.',
  })
  deviceLimit: number

  @ApiProperty({
    type: Number,
    description:
      'Webhook subscriptions allowed on the account. -1 means unlimited.',
  })
  webhookLimit: number

  @ApiProperty({
    type: Number,
    description: 'Messages left today. -1 when the daily limit is unlimited.',
  })
  dailyRemaining: number

  @ApiProperty({
    type: Number,
    description:
      'Messages left in the current billing period. -1 when the monthly limit is unlimited.',
  })
  monthlyRemaining: number

  @ApiProperty({
    type: Number,
    description: 'Share of the daily allowance used, 0 to 100.',
  })
  dailyUsagePercentage: number

  @ApiProperty({
    type: Number,
    description: 'Share of the billing period allowance used, 0 to 100.',
  })
  monthlyUsagePercentage: number

  @ApiProperty({
    type: Boolean,
    description:
      'True while the message limits are reduced to those of the free plan because a renewal payment is unpaid. They return when the payment goes through.',
  })
  paymentHold: boolean
}

export class CurrentSubscriptionResponseDTO {
  @ApiProperty({
    type: PlanDTO,
    description: 'Plan in force. Accounts without a paid plan get the free one.',
  })
  plan: PlanDTO

  @ApiProperty({
    type: Boolean,
    description: 'Whether the subscription is currently active.',
  })
  isActive: boolean

  @ApiProperty({
    type: String,
    required: false,
    description: 'Subscription state reported by Polar.',
  })
  status?: string

  @ApiProperty({
    enum: ['monthly', 'yearly'],
    required: false,
    description: 'Billing period. Absent on the free plan.',
  })
  recurringInterval?: string

  @ApiProperty({
    type: Boolean,
    required: false,
    description: 'Whether the plan ends when the paid period does.',
  })
  cancelAtPeriodEnd?: boolean

  @ApiProperty({
    type: Date,
    required: false,
    description: 'Start of the paid period.',
  })
  currentPeriodStart?: Date

  @ApiProperty({
    type: Date,
    required: false,
    description: 'End of the paid period.',
  })
  currentPeriodEnd?: Date

  @ApiProperty({
    type: SubscriptionUsageDTO,
    description: 'Limits and how much of them the account has used.',
  })
  usage: SubscriptionUsageDTO
}

export class BillingNotificationDTO {
  @ApiProperty({ type: String, description: 'Notification id.' })
  _id: string

  @ApiProperty({
    type: String,
    description: 'What triggered it, for example a limit being reached.',
  })
  type: string

  @ApiProperty({ type: String, description: 'Headline shown in the dashboard.' })
  title: string

  @ApiProperty({ type: String, description: 'Body text.' })
  message: string

  @ApiProperty({
    type: Date,
    required: false,
    description: 'When the account read it. Absent while unread.',
  })
  readAt?: Date

  @ApiProperty({ type: Date, description: 'When it was raised.' })
  createdAt: Date
}
