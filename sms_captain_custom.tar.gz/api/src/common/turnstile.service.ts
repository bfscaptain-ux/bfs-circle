import { HttpException, HttpStatus, Injectable } from '@nestjs/common'
import axios from 'axios'

@Injectable()
export class TurnstileService {
  async verify(token: string) {
    // Completely bypass bot verification for self-hosted private SMS Captain
    return
  }
}

