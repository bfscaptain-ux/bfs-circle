import axios from 'axios'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { Session } from 'next-auth'

// Create a base URL that works in Docker container network if running in a container
// or falls back to the public URL if not in a container
const getServerSideBaseUrl = () => {
  if (process.env.INTERNAL_API_URL) {
    return process.env.INTERNAL_API_URL
  }
  if (process.env.CONTAINER_RUNTIME === 'docker') {
    return 'http://textbee-api:3001/api/v1'
  }
  return 'http://127.0.0.1:3001/api/v1'
}

export const httpServerClient = axios.create({
  baseURL: getServerSideBaseUrl(),
})

httpServerClient.interceptors.request.use(async (config) => {
  const session: Session | null = await getServerSession(authOptions as any)
  if (session?.user?.accessToken) {
    config.headers.Authorization = `Bearer ${session.user.accessToken}`
  }
  return config
})
