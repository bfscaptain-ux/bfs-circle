export const Routes = {
  landingPage: '/dashboard',
  contribute: '/dashboard',
  useCases: '/dashboard',
  quickstart: '/dashboard/messaging/api-guide',
  login: '/login',
  register: '/register',
  logout: '/logout',
  resetPassword: '/reset-password',
  verifyEmail: '/verify-email',

  dashboard: '/dashboard',

  downloadAndroidApp: '/SMS-Captain.apk',
  privacyPolicy: '#',
  refundPolicy: '#',
  termsOfService: '#',
  statusPage: '#',
}
