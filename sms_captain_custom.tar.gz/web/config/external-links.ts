const POLAR_CUSTOMER_PORTAL_REQUEST_BASE = '#'

export function polarCustomerPortalRequestUrl(
  email?: string | null
): string {
  return '#'
}

const SMS_PERMISSION_GUIDE = '#'

export function smsPermissionGuideUrl(source: string): string {
  return '#'
}

export const ExternalLinks = {
  patreon: '#',
  github: '#',
  discord: '#',
  polar: '#',
  twitter: '#',
  linkedin: '#',
}
