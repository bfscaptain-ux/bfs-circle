'use client'

import { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import {
  DISCORD_STORAGE_KEYS as STORAGE_KEYS,
  markDiscordJoined,
  openDiscordInvite,
  recordDiscordModalShown,
  safeGetDiscordFlag,
} from '@/lib/discord-community'

const SHOW_INTERVAL = 1 * 24 * 60 * 60 * 1000 // 1 days in milliseconds
const RANDOM_CHANCE = 0.2 // 20% chance to show when eligible

export const JoinCommunityModal = () => {
  return null
}
