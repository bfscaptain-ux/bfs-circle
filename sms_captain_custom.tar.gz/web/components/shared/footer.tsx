import { Routes } from '@/config/routes'
import { ExternalLinks } from '@/config/external-links'
import { Activity } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'

// A logged-in user is already converted, so the app footer stays a single slim
// bar rather than the marketing site's multi-column link farm. It borrows that
// footer's visual language (muted surface, muted-to-foreground link hovers,
// green status pill) so the two still read as one product.
const links = [
  { label: 'Dashboard', href: '/dashboard' },
  { label: 'Messaging', href: '/dashboard/messaging' },
  { label: 'API Guide', href: '/dashboard/messaging/api-guide' },
  { label: 'Webhooks', href: '/dashboard/webhooks' },
  { label: 'Download APK', href: '/SMS-Captain.apk' },
]

const linkClass =
  'text-sm text-muted-foreground transition-colors hover:text-foreground'

export default function Footer() {
  return (
    <footer className='border-t border-border bg-shell/60'>
      <div className='mx-auto flex max-w-7xl flex-col items-start gap-4 px-4 py-6 sm:items-center sm:px-6 md:flex-row md:justify-between lg:px-8'>
        <div className='flex items-center gap-2'>
          <Image
            src='/images/logo.png'
            alt='SMS Captain logo'
            width={20}
            height={20}
            className='h-5 w-5 rounded-full bg-white'
          />
          <span className='text-sm text-muted-foreground'>
            © {new Date().getFullYear()} SMS Captain
          </span>
        </div>

        <nav
          aria-label='Footer'
          className='flex w-full flex-col items-start gap-3 sm:w-auto sm:flex-row sm:flex-wrap sm:items-center sm:justify-center sm:gap-x-5 sm:gap-y-2'
        >
          {links.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className={linkClass}
            >
              {link.label}
            </Link>
          ))}
          <span
            className='inline-flex items-center gap-1.5 rounded-full border bg-muted/70 px-2.5 py-1 text-sm font-medium text-success'
          >
            <Activity className='h-3.5 w-3.5' />
            Online
          </span>
        </nav>
      </div>
    </footer>
  )
}
